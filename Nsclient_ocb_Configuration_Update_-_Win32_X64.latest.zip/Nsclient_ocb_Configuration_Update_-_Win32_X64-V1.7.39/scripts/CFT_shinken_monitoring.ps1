[CmdletBinding()]
param(
        [Parameter(Mandatory = $True, ParameterSetName = "Flows")]
        [switch]$check_flows,

        [Parameter(Mandatory = $True, ParameterSetName = "process")]
        [switch]$check_process,

        [Parameter(Mandatory = $True, ParameterSetName = "freeSpace")]
        [switch]$check_catalog_free_space,

        [Parameter(Mandatory = $False, ParameterSetName = "freeSpace", position = 0)]
        [int]$percent_free_space = 30
)

#check_catalog_free_space

# PS C:\Users\Admin> get-help c:\NTAppl\test_supp\CFT_shinken_monitoring.ps1
# CFT_shinken_monitoring.ps1 -check_flows [<CommonParameters>]
# CFT_shinken_monitoring.ps1 -check_process [<CommonParameters>]
# CFT_shinken_monitoring.ps1 [[-percent_free_space] <int>] -check_catalog_free_space [<CommonParameters>]



###############################################################################################################################################
# Versions
###############################################################################################################################################

# 02/2021 - V1 - First release


###############################################################################################################################################
# Exit codes
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one of the provide parameter isn't right!
# 2 : "Critical" At least one Vault element is not working!
###############################################################################################################################################

$Shinken_error_code = 0

###############################################################################################################################################
# translate profile.bat to PS
###############################################################################################################################################

$null = get-process -name CFTMAIN -ErrorAction SilentlyContinue
if (!$?) {
    write-host "CRITICAL : CFTMAIN not running"
    Exit 2
}

$CFT_runningpath = (get-process -name CFTMAIN).path
$CFT_root = ""
foreach ($part in $CFT_runningpath.split('\')) {
    if ($part -eq "home") {break}
    $CFT_root += $part + "\"
}

$env:CFTDIRINSTALL = $CFT_root + "home"
$env:CFTDIRRUNTIME = $CFT_root + "runtime"
$env:PATH_CLEAN =  $CFT_ROOT + "home\bin;" + $CFT_ROOT + "runtime\bin;" + $env:PATH
$env:CFTUCONF = $env:CFTDIRRUNTIME + "\data\cftuconf.dat"
$env:CFTBINPATH = $env:CFTDIRINSTALL + "\bin;" + $env:CFTDIRRUNTIME + "\bin"
$env:PATH = $env:CFTBINPATH + ";"+ $env:PATH_CLEAN
#$CFTDIRHOME=%CD%

$cmd_result = invoke-expression "$env:CFTDIRINSTALL\bin\cftutil.exe /m=0 uconfsubst FIN=$env:CFTDIRINSTALL\distrib\dat\profile.inc"

foreach($line in $cmd_result){
        $env_var, $env_value  = $line.split("=")
        if ($env_var) {
                [Environment]::SetEnvironmentVariable($env_var, $env_value)
        }
}

###############################################################################################################################################
# Commands
# Invoke-Expression "$env:CFTDIRINSTALL\bin\cftutil.exe"
###############################################################################################################################################

if ($check_flows) {

        $cmd_result = invoke-expression "$env:CFTDIRINSTALL\bin\cftutil.exe listcat state=HK,direct=send,type=file"
        if ($cmd_result -match " 0 record\(s\) selected") {
                write-host "OK : No Flows in error"
                $Shinken_error_code = 0
        } else {
                write-host "CRITICAL : Flows in error"
                $Shinken_error_code = 2
        }
}

if ($check_process) {
        $cmd_result = invoke-expression "cftping -p"
        if ($cmd_result -match "not") {
                write-host "CRITICAL : process not running"
                $Shinken_error_code = 2
        } else {
                write-host "OK : $cmd_result"
        }
}

if ($check_catalog_free_space) {
        $cmd_result = invoke-expression "$env:CFTDIRINSTALL\bin\cftutil.exe listcat"
        $null = ($cmd_result -join(' ')) -match " free \((\d+)%\)"

        [int]$fs = $Matches[1]
        if ($fs -lt $percent_free_space) {
                write-host "CRITICAL : Free CATALOG space $fs"
                $Shinken_error_code = 2
        } else {
                write-host "OK : Free CATALOG space $fs"
        }
}

Exit $Shinken_error_code

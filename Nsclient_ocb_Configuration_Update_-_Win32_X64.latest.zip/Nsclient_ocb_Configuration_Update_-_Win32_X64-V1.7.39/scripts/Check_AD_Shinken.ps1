###############################################################################################################################################
# Script Name : Check_AD_Shinken.ps1
# Adapted from Check_AD.ps1 script (without Display and without Domain controler role check)
###############################################################################################################################################
# Version : 1.5
###############################################################################################################################################
# Description : This Script check the health status of AD: Ping,Netlogon,NTDS,DNS,DCdiag Test(Replication,sysvol,Services,Advertising...)
# Usage example:
# .\Check_AD.ps1 -local
# .\Check_AD.ps1 -full
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 03/2016, Guillaume Blois, First script version
# 0.2, 03/2016, Guillaume Blois, Delete timeout if test is only local, and stop checkflow if one flow is failed.
# 1.0, 03/2016, Guillaume Blois, First Release
# 1.1, 03/2016, Guillaume Blois, Special version for Shinken compatibility/change exit codes
# 1.2, 03/2016, Guillaume Blois, Delete Services checks like, services will be directly monitored by Shinken
# 1.3, 03/2016, Guillaume Blois, Delete DNS Check as it is too long for Shinken Monitoring
# 1.4, 07/2016, Guillaume Blois, Add out-null for the result file creation "Check_AD_report.htm".
# 1.5, 07/2016, Guillaume Blois, Set "-local" if no parameter is done
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" Checks cannot be done because timeout or closed flows.
# 2 : "Critical" one of the flow or service failed!

# Old codes without Shinken:
# 0 : All tests are Ok
# 1 : Wrong Powershell version
# 2 : Wrong Powershell execution Policy
# 3 : No parameter has been passed to the script
# 4 : Active Directory role is not installed.
# 5 : One of the Ad flows checked is not opened
# 6 : Check Service failed
# 7 : Test DCDIAG failed

###############################################################################################################################################
# Script Parameters Declaration 
###############################################################################################################################################
param(
	[Switch]$local = $False,
	[Switch]$full = $False
)

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$reportpath = ".\Check_AD_report.htm" 
$timeout = "80"
$powershellversion = $host.Version.major
$global:Computername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$global:errorcode = "0"
$Shinkenerrorcode = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

Function Show-UsageMessage
{
	Write-Host "`n#############################################`n`tScript Usage :`n#############################################"
	Write-Host ".\Check_AD.ps1 -local"
	Write-Host ".\Check_AD.ps1 -full"
	Write-Host "`n#################################`n`tAt least on parameter is mandatory:`n####################################"
	Write-Host "-local : Specifies that only the Domain controller server where this script is executed, will be checked"
	Write-host "-full  : Specifies that all the Domain controllers of the forest will be check from this server"
	Write-host "-Usage : Show this message`n"
}

### This Function #Diplay a message with the date and color if need it
Function Diplay 
{
	param (
	[String] $Text,
	[String] $Type
	)
	$date = Get-Date
	Switch($Type)
	{
		"OK" {Write-Host "$date - $text" -nonewline; Write-Host " [Success]" -ForegroundColor Green}
		"NOK" {Write-Host "$date - $text" -nonewline; Write-Host " [Fail]" -ForegroundColor Red}
		"WARNING" {Write-Warning "$date - $text"}
		DEFAULT {Write-Host "$date - $text"}
	}
}

### This Function check if flow is opened
Function Check-Flow
{
	param(
	[String]$Server,
	[Int]$Port
	)

	# Create a Net.Sockets.TcpClient object to use for
    # checking for open TCP ports.
    $Socket = New-Object Net.Sockets.TcpClient
        
    # Suppress error messages
    $ErrorActionPreference = 'SilentlyContinue'
        
    # Try to connect
    $Socket.Connect($Server, $Port)
        
    # Make error messages visible again
    $ErrorActionPreference = 'Continue'
        
    # Determine if we are connected
    if ($Socket.Connected) 
	{
        $Socket.Close()
    }Else
	{
		#Diplay "The flow $Port is closed toward $Server" "NOK"
        $global:errorcode = "5"
        $global:flowstatus = $false
    }
        
    # Resetting the variable
    $Socket = $null
}

### This function check if service is present and running or not
Function Check-Service
{
	param(
	[String]$Servicename
	)
        
    $serviceStatus = start-job -scriptblock {get-service -ComputerName $($args[0]) -Name $($args[1]) -ErrorAction SilentlyContinue} -ArgumentList ($DC,$Servicename)
    wait-job $serviceStatus -timeout $timeout| Out-Null
    if($serviceStatus.state -like "Running")
    {
        #Diplay "Service status $Servicename Timeout" "WARNING"
        Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Timeout</B></td>"
    }else
    {
        $serviceStatus1 = Receive-job $serviceStatus
        if ($serviceStatus1.status -eq "Running") 
        {
 		    #Diplay "Service Status $Servicename running" "OK"            
         	Add-Content $report "<td bgcolor= 'Aquamarine' align=center><B>Running</B></td>" 
        }else 
        { 
       		#Diplay "Service Status $Servicename failed" "NOK"
            $global:errorcode = "6"         
         	Add-Content $report "<td bgcolor= 'Red' align=center><B>Failed</B></td>" 
        } 
    }
    Stop-job $serviceStatus -ErrorAction SilentlyContinue
}

### This function execute the DCdiag test depending of the passed parameter
Function Test-DCDIAG
{
	param(
	[String]$dcdiagtest
	)
    add-type -AssemblyName microsoft.visualbasic 
    $cmp = "microsoft.visualbasic.strings" -as [type]
    $sysvol = start-job -scriptblock {dcdiag /test:$($args[0]) /s:$($args[1])} -ArgumentList ($dcdiagtest,$DC)
    wait-job $sysvol -timeout $timeout | Out-Null
    if($sysvol.state -like "Running")
    {
        #Diplay "Test $dcdiagtest Timeout" "WARNING"
        Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Timeout</B></td>"
    }else
    {
        $sysvol1 = Receive-job $sysvol
        if($dcdiagtest -eq '"DNS /DNSBASIC"')
        {
            $checktest = $cmp::instr($sysvol1, "passed test DNS") 
        }elseif($dcdiagtest -eq "FsmoCheck")
        {
            $checktest = (($cmp::instr($sysvol1, "passed test")) -and ($cmp::instr($sysvol1, "FsmoCheck"))) 
        }else
        {
            $checktest = $cmp::instr($sysvol1, "passed test $dcdiagtest")
        }

        if($checktest)
        {
            #Diplay "Test $dcdiagtest passed" "OK"
            Add-Content $report "<td bgcolor= 'Aquamarine' align=center><B>Passed</B></td>"
        }else
        {
            #Diplay "Test $dcdiagtest failed" "NOK"
            $global:errorcode = "7"
            Add-Content $report "<td bgcolor= 'Red' align=center><B>Failed</B></td>"
        }
    }
    stop-job $sysvol -ErrorAction SilentlyContinue
}

###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

# Checking Powershell status

If ($powershellversion -lt "2")
{
    #Diplay "Wrong powershell version detected" "Warning"
    $global:errorcode = "1"
    Exit $global:errorcode
}

#$Policy = "RemoteSigned"
#$Policy2 = "Unrestricted"
#If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)) 
#{
#  #Diplay "Script Execution is disabled. Enabling it now" "Warning"
#  Set-ExecutionPolicy $Policy -Force
#  #Diplay "Please Re-Run this script in a new powershell enviroment" "Warning"
#  $global:errorcode =  = "2"
#  Exit $global:errorcode
#}

# Show Usage
If($Usage -eq $True)
{
    #Show-UsageMessage
    $global:errorcode = "3"
    Exit $global:errorcode
}

# If no method is passed to the script
If($local -eq $False -And $full -eq $False)
{
    #Diplay "No method has been passed to the script, only local Domain controller will be tested" "WARNING"
    $local = $true
}


#Log file creation (Report in HTML format)
if((test-path $reportpath) -like $false)
{
new-item $reportpath -type file | out-null
}

$report = $reportpath
Clear-Content $report 
Add-Content $report "<html>" 
Add-Content $report "<head>" 
Add-Content $report "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>" 
Add-Content $report '<title>AD Status Report</title>' 
add-content $report '<STYLE TYPE="text/css">' 
add-content $report  "<!--" 
add-content $report  "td {" 
add-content $report  "font-family: Tahoma;" 
add-content $report  "font-size: 11px;" 
add-content $report  "border-top: 1px solid #999999;" 
add-content $report  "border-right: 1px solid #999999;" 
add-content $report  "border-bottom: 1px solid #999999;" 
add-content $report  "border-left: 1px solid #999999;" 
add-content $report  "padding-top: 0px;" 
add-content $report  "padding-right: 0px;" 
add-content $report  "padding-bottom: 0px;" 
add-content $report  "padding-left: 0px;" 
add-content $report  "}" 
add-content $report  "body {" 
add-content $report  "margin-left: 5px;" 
add-content $report  "margin-top: 5px;" 
add-content $report  "margin-right: 0px;" 
add-content $report  "margin-bottom: 10px;" 
add-content $report  "" 
add-content $report  "table {" 
add-content $report  "border: thin solid #000000;" 
add-content $report  "}" 
add-content $report  "-->" 
add-content $report  "</style>" 
Add-Content $report "</head>" 
Add-Content $report "<body>" 
add-content $report  "<table width='100%'>" 
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Active Directory Health Check</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report  "<tr bgcolor='IndianRed'>" 
Add-Content $report  "<td width='5%' align='center'><B>Identity</B></td>" 
Add-Content $report  "<td width='10%' align='center'><B>FlowsStatus</B></td>" 
#Add-Content $report  "<td width='10%' align='center'><B>Service-Netlogon</B></td>" 
#Add-Content $report  "<td width='10%' align='center'><B>Service-NTDS</B></td>" 
#Add-Content $report  "<td width='10%' align='center'><B>Service-DNS</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-FSMO</B></td>"
#Add-Content $report  "<td width='10%' align='center'><B>Test-DNS</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-MACHINEACCOUNT</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-SYSVOLCHECK</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-RIDMANAGER</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-KCCEVENT</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-Netlogons</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-Replication</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-Services</B></td>"
Add-Content $report  "<td width='10%' align='center'><B>Test-Advertising</B></td>"
Add-Content $report "</tr>" 

#Get ALL DC Servers

#import-module servermanager
#$global:ADDSrole = Get-WindowsFeature -Name AD-Domain-Services 
#If(!($ADDSrole.Installed))
#{
#    #Diplay "The Active Directory Domain Service role isn't installed on this $Computername computer" "NOK"
#    $global:errorcode = "4"    
#}Else
#{
    #Diplay "The Active Directory Domain Service role is installed on this $Computername computer" "OK"
    If($full -eq $true)
    {
        $getForest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest()
        $DCServers = $getForest.domains | ForEach-Object {$_.DomainControllers} | ForEach-Object {$_.Name} 
    }elseif($local -eq $true)
    {
        $DCServers = $computername
        $timeout = "-1"     
    }

    foreach ($DC in $DCServers)
    {
        #Diplay "###### Check $DC AD Services...#####"
        Add-Content $report "<tr>"

        $global:flowstatus = $true
        If($dc -ne $computername)
        {
            Check-Flow $DC "53"
            if($errorcode -ne "5")
            {
                Check-Flow $DC "88"
                Check-Flow $DC "135"
                Check-Flow $DC "389"
                Check-Flow $DC "445"
                Check-Flow $DC "464"
                Check-Flow $DC "636"
            }
        }

        if ($flowstatus -eq $true) 
        {
            #Diplay "A Minimal number of AD flows are opened to this server"
            Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B>$DC</B></td>" 
            Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B>Success</B></td>" 

            ####################Test services#####################################

            #Netlogon Service Status
		    #Check-Service "Netlogon" 

            #NTDS Service Status
		    #Check-Service "NTDS"

            #DNS Service Status
		    #Check-Service "DNS"

            ####################Check Dcdiags######################################

            If (($dc -eq $computername) -or (Test-Connection -computername $dc -Quiet))
            {
                
                #FSMOCheck status
                Test-DCDIAG "FsmoCheck"
                
                #DNS status
                #Test-DCDIAG '"DNS /DNSBASIC"'

                #MACHINEACCOUNT status
                Test-DCDIAG "MachineAccount"

                #SYSVOLCHECK status
                Test-DCDIAG "SysVolCheck"

                #RIDMANAGER status
                Test-DCDIAG "RidManager"

                #KCCEVENT status
                Test-DCDIAG "KccEvent"

                #Netlogons status
                Test-DCDIAG "NetLogons"

                #Replications status
                Test-DCDIAG "Replications"

	            #Services status
                Test-DCDIAG "Services"

	            #Advertising status
                Test-DCDIAG "Advertising"
                
               ##################End of tests######################################
            }else
            {
                $Shinkenerrorcode = "1"
                #Diplay "Failed test of connectivity (Ping) to this server" "WARNING"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
                Add-Content $report "<td bgcolor= 'Yellow' align=center><B>Ping Failed</B></td>"
            }     
        }else
        {
            Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B>$DC</B></td>" 
            Add-Content $report "<td bgcolor= 'Red' align=center>  <B>Closed</B></td>" 
	        Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>"
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>"
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            #Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            #Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            #Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
            #Add-Content $report "<td bgcolor= 'Yellow' align=center>  <B>Not tested</B></td>" 
        
        }
    }        
#}
Add-Content $report "</tr>"
############################################Close HTMl Tables###########################
Add-content $report  "</table>" 
Add-Content $report "</body>" 
Add-Content $report "</html>" 

#Diplay "Treatment completed, Please check results in $report code $errorcode"

# Change the errorcodes for Shinken

If(($errorcode -eq "0") -and ($Shinkenerrorcode -eq "0"))
{
    $Shinkenerrorcode = "0"
    write-host "All Checks are fine" -ForegroundColor Green
}Elseif($errorcode -eq "7"){$Shinkenerrorcode = "2"; write-host "Critical At least one Dcdiag check failed" -ForegroundColor Red
}Elseif($errorcode -eq "6"){$Shinkenerrorcode = "2"; write-host "Critical At least one service isn't started" -ForegroundColor Red
}Elseif($errorcode -eq "5"){$Shinkenerrorcode = "2"; write-host "Critical At least one AD flows isn't opened" -ForegroundColor Red
}Elseif($Shinkenerrorcode -eq "1"){$Shinkenerrorcode = "1"; write-host "Warning Check cannot be tested because ping failed" -ForegroundColor Yellow}

Exit $Shinkenerrorcode
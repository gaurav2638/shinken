###############################################################################################################################################
# Script Name : Check_Cyberark_Shinken.ps1
###############################################################################################################################################
# Version : 1.2
###############################################################################################################################################
# Description : This Script check the health status of Cyberark on Windows 2012 and later versions
# Usage example:
# .\Check_Cyberark_Shinken.ps1
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 2018/01/04, Guillaume Blois, First script version
# 0.2, 2018/01/08, Guillaume Blois, Add Vault even if it won't be used in a lot of cases, due to hardening.
# 1.0, 2018/01/08, Guillaume Blois, First Release
# 1.1, 2018/01/30, Guillaume Blois, change "Down" -or "Missing" per ("Down" -or "Missing")
# 1.2, 2018/05/03, Guillaume Blois, change ($Servicestatus -eq ("Down" -or "Missing")) per ($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing"))
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one of the Cyberark services isn't running!
# 2 : "Critical" Cyberark application on this server isn't operational!

# Others exit codes:
# 3 : Wrong Operating System version
# 4 : Powershell Rights has been redefined
# 5 : No Cyberark role detected.

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$FullComputername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
[INT]$global:ServiceNbr = "0"
[INT]$global:ServiceNbrfailed = "0"

$global:errorcode = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This function check if service is present and running or not
Function Check-Service
{
	param(
	#[Parameter(Mandatory=$true)]
	[String]$DisplayServiceName
	)
	If (Get-Service -DisplayName $DisplayServiceName -ErrorAction SilentlyContinue)
	{ 
       If ((Get-Service -DisplayName $DisplayServiceName).status -eq "running")
       {
            $global:Servicestatus = "Up"
            #Write-Warning "Service $DisplayServiceName is $Servicestatus"
	   }Else
       {
	        $global:Servicestatus = "Down"
            #Write-Warning "Service $DisplayServiceName is $Servicestatus"
            $global:failedServiceName=$DisplayServiceName
       }       
	}Else
    {
        $global:Servicestatus = "Missing"
        #Write-Warning "Service $DisplayServiceName is $Servicestatus"
	}
}

function Get-InstalledApps
# This function will loop through the applications installed and output one object for each Application with all its properties.
{
    
    
    foreach ($App in $Applications)
    {           
        $AppRegistryKey = $UninstallRegKey + "\\" + $App
        $AppDetails = $HKLM.OpenSubKey($AppRegistryKey)
        $AppGUID = $App
        $AppDisplayName = $($AppDetails.GetValue("DisplayName"))
        $AppVersion = $($AppDetails.GetValue("DisplayVersion"))
        $AppPublisher = $($AppDetails.GetValue("Publisher"))
        $AppInstalledDate = $($AppDetails.GetValue("InstallDate"))
        #$AppUninstall = $($AppDetails.GetValue("UninstallString"))
        if(!$AppDisplayName) { continue }
        $OutputObj = New-Object -TypeName PSobject
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppName -Value $AppDisplayName
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppVersion -Value $AppVersion
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppVendor -Value $AppPublisher
        $OutputObj | Add-Member -MemberType NoteProperty -Name InstalledDate -Value $AppInstalledDate
        $OutputObj | Add-Member -MemberType NoteProperty -Name UninstallKey -Value $AppUninstall
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppGUID -Value $AppGUID
        if ($RegistryView -eq 'Registry32')
        {
            $OutputObj | Add-Member -MemberType NoteProperty -Name Arch -Value '32'
        } else {
            $OutputObj | Add-Member -MemberType NoteProperty -Name Arch -Value '64'
        }
        $OutputObj
    }
}


###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

# Checking Windows version

If($OSVersion -match "6.2|3"){import-module ServerManager}
Else
{
  Write-Warning "This Operating System is not supported for monitoring"
  $global:errorcode = "3"
  Exit $errorcode  
}

# Checking/set Powershell status

$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)) 
{
  #Write-Warning "Script Execution is disabled. Enabling it now"
  Set-ExecutionPolicy $Policy -Force
  Write-Warning "Please Re-Run this script in a new powershell environment"
  $global:errorcode = "4"
  Exit $errorcode
}


# Variables to test if Cyberark roles exist
#write-output "Retrieve all installed applications and search for CyberArk programs."

$UninstallRegKey="SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
$RegistryViews = @('Registry32','Registry64')

foreach ( $RegistryView in $RegistryViews )
{
    # Get the reg key(s) where add/remove program information is stored.
    $HKLM = [microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine',$computer,$RegistryView)
    $UninstallRef = $HKLM.OpenSubKey($UninstallRegKey)
    $Applications = $UninstallRef.GetSubKeyNames()

    # Now we have the registry locations, call the function which will enumerate the applications on this PC
    [Array]$apps = Get-InstalledApps
    If($Apps)
    {
	    # Get all programs names
	    ForEach ($App in $Apps) 
	    {
            $Cyberapp = ($App | Where-Object {$_.AppVendor -Match "Cyber"}).AppName
            if ($Cyberapp -Match "CyberArk Central Policy Manager")
            {
                $global:CPMroleinstalled = "Yes"
            }Elseif ($Cyberapp -Match "Cyberark Privileged Session Manager")
            {
                $global:PSMroleinstalled = "Yes"
            }Elseif ($Cyberapp -Match "Password Vault Web Access")
            {
                $global:PVWAroleinstalled = "Yes"
            }Elseif ($Cyberapp -match "PrivateArk Client") #}Elseif ($Cyberapp -like "CybeArk Digital Vault")
            {
                $global:Vaultroleinstalled = "Yes"
            }
            if ($Cyberapp -Match "CyberArk Vault Disaster Recovery")
            {
                $global:VaultDRroleinstalled = "Yes"
            }
        }
    }
}

#$global:CPMrole = Get-Service -Name "Cyberark Password Manager" -ErrorAction SilentlyContinue
#$global:PSMrole = Get-Service -Name "Cyber-Ark Privileged Session Manager" -ErrorAction SilentlyContinue
#$global:PVWArole = Get-Service -Name "CyberArk Scheduled Tasks" -ErrorAction SilentlyContinue


############ Check CPM services status ############ 
    if($CPMroleinstalled -eq "Yes")
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 2
        Check-Service "Cyberark Password Manager"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
        Check-Service "Cyberark Central Policy Manager Scanner"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
     }

############ Check PSM service status ############ 
    if($PSMroleinstalled -eq "Yes")
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Cyber-Ark Privileged Session Manager"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
     }

############ Check PVWA service status ############ 
    if($PVWAroleinstalled -eq "Yes")
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "CyberArk Scheduled Tasks"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
        Check-Service "World Wide Web Publishing Service"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                $global:errorcode = "1"
            }
        import-module WebAdministration
        $Sitesnames = (Get-Website -ErrorAction SilentlyContinue) | foreach-object -process {$_.state}
        If ($Sitesnames -eq "Stopped"){$Servicestatus = "Down"}
        If($Servicestatus -eq "Down") 
        {
            #write-warning "Warning The PVWA site is down on this system"
            $global:errorcode = "1"
        }Else
        {
            import-module Webadministration
            $websites = get-website
            ForEach ($site in $websites)
            {
	            $sitename = $Websites.name
	            $PVWAsite = get-childitem IIS:\Sites\$sitename\ | where Name -match "PasswordVault"
 	            if (!($PVWAsite))
	            {
		            $global:errorcode = "1"
	            }              
            }

        }
     }

############ Check Vault service status ############ 
    if($Vaultroleinstalled -eq "Yes")
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "CyberArk Logic Container"
        If($Servicestatus -eq "Down" -or ($Servicestatus -eq "Missing")) 
            {
                if($VaultDRroleinstalled -eq "Yes")
                {
                    [INT]$global:ServiceNbr= $ServiceNbr + 1
                    Check-Service "CyberArk Cluster Vault Manager"
                    if($Servicestatus -ne "up")
                    {
                        $global:errorcode = "1"
                        [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
                    }
                }
            }

        Check-Service "Cyber-Ark Hardened Windows Firewall"
        If($Servicestatus -ne "Missing")
        {
            [INT]$global:ServiceNbr= $ServiceNbr + 1
            If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
        }         
     }
    
############ Check Cyberark whole Service presence ############
if($ServiceNbr -eq "0")
{
  #Write-Warning "CyberArk programs are not found on this System"
  $global:errorcode = "5"
}Elseif($ServiceNbr -eq $ServiceNbrfailed)
{
    $global:errorcode = "2"
}


# Change the errorcodes for Shinken

If($errorcode -eq "0")
{
    $global:Shinkenerrorcode = "0"
    write-host "All Checks are fine" -ForegroundColor Green
}Elseif($errorcode -eq "1"){$global:Shinkenerrorcode = "1"; write-host "Warning At least one service or Website isn't started" -ForegroundColor Yellow
}Elseif($errorcode -eq "5"){$global:Shinkenerrorcode = "1"; write-host "Warning Cyberark is not installed on this System" -ForegroundColor Yellow
}Elseif($errorcode -eq "2"){$global:Shinkenerrorcode = "2"; write-host "Critical Cyberark is not working" -ForegroundColor Red
}

Exit $Shinkenerrorcode
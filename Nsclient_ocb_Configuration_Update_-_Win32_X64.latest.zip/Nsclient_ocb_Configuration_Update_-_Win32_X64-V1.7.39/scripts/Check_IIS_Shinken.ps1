###############################################################################################################################################
# Script Name : Check_IIS_Shinken.ps1
###############################################################################################################################################
# Version : 1.0
###############################################################################################################################################
# Description : This Script check the Internet Information services roles and features are running, including FTP Service.
# Usage example:
# .\Check_IIS_Shinken.ps1
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 06/2016, Guillaume Blois, First script version
# 1.0, 06/2016, Guillaume Blois, First Release

###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one of the IIS service isn't running!
# 2 : "Critical" IIS isn't operational!

# Others exit codes:
# 3 : Wrong Operating System version
# 4 : Powershell Rights has been redefined
# 5 : IIS role is not installed.

###############################################################################################################################################
# Script Parameters Declaration 
###############################################################################################################################################

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$powershellversion = $host.Version.major
$global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
$global:Computername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$appCmd = "C:\windows\system32\inetsrv\appcmd.exe"
$global:errorcode = "0"
$global:Shinkenerrorcode = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This Function Display a message with the date and color if need it
Function Display 
{
	param (
	[String] $Text,
	[String] $Type
	)
	$date = Get-Date
	Switch($Type)
	{
		"OK" {Write-Host "$date - $text" -nonewline; Write-Host " [Success]" -ForegroundColor Green}
		"NOK" {Write-Host "$date - $text" -nonewline; Write-Host " [Fail]" -ForegroundColor Red}
		"WARNING" {Write-Warning "$date - $text"}
		DEFAULT {Write-Host "$date - $text"}
	}
}

### This function check if service is present and running or not
Function Check-Service
{
	param(
	#[Parameter(Mandatory=$true)]
	[String]$DisplayServiceName
	)
	If (Get-Service -DisplayName $DisplayServiceName -ErrorAction SilentlyContinue)
	{ 
       If ((Get-Service -DisplayName $DisplayServiceName).status -eq "running")
       {
            $global:Servicestatus = "Up"
            #Display "Service $DisplayServiceName is $Servicestatus"
	   }Else
       {
	        $global:Servicestatus = "Down"
            #Display "Service $DisplayServiceName is $Servicestatus"
            $global:failedServiceName=$DisplayServiceName
       }       
	}Else
    {
        $global:Servicestatus = "Missing"
        #Display "Service $DisplayServiceName is $Servicestatus"
	}
}

###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

# Checking Windows version

If($OSVersion -match "6.0|1|2|3"){}
Else
{
  Display "This Operating System is not supported for monitoring"
  $global:errorcode =  = "3"
  Exit $global:errorcode
}

# Checking/set Powershell status

$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)) 
{
  #Display "Script Execution is disabled. Enabling it now" "Warning"
  Set-ExecutionPolicy $Policy -Force
  Display "Please Re-Run this script in a new powershell enviroment" "Warning"
  $global:errorcode =  = "4"
  Exit $global:errorcode
}

If ($OSVersion -gt "6.1")
{
    import-module ServerManager

    # Variables to test if IIS role exist
    $global:IISrole = Get-WindowsFeature -Name Web-Server

    ############ Check IIS presence ############ 
        if($IISrole.Installed)
        {
            Check-Service "World Wide Web Publishing Service"
            If($Servicestatus -eq "Down") 
            {
                $global:Shinkenerrorcode = "2"
            }
            Check-Service "Microsoft FTP Service"
            import-module WebAdministration
            $Sitesnames = (Get-Website -ErrorAction SilentlyContinue) | foreach-object -process {$_.state}
            If ($Sitesnames -eq "Stopped"){$Servicestatus = "Down"}
            If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
            }
            
        }Else
        {
            Display "IIS role isn't installed" "NOK"
            $global:errorcode =  = "5"
            Exit $global:errorcode
        }
}Else
{
    Check-Service "World Wide Web Publishing Service"
    If($Servicestatus -eq "Missing")
    {
        Display "IIS role isn't installed" "NOK"
        $global:errorcode =  = "5"
        Exit $global:errorcode
    }ElseIf($Servicestatus -eq "Down") 
    {
        $global:Shinkenerrorcode = "2"
    }
    Check-Service "Microsoft FTP Service"

    [string]$listsites= & $appCmd list site
    if($listsites.Contains("state:Stopped")){$global:Servicestatus="Down"}

    #[Void][Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration")
    #$sm = New-Object Microsoft.Web.Administration.ServerManager
    #foreach($site in $sm.Sites)
    #{
    #    Write-Output ($site.state)
    #}

    If($Servicestatus -eq "Down") 
    {
        $global:errorcode = "1"
    }
}

# Collect IIS version
$global:IISversion=(get-itemproperty HKLM:\SOFTWARE\Microsoft\InetStp\ -ErrorAction SilentlyContinue | select setupstring,versionstring ).SetupString
        
# Change the errorcodes for Shinken

If(($errorcode -eq "0") -and ($Shinkenerrorcode -eq "0"))
{
    $Shinkenerrorcode = "0"
    write-host "All Checks are fine $IISversion running" -ForegroundColor Green
}Elseif($Shinkenerrorcode -eq "2"){$Shinkenerrorcode = "2"; write-host "Critical $IISversion Service isn't running" -ForegroundColor Red
}Elseif($errorcode -eq "1"){$Shinkenerrorcode = "1"; write-host "Warning At least the Service $failedServiceName is stopped" -ForegroundColor Yellow}

Exit $Shinkenerrorcode
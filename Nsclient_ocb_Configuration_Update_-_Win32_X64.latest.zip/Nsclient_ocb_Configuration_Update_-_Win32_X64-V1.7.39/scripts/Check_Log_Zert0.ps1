<#
.EXAMPLE
  PS> Get-VMConfigChanges -vm $VM
.EXAMPLE
  PS> Get-VMConfigChanges -vm $VM -hours 8
#>

$directory = $args[1];
#echo $directory
$directory_1 = $directory -replace '/','\'
#echo $directory_1

$lists = $args[0].split("_");
 
foreach ($item in $lists) {

#$result = Get-Content c:\MonitoringScript\alert.xml | Select-String -CaseSensitive -pattern $item
$result = Get-Content $directory_1 | Select-String -CaseSensitive -pattern $item
if ($result -ne $null)
{
	switch ($item)
		{
		"VPG0005" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGProtectionGroupError "} 				
		"VPG0015" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGRessourcePoolInsufficientError "}	
		"VPG0016" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGRessourcePoolMissingError "}		
		"VPG0010" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGRpoError "}				
		"VPG0009" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGRpoWarning "}				
		"VPG0027" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VPGUnprotectedVMsError "}
		"VRA0024" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRAGhostVm "} 				
		"VRA0001" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRAUninstalledHost "}	
		"VRA0029" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRABallooning "}		
		"VRA0028" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRAPoweredOff "}
		"VRA0008" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0009" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0010" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0011" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0012" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0013" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRATargetVolume "}				
		"VRA0006" {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " VRAToVraConnection "}		
		default   {$ErrorCheckLog = $ErrorCheckLog + ";" + $item + " ;" }
		}
		 
#$ErrorCheckLog = $ErrorCheckLog + " " + $item
}
else
{
$ErrorCheckLog = $ErrorCheckLog
}
}

if ($ErrorCheckLog -ne $null)
{
echo "VCOPS KO - $ErrorCheckLog" 
exit 2
}
else
{
echo "VCOPS OK - $ErrorCheckLog" 
exit 0
}




###############################################################################################################################################
# Script Name : Check_MAPDISK_Shinken.ps1
###############################################################################################################################################
# Version : 1.2
###############################################################################################################################################
# Description : This Script check the health status of mapped logical disks on Windows 2008 and later versions
# Usage example:
# .\Check_MAPDISK_Shinken.ps1
# .\Check_MAPDISK_Shinken.ps1 -$MAPlist (To obtain the Mapped drives list)
# .\Check_MAPDISK_Shinken.ps1 -DriveID "H:" (To obtain the H: mapped drive informations/status)
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 2018/03/16, Guillaume Blois, First script version
# 1.0, 2018/03/19, Guillaume Blois, First Release
# 1.1, 2018/03/28, Guillaume Blois, update to be less verbose for Shinken compatibility
# 1.2, 2018/06/05, Guillaume Blois, Add Mandatory credentials
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one mapped drive is almost full (-5% of free space available)! 
# 2 : "Critical" At least one mapped drive isn't reachable or drive full!

# Others exit codes:
# 3 : Wrong Operating System version
# 4 : Credentials aren't provided to check the Mapped drive(s)
# 5 : Wrong Drive format provided, must be "[DRIVELETTER]:" format, for example "E:" "X:"...
# 6 : Drive unavailable on this system

################################################################################
#			 Script Parameters Declaration 
################################################################################

param(
    [Switch]$MAPlist = $False,
    [String]$username = "",
    [String]$password = "",
	[String]$driveID = ""
	)

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$FullComputername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
$global:errorcode = "0"
$global:warningcode = "0"
$global:Redcode = "0"
$global:i = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

function Get-Mappeddrives
# This function will loop the visible mapped drives and output one object for each drive property.
{

#$strComputer = "." 
 
$colItems = get-wmiobject -class "Win32_MappedLogicalDisk" -namespace "root\CIMV2" #` -computername $strComputer 

foreach ($objItem in $colItems) 
    { 

        $OutputObj = New-Object -TypeName PSobject

        #$OutputObj | Add-Member -MemberType NoteProperty -Name Access -Value $objItem.Access
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Availability -Value $objItem.Availability
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Block_Size -Value $objItem.BlockSize
        $OutputObj | Add-Member -MemberType NoteProperty -Name Caption -Value $objItem.Caption
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Compressed -Value $objItem.Compressed
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Configuration_Manager_Error_Code -Value $objItem.ConfigManagerErrorCode
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Configuration_Manager_User_Configuration -Value $objItem.ConfigManagerUserConfig
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Creation_Class_Name -Value $objItem.CreationClassName
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Description -Value $objItem.Description
        $OutputObj | Add-Member -MemberType NoteProperty -Name Device_ID -Value $objItem.DeviceID
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Error_Cleared -Value $objItem.ErrorCleared
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Error_Description -Value $objItem.ErrorDescription
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Error_Methodology -Value $objItem.ErrorMethodology
        $OutputObj | Add-Member -MemberType NoteProperty -Name File_System -Value $objItem.FileSystem
        $OutputObj | Add-Member -MemberType NoteProperty -Name Free_Space -Value $objItem.FreeSpace
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Installation_Date -Value $objItem.InstallDate
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Last_Error_Code -Value $objItem.LastErrorCode
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Maximum_Component_Length -Value $objItem.MaximumComponentLength
        $OutputObj | Add-Member -MemberType NoteProperty -Name Name -Value $objItem.Name
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Number_Of_Blocks -Value $objItem.NumberOfBlocks
        #$OutputObj | Add-Member -MemberType NoteProperty -Name PNP_Device_ID -Value $objItem.PNPDeviceID
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Power_Management_Capabilities -Value $objItem.PowerManagementCapabilities
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Power_Management_Supported -Value $objItem.PowerManagementSupported
        $OutputObj | Add-Member -MemberType NoteProperty -Name Provider_Name -Value $objItem.ProviderName
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Purpose -Value $objItem.Purpose
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Quotas_Disabled -Value $objItem.QuotasDisabled
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Quotas_Incomplete -Value $objItem.QuotasIncomplete
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Quotas_Rebuilding -Value $objItem.QuotasRebuilding
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Session_ID -Value $objItem.SessionID
        $OutputObj | Add-Member -MemberType NoteProperty -Name Size -Value $objItem.Size
        $OutputObj | Add-Member -MemberType NoteProperty -Name Status -Value $objItem.Status
        $OutputObj | Add-Member -MemberType NoteProperty -Name Status_Information -Value $objItem.StatusInfo
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Supports_Disk_Quotas -Value $objItem.SupportsDiskQuotas
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Supports_File-Based_Compression -Value $objItem.SupportsFileBasedCompression
        #$OutputObj | Add-Member -MemberType NoteProperty -Name System_Creation_Class_Name -Value $objItem.SystemCreationClassName
        #$OutputObj | Add-Member -MemberType NoteProperty -Name System_Name -Value $objItem.SystemName
        $OutputObj | Add-Member -MemberType NoteProperty -Name Volume_Name -Value $objItem.VolumeName
        #$OutputObj | Add-Member -MemberType NoteProperty -Name Volume_Serial_Number -Value $objItem.VolumeSerialNumber

        $OutputObj
    }
}


function Get-mapDsizestatus($mapdrivename)
# This function will output the specified drive spacestatus
{
    If($mappeddrive.size)
    {
        
        $checkdrive = cmd /c dir $mapdrivename '2>&1'
        # redirect error stream (2) to success stream (1): Note the single quotes around 2>&1, which ensures that the redirection is passed to cmd.exe rather than being interpreted by PowerShell.
        
        if(!($checkdrive -like "The system cannot find the path specified."))
	    {
		    $Freespace = ((cmd /c dir $mapdrivename)[-1] -replace '.+?([\d,]+) bytes free','$1' -replace '\D') / 1gb  
        }Else
	    {
		    $Freespace = ($mappeddrive.Free_Space)/ 1gb   
        }
        $Freespace = [math]::Round($Freespace,2)
        $sizeround = [String]$Freespace + " Gbits"

        $totalspace = $mappeddrive.size
        $totalspace = [math]::Round(($totalspace / 1gb),2)        
        $freePercent = [math]::Round((($Freespace/$totalspace)*100),0)

        If ($availablespace -eq "0")
        {
            $color = "Red"            
            $global:fullmappeddrive = $mapdrivename
            $global:redcode = "2"

        }Elseif($freePercent -lt "5")
        {
            $color = "Yellow"            
            $global:fullmappeddrive = $mapdrivename
            $global:warningcode = "1"

        }Else
        {
            $color = "Green"
            $global:errorcode = "0"                       
        }

        If ($i -eq "1" -or $driveID -ne "")
        {
            $global:spacemsg = "$mapdrivename $freePercent% free space: $sizeround/$totalspace Gbits"
            
        }Else
        {
            write-host "The mapped Drive $mapdrivename has $sizeround available of $totalspace Gbits, which represents $freePercent% free" -ForegroundColor $color
        }

    }Else
    {
        If ($i -eq "1" -or $driveID -ne "")
        {
            $global:spacemsg = ": $mapdrivename"
            
        }Else
        {
            write-host "Mapped drive $mapdrivename size status is not reachable" -ForegroundColor Red
        }
        $global:errorcode = "2"
    }
}


###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls
# Checking Windows version
If(!($OSVersion -match "6.0|1|2|3"))
{
  Write-Warning "This Operating System is not supported for monitoring"
  $global:errorcode = "3"
  Exit $errorcode  
}

# Credentials are mandatory to check the mapped drive(s)
If($username -eq "" -or $password -eq "")
{
    write-warning  "Please provide the username and password who mapped the drive(s)"
    $global:errorcode = "4"
    Exit $errorcode
 }Else
 {
    $Global:credentials = New-Object System.Management.Automation.PsCredential($username, (ConvertTo-SecureString $password -AsPlainText -Force))
}

# Execute the Mapped disks function to check if mapped disks exist
$global:mappeddrive = Get-Mappeddrives -Credential $credentials
If($mappeddrive.caption -ne $null)
{
	# list all mapped drives in a list
    $Mappeddriveslist = @() 

    if ($driveID -ne "")
    {
        If(($driveID.Contains(":")) -and (!($driveID.Contains("\"))) -and ($driveID.length -eq "2"))
        {            
            $mapdrivename = $driveID
            $mappeddrive = $mappeddrive | Where-Object {$_.Caption -Match $mapdrivename}
            If($mappeddrive)
            {
                Get-mapDsizestatus($mapdrivename) -Credential $credentials
            }Else
            {
                Write-Warning "Mapped Drive doesn't exist, please provide a good one"
                $global:errorcode = "6"
                Exit $errorcode
            }
        }Else
        {
            Write-Warning "Please provide a good format, Drive ID should be '[DRIVELETTER]:' "
            $global:errorcode = "5"
            Exit $errorcode
        }
    }Else
    {
        ForEach ($mappeddrive in $mappeddrive) 
	    {
            $global:i = $i+1
            $mapdrivename = $mappeddrive.Caption
            $mapdrivetree = $mappeddrive.Provider_Name
            If ($MAPlist -eq $true)
            {
                $line = New-Object -TypeName PSobject
                $line | Add-Member -MemberType NoteProperty -Name drive -Value $mapdrivename
                $line | Add-Member -MemberType NoteProperty -Name tree -Value $mapdrivetree
                $Mappeddriveslist+=$line 

            }Else
            {
                Get-mapDsizestatus($mapdrivename) -Credential $credentials
            }      
        }

        If ($MAPlist -eq $true)
        {
            #$Mappeddriveslist
            ForEach ($drive in $Mappeddriveslist)
            {
                $drivetree = $drive.drive + " (" + $drive.tree + ")"
		        Write-host $drivetree
            }            
            $global:errorcode = "0"
            Exit $errorcode
        }
    }
}Else
{
    Write-Warning "No mapped drives on this computer"
    $global:errorcode = "0"
    Exit $errorcode
}

# Change the errorcodes for Shinken
If($redcode -eq "2")
{
    $global:errorcode = "2"; write-host "Warning the mapped Drive $fullmappeddrive is full" -ForegroundColor Red
    $global:Shinkenerrorcode = "2"

}Elseif($warningcode -eq "1")
{
    $global:errorcode = "1"; write-host "Warning the mapped Drive $fullmappeddrive is almost full $spacemsg" -ForegroundColor Yellow
    $global:Shinkenerrorcode = "1"


}ElseIf($errorcode -eq "0")
{
    write-host "All Checks are fine $spacemsg" -ForegroundColor Green
    $global:Shinkenerrorcode = "0"    
}Elseif($errorcode -eq "2"){$global:Shinkenerrorcode = "2"; write-host "Critical At least one mapped drive isn't reachable$spacemsg" -ForegroundColor Red
}

Exit $Shinkenerrorcode
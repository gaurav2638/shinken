###############################################################################################################################################
# Script Name : Check_RDS_Shinken.ps1
###############################################################################################################################################
# Version : 1.1
###############################################################################################################################################
# Description : This Script check the health status of RDS Services on Windows 2008-R2 and later versions
# Usage example:
# .\Check_RDS_Shinken.ps1
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 2018/01/03, Guillaume Blois, First script version
# 0.2, 2018/01/04, Guillaume Blois, update the error codes and tests in different RDS environements
# 1.0, 2018/01/05, Guillaume Blois, First Release
# 1.1, 2018/04/17, Guillaume Blois, delete the broker part which requiered elevated rights
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one of the RDS services isn't running!
# 2 : "Critical" RDS isn't operational!

# Others exit codes:
# 3 : Wrong Operating System version
# 4 : Powershell Rights has been redefined
# 5 : No RDS role detected.
# 6 : There isn't any RD hosts Serversin this broker. 

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$FullComputername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
[INT]$global:ServiceNbr = "0"
[INT]$global:ServiceNbrfailed = "0"

# Variables to picked up the configuration
$global:Collections = ""
$global:RDservers = ""
$global:Remoteapps = ""

$global:errorcode = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This function check if service is present and running or not
Function Check-Service
{
	param(
	#[Parameter(Mandatory=$true)]
	[String]$DisplayServiceName
	)
	If (Get-Service -DisplayName $DisplayServiceName -ErrorAction SilentlyContinue)
	{ 
       If ((Get-Service -DisplayName $DisplayServiceName).status -eq "running")
       {
            $global:Servicestatus = "Up"
            #Write-Warning "Service $DisplayServiceName is $Servicestatus"
	   }Else
       {
	        $global:Servicestatus = "Down"
            #Write-Warning "Service $DisplayServiceName is $Servicestatus"
            $global:failedServiceName=$DisplayServiceName
       }       
	}Else
    {
        $global:Servicestatus = "Missing"
        #Write-Warning "Service $DisplayServiceName is $Servicestatus"
	}
}


###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

# Checking Windows version

If($OSVersion -match "6.1|2|3"){import-module ServerManager}
Else
{
  Write-Warning "This Operating System is not supported"
  $global:errorcode = "3"  
  Exit $errorcode
}

# Checking/set Powershell status

$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)) 
{
  #Write-Warning "Script Execution is disabled. Enabling it now"
  Set-ExecutionPolicy $Policy -Force
  #Write-Warning "Please Re-Run this script in a new powershell environment"
  $global:errorcode = "4"
  Exit $errorcode
}

If($OSVersion -gt "6.2"){import-module RemoteDesktop}

# Variables to test if RDS roles exist
$global:RDSHrole = Get-WindowsFeature -Name RDS-RD-Server -ErrorAction SilentlyContinue
$global:RDSLrole = Get-WindowsFeature -Name RDS-Licensing -ErrorAction SilentlyContinue
$global:RDCBrole = Get-WindowsFeature -Name RDS-Connection-Broker -ErrorAction SilentlyContinue
$global:RDWArole = Get-WindowsFeature -Name RDS-Web-Access -ErrorAction SilentlyContinue
$global:RDGWrole = Get-WindowsFeature -Name RDS-Gateway -ErrorAction SilentlyContinue
$global:RDVHrole = Get-WindowsFeature -Name RDS-Virtualization -ErrorAction SilentlyContinue

############ Check RDS-SESSION-HOST presence ############ 
    if($RDSHrole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Services"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
     }
    
############ Check RDS-Licensing feature presence ############ 
    if($RDSLrole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Licensing"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
    }
    
############ Check RDS-Connection-Broker presence ############ 
    if($RDCBrole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Connection Broker"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }<#Elseif($OSVersion -match "6.2|3")
                {
                    if(Get-RDConnectionBrokerHighAvailability -ErrorAction SilentlyContinue)
                    {   
                        $global:HAserver = (Get-RDConnectionBrokerHighAvailability).ActiveManagementserver
                        if($HAserver -eq $FullComputername)
                        {
                            $global:Collections = (Get-RDSessionCollection -ErrorAction SilentlyContinue).CollectionName
                            if(!($global:RDservers = (Get-RDServer -ErrorAction SilentlyContinue).server)){$global:errorcode = "6"}
                            $HAsql_splitted = (((Get-RDConnectionBrokerHighAvailability -ErrorAction SilentlyContinue).databaseconnectionstring).split(";"))[1]
                            $HAsql = ($HAsql_splitted.split("="))[1]                  
                        }
                        Else
                        {
                            if(!($global:RDservers = (Get-RDConnectionBrokerHighAvailability -ErrorAction SilentlyContinue).Connectionbroker)){$global:errorcode = "6"}
                            $HAsql_splitted = (((Get-RDConnectionBrokerHighAvailability -ErrorAction SilentlyContinue).databaseconnectionstring).split(";"))[1]
                            $HAsql = ($HAsql_splitted.split("="))[1]  
                        }
                    }
                    Else    
                    {    
                        $global:Collections = (Get-RDSessionCollection -ErrorAction SilentlyContinue).CollectionName
                        if(!($global:RDservers = (Get-RDServer -ErrorAction SilentlyContinue).server)){$global:errorcode = "6"}
                        $HAsql = "No Ha"
                    }

                }
                #>
    }
    
############ Check RDS-Web-Access presence ############ 
    if($RDWArole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "RemoteApp and Desktop Connection Management"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
        Check-Service "World Wide Web Publishing Service"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
            }
        import-module WebAdministration
        $Sitesnames = (Get-Website -ErrorAction SilentlyContinue) | foreach-object -process {$_.state}
        If ($Sitesnames -eq "Stopped"){$Servicestatus = "Down"}
        If($Servicestatus -eq "Down") 
        {
            #write-warning "Warning The RDWebAccess site is down on this system"
            $global:errorcode = "1"
        }

        if($OSVersion -match "6.2|3")
        {
            $global:Remoteapps = (Get-RemoteApp -ErrorAction SilentlyContinue).displayname
        }
    }

############ Check RDS-Gateway presence ############ 
    if($RDGWrole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Gateway"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
    }
    
############ Check RDS-Virtual-Host presence ############ 
    if($RDVHrole.Installed)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Virtualization Host"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
    }

############ Check Remote Desktop Management Service (RMDS) Status ############ 
    if(get-service -name RDMS -ErrorAction SilentlyContinu)
    {
        [INT]$global:ServiceNbr= $ServiceNbr + 1
        Check-Service "Remote Desktop Management"
        If($Servicestatus -eq "Down") 
            {
                $global:errorcode = "1"
                [INT]$global:ServiceNbrfailed = $ServiceNbrfailed + 1
            }
    }
    
############ Check RDS Roles presence ############
if($ServiceNbr -eq "0")
{
  #Write-Warning "RDS not found on this System"
  $global:errorcode = "5"
}Elseif($ServiceNbr -eq $ServiceNbrfailed)
{
    $global:errorcode = "2"
}


# Change the errorcodes for Shinken

If($errorcode -eq "0")
{
    $global:Shinkenerrorcode = "0"
    write-host "All Checks are fine" -ForegroundColor Green
}Elseif($errorcode -eq "1"){$global:Shinkenerrorcode = "1"; write-host "Warning At least one service or Website isn't started" -ForegroundColor Yellow
}Elseif($errorcode -eq "5"){$global:Shinkenerrorcode = "1"; write-host "Warning RDS is not installed on this System" -ForegroundColor Yellow
}Elseif($errorcode -eq "6"){$global:Shinkenerrorcode = "2"; write-host "Critical No RD Session Hosts detected on this broker" -ForegroundColor Red
}Elseif($errorcode -eq "2"){$global:Shinkenerrorcode = "2"; write-host "Critical RDS is not working" -ForegroundColor Red
}

Exit $Shinkenerrorcode
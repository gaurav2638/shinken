﻿###############################################################################################################################################
# Script Name : Check_SophosConsoleStatus.ps1
###############################################################################################################################################
#Version : "2.3"
###############################################################################################################################################
# Description : This Script check the health status of Sophos Enterprise Console
# Usage example:
# .\Check_SophosConsoleStatus.ps1
#
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 2016/05, Guillaume Blois, pre-release
# 1.0, 2016/05, Guillaume Blois, First script version
# 1.1, 2019/03/18, Guillaume Blois, update to be centralized as Console monitoring instead of agent monitoring
# 1.2, 2019/04/16, Guillaume Blois, delete "Sql-presence" function, update with last "Endpoint-status.ps1" functions, add "Shinken" parameter
# 1.3, 2019/04/18, Guillaume Blois, delete processor check, change the variable "sqlconnection" to be reuse more simply, add credentials, update errors detected
# 1.4, 2019/04/23, Guillaume Blois, add a Console Update date comparison + more console information + change script name
# 1.5, 2019/04/24, Guillaume Blois, add SQL and Console flows checks, move sql credentials and databaseusername check
# 1.6, 2019/04/25, Guillaume Blois, Change the Windows credentials to plain text SQL credentials
# 1.7, 2019/04/26, Guillaume Blois, Add a function Get-SqlDataTable2
# 1.8, 2021/05/25, Guillaume Blois, rebuilt functions to better detect Console and SQL informations (Copy from last Endpoints_status.ps1 code script)
# 1.9, 2021/06/01, Guillaume Blois, change quotas alerts for Shinken
# 2.0, 2021/06/02, Guillaume Blois, Rebuild $LastSECUpdate comparison with day date
# 2.1, 2021/07/01, Guillaume Blois, increase default sql timeout in order to retrieve all the data for Sophos consoles + hide errors when shinken is set
# 2.2, 2021/07/02, Guillaume Blois, Update get-sqldatatable to use credentials always
# 2.3, 2021/07/07, Guillaume Blois, Change credentials provisioning for shinken compatibility
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok"        : Console is Ok and Sophos agents are well from the console view.
# 1 : "Warning"   : A certain number agents waiting a non critical action, someone must check the status.
# 2 : "Critical"  : Too much Sophos agents have problems (Communication failure , malware detected ...), an intervention MUST BE DONE ASAP.

###############################################################################################################################################
#			 Script Parameters Declaration 
###############################################################################################################################################

param(
	[Switch]$Shinken = $False,           # Switch to be used for Shinken monitoring
    [String]$username = "",             # User for Database access
    [String]$password = ""              # Password for Database access
	)

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$powershellversion = $host.Version.major
$global:Computername = $env:computerName
$global:ExitCode = 0
$global:Endpointlist = $null
$global:rebootneeded = $null
$global:failure = $false
$global:Malwaredetected = 0
$global:Onaccessdeactivated = 0
$global:NotUptoDate = 0
$global:rebootpending = 0
$global:errordetected = 0
$global:dbpath = "HKLM:\SOFTWARE\Wow6432Node\Sophos\EE\Management Tools\"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This Function Display a message with the date and color if need it
Function Display 
{
	param (
	[String] $Text,
	[String] $Type
	)
	$date = Get-Date

    if($shinken -eq $false)
    {
        Switch($Type)
	    {
         	"OK"{Write-Host "$date - $text" -nonewline;Write-Host " [Success]" -ForegroundColor Green}
		    "NOK" {Write-Host "$date - $text" -nonewline; Write-Host " [Wrong]" -ForegroundColor Red;$global:badmessage = $text;$global:failure=$true}
		    "WARNING" {Write-Host "$date - $text" -nonewline;Write-Host " [Warning]" -ForegroundColor Yellow;$global:warningmessage = $text}
		    DEFAULT {Write-Host "$date - $text"}
	    }

    }Else
    {
        Switch($Type)
	    {
            "OK"{}
		    "NOK" {$global:badmessage = $text; $global:failure=$true}
		    "WARNING" {$global:warningmessage = $text}
        }
    }
}


### This function end the script properly
Function EndScript
{
	param (
	[Int] $ExitCode
	)
    If($ExitCode -eq "0" -And $failure -eq $false)
    {
        Write-Host "OK: Sophos console and agents are working properly" -ForegroundColor Green
    }Elseif($failure -eq $true -or $ExitCode -eq "2")
    {
            Write-Host "CRITICAL: $badmessage" -ForegroundColor red
    }Else
    {
        Write-Host "WARNING: $warningmessage" -ForegroundColor Yellow
    }

    remove-job *

    If($Shinken -eq $False)
    {
        Write-Host "#######################################################################`n---> End of Check_SophosConsoleStatus.ps1 script`n#######################################################################"
        Stop-Transcript
    }
	exit ($ExitCode)
}

### This Function check the connectivity to the console server 
Function Check-ServerConnectivity
{
	param(
	[String]$Server,
	[Int]$Port
	)
	# Create a Net.Sockets.TcpClient object to use for
        # checking for open TCP ports.
        $Socket = New-Object Net.Sockets.TcpClient
                
        # Suppress error messages
        $ErrorActionPreference = 'SilentlyContinue'
        
        # Try to connect
        $Socket.Connect($Server, $Port)
        
        # Make error messages visible again
        $ErrorActionPreference = 'Continue'
        
        # Determine if we are connected
        if ($Socket.Connected) 
		{
            $Socket.Close()
        }Else
		{
            $global:PORTScheck="$false"
        }
        
        # Resetting the variable
        $Socket = $null
}

### This function check if sophos console components are presents and running.
Function Sophosmgnt-presence
{
    # Check Management Serveur presence
    If (!(Get-Service "Sophos Management Service" -ErrorAction SilentlyContinue))
    {     
	    Display "$env:COMPUTERNAME is not a Sophos management Server!"
        If (!(Get-Service "SQL Server Browser" -ErrorAction SilentlyContinue))
        {
            Display "$env:COMPUTERNAME is also not a SQL Server!" "NOK";Exit $CON_ERROR
        }Else
        {
            Get-SQLInstance -ComputerName "$_" | ForEach {             
            If ($_.isClusterNode) 
            { 
                If (($list -notcontains $_.Clustername)) 
                { 
                    Get-SQLInstance -ComputerName $_.ClusterName 
                    $list += ,$_.ClusterName 
                } 
            }ElseIf($_.sqlinstance -like "*SOPHOS*")
        	{
        	 	If(!($_.ClusterName-like $NULL))
                {
                
                [String]$global:SQLServerName = $_.ClusterName
                [String]$global:instance = $_.ClusterName + "\" + $_.sqlinstance
                
                }Else
                {
                    [String]$global:SQLServerName = $env:COMPUTERNAME
                    [String]$global:instance = $env:COMPUTERNAME + "\" + $_.sqlinstance
                }
        	}
            }
            #Display "Found the instance name: $instance"
            [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")|Out-null
            $srv = New-Object 'Microsoft.SqlServer.Management.SMO.Server' "$instance"
            [String]$dbnametemp = $srv.Databases | select name | ? {$_.name -like "SOPHOS5*"}
            $global:DbName = (($dbnametemp.split("="))[1]).Trim("}")
            #Display "Found the Database Name: $dbname"
        }
    }Else
    {
        # get Database name and SQL server and instance names
        Set-ProcVariable
        Collect-dbinformations
    }
}

# This Function Get the processor type and set the right registry path of the database
Function Set-ProcVariable
{
    $Proc = Get-WmiObject win32_processor
    $Switchproc=$Proc.AddressWidth
    If ($Switchproc -eq "32")
    
        {
            $global:dbpath = "HKLM:\SOFTWARE\Sophos\EE\Management Tools\"
        }
        else
        {
            $global:dbpath = "HKLM:\SOFTWARE\Wow6432Node\Sophos\EE\Management Tools\"
        }
}

# This function Collect the Database informations
Function Collect-dbinformations
{
    
    $dbconnection = (get-itemproperty -path $dbpath -name DatabaseConnectionMS).DatabaseConnectionMS
    $line_splitted = $dbconnection.split(";")
    ForEach ($dbitem in $line_splitted)
    {
        if($dbitem.startswith("Database")){$global:dbname = ($dbitem.split("="))[1]}
        if($dbitem.startswith("Initial Catalog=")){$global:dbname = ($dbitem.split("="))[1]}
        if($dbitem.startswith("Server=")){$global:instance = ($dbitem.split("="))[1]}
        if($dbitem.startswith("Data Source=")){$global:instance = ($dbitem.split("="))[1]}        
    }

    $global:SQLServerName = ($instance.split("\"))[0]
       
    Display "The SQL Server name is $SQLServerName" "OK"
    Display "The SQL Server instance name is $instance" "OK"
    Display "The SQL Server Database name is $dbname" "OK"                                          

}     
 
# This function allow the user to perform a query that returns a table full of data
Function global:Get-SqlDataTable
{
    param(
        $requete,
        [STRING]$jobname
    )
    Invoke-Command -ScriptBlock {Start-Job -name $jobname -ScriptBlock {

            # Initially create the SqlConnection
            $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
            $SqlConnection.ConnectionString = "Data Source=$using:instance;Initial Catalog=$using:dbname;Trusted_Connection=True;" 

            $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
            $SqlCmd.CommandText = $using:requete
            $SqlCmd.Connection = $SqlConnection

            $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
            $SqlAdapter.SelectCommand = $SqlCmd
	        # increase command timeout
	        $SqlAdapter.SelectCommand.CommandTimeout = 1800;

            $DataSet = New-Object System.Data.DataSet
            $SqlAdapter.Fill($DataSet) 

            $SqlConnection.Close()
  
            return $DataSet.Tables[0]

        } -Credential $credential
    } | out-null
    
    $done = Invoke-Command -Command {Wait-Job -name $jobname}

}

# This function Retrieves SQL server information from a local or remote servers. Pulls all instances from a SQL server and detects if in a cluster or not.
Function Get-SQLInstance 
{  

    [cmdletbinding()] 
    Param (
        [parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('__Server','DNSHostName','IPAddress')]
        [string[]]$ComputerName = $env:COMPUTERNAME
    ) 
    Process {
        ForEach ($Computer in $Computername) {
            $Computer = $computer -replace '(.*?)\..+','$1'
            Write-Verbose ("Checking {0}" -f $Computer)
            Try { 
                $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Computer) 
                $baseKeys = "SOFTWARE\\Microsoft\\Microsoft SQL Server",
                "SOFTWARE\\Wow6432Node\\Microsoft\\Microsoft SQL Server"
                If ($reg.OpenSubKey($basekeys[0])) {
                    $regPath = $basekeys[0]
                } ElseIf ($reg.OpenSubKey($basekeys[1])) {
                    $regPath = $basekeys[1]
                } Else {
                    Continue
                }
                $regKey= $reg.OpenSubKey("$regPath")
                If ($regKey.GetSubKeyNames() -contains "Instance Names") {
                    $regKey= $reg.OpenSubKey("$regpath\\Instance Names\\SQL" ) 
                    $instances = @($regkey.GetValueNames())
					$instances = "MSSQL10_50.SOPHOS"									 
                } ElseIf ($regKey.GetValueNames() -contains 'InstalledInstances') {
                    $isCluster = $False
                    $instances = $regKey.GetValue('InstalledInstances')
                    #Display $instances
                } Else {
                    Continue
                }
                If ($instances.count -gt 0) { 
                    ForEach ($instance in $instances) {
                    #display $instance
                        $nodes = New-Object System.Collections.Arraylist
                        $clusterName = $Null
                        $isCluster = $False
                        $instanceValue = $regKey.GetValue($instance)
                        $instanceReg = $reg.OpenSubKey("$regpath\\$instanceValue")
                        If ($instanceReg.GetSubKeyNames() -contains "Cluster") {
                            $isCluster = $True
                            $instanceRegCluster = $instanceReg.OpenSubKey('Cluster')
                            $clusterName = $instanceRegCluster.GetValue('ClusterName')
                            $clusterReg = $reg.OpenSubKey("Cluster\\Nodes")                            
                            $clusterReg.GetSubKeyNames() | ForEach {
                                $null = $nodes.Add($clusterReg.OpenSubKey($_).GetValue('NodeName'))
                            }
                        }
                        $instanceRegSetup = $instanceReg.OpenSubKey("Setup")
                        Try {
                            $edition = $instanceRegSetup.GetValue('Edition')
                        } Catch {
                            $edition = $Null
                        }
                        Try {
                            $ErrorActionPreference = 'Stop'
                            #Get from filename to determine version
                            $servicesReg = $reg.OpenSubKey("SYSTEM\\CurrentControlSet\\Services")
                            $serviceKey = $servicesReg.GetSubKeyNames() | Where {
                                $_ -match "$instance"
                            } | Select -First 1
                            $service = $servicesReg.OpenSubKey($serviceKey).GetValue('ImagePath')
                            $file = $service -replace '^.*(\w:\\.*\\sqlservr.exe).*','$1'
                            $version = (Get-Item ("\\$Computer\$($file -replace ":","$")")).VersionInfo.ProductVersion
                        } Catch {
                            #Use potentially less accurate version from registry
                            $Version = $instanceRegSetup.GetValue('Version')
                        } Finally {
                            $ErrorActionPreference = 'Continue'
                        }
                        New-Object PSObject -Property @{
                            Computername = $Computer
                            SQLInstance = $instance
                            Edition = $edition
                            Version = $version
                            Caption = {Switch -Regex ($version) {
                                "^16" {'SQL Server 2016';Break}
                                "^14" {'SQL Server 2014';Break}
                                "^11" {'SQL Server 2012';Break}
                                "^10\.5" {'SQL Server 2008 R2';Break}
                                "^10" {'SQL Server 2008';Break}
                                "^9"  {'SQL Server 2005';Break}
                                "^8"  {'SQL Server 2000';Break}
                                Default {'Unknown'}
                            }}.InvokeReturnAsIs()
                            isCluster = $isCluster
                            isClusterNode = ($nodes -contains $Computer)
                            ClusterName = $clusterName
                            ClusterNodes = ($nodes -ne $Computer)
                            FullName = {
                                If ($Instance -eq 'MSSQLSERVER') {
                                    $Computer
                                } Else {
                                    "$($Computer)\$($instance)"
                                }
                            }.InvokeReturnAsIs()
                        }
                    }
                }
            } Catch { 
                Write-Warning ("{0}: {1}" -f $Computer,$_.Exception.Message)
            }  
        }   
    }
}

# This function recovered the list of computers that are pending a reboot
Function global:Get-rebootcomputers 
{
    $Reboot =   "USE $dbname    
                 SELECT DISTINCT
                 c.ID,
                 c.name
                 FROM 
                 computersanddeletedcomputers as c
                 INNER JOIN errors as e on e.id = c.lastauerroralert
                 WHERE
                 e.Number = 109 and e.outstanding = 1
                 ORDER BY c.name"

  
    # Run the Query
    Get-SqlDataTable -requete $reboot -jobname "rebootneeded"
    $global:rebootneeded = Receive-Job -name "rebootneeded" -keep 
}

Function Get-SECInformations
{
    param(
        [STRING]$jobname
    )

    $Query =   "USE $dbname
                SELECT
                d.LastName,
                d.SDDMVersion,
                d.StatusRefreshedAt,
                d.LastBinaryUpdate,
                d.LastDataUpdate
                FROM
                dbo.SDDMServers as d"
    
    # Run the Query                
    Get-SqlDataTable -requete $Query -jobname $jobname
    [STRING]$ConsoleServername = (Receive-Job -name $jobname -keep).LastName
    If($ConsoleServername -ne $null)
    {

        [STRING]$global:ConsoleServername = (Receive-Job -name $jobname -keep).LastName
        Display "The Sophos Enterprise Console server name is $ConsoleServername" "OK"
        [STRING]$global:updatemanagerversion = (Receive-Job -name $jobname -keep).SDDMVersion
        Display "The Sophos Update Manager version is $updatemanagerversion" "OK"
        [DATETIME]$global:LastSECUpdate = (Receive-Job -name $jobname -keep).LastBinaryUpdate


        #Check the update status of the Sophos Enterprise Console, and exit script if it is offset comparing of the day date
        if($LastSECUpdate -gt (Get-Date).AddHours(-24)) 
        {
            Display "The Update time of console $ConsoleServername is $LastSECUpdate" "OK"
        }Else
        {
            Display  "The Update time of console $ConsoleServername is too old: $LastSECUpdate" "NOK"
            $global:ExitCode = "2"
            EndScript($exitcode)
        }

    }
          
}

###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
If($Shinken -eq $False)
{
    # Create the transcript log file
    New-Item -type file -Name "Check_SophosConsoleStatus.log" -Force
    sleep 2
    Start-Transcript -Path "Check_SophosConsoleStatus.log" -Force
    cls

    Write-Host "#######################################################################`n---> Begin of Check_SophosConsoleStatus script`n#######################################################################"

}Else
{
    $ErrorActionPreference = 'SilentlyContinue'
}

# Check if the current server is really a Sophos management Server and/or a SQl server storing the Sophos database.
Sophosmgnt-presence


# Credentials to check the SQL database
If($username -eq "" -and ($password -eq ""))
{
    Display "please provide credential of a user able to read the SQL database as parameters of the script" "WARNING"
    EndScript(1)

}Else
{
    $global:username1 = $username
    $global:password1 = ConvertTo-SecureString –String $password –AsPlainText -Force
    $global:credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $username1, $password1    
}

Display "Get More informations from SOPHOS Database Please wait..."
#remove-job *
# Try to retrieve the Sophos Enterprise Console information from the SQL database using the credentials
try 
{ 
    Get-SECInformations -jobname "JOBSQLSOPHOS"
    
}catch
{ 
    Display "Wrong credentials to read SQL database, please provide $user credentials as parameters of the script" "Warning"
    Endscript(1)
} 

# retrieve all the Endpoints information to store it in a variable 
$Query =   "USE $dbname
            SELECT DISTINCT
            c.ComputerName,
            c.ComputerID,
            c.DomainName,
            t.OperatingSystemName,
            c.ServicePack,
            c.lastmessageTime,
            c.SAVOnAccess,
            c.Productid,
            c.LastScanDateTime,
            c.LastScanName,
            c.savversion,
            c.VirusDataVersion, 
            c.PackageExpiryTime,
            c.PackageNotificationTime,
            c.ThreatName,
            c.FullFilePath,
            c.SAVErrSource,
            c.SAVErrInsert1,
            c.AUErrSource,
            c.AUErrInsert1,
            c.AUErrInsert2,
            c.groupID,
            i.Name            
            FROM
            dbo.ComputerListData2 as c 
            INNER JOIN dbo.groups as i on i.ID = c.groupID
            INNER JOIN [Sophos Reporting Interface].vComputerHostData as t on t.OperatingSystemID = c.OS
            WHERE
            c.ComputerName <> ''
            $grouprequest
            Order by c.ComputerName"

Get-SqlDataTable -requete $Query -jobname "Endpointlist"
$global:Endpointlist = (Receive-Job -name "Endpointlist" -keep)

#store the list of computers which required a reboot
Get-rebootcomputers

foreach($data in $Endpointlist)
{
    [STRING]$computername = $data.computername
    If($computername)
    {
        $ComputerID = $data.ComputerID
        $DomainName = $data.DomainName
        $OSName = $data.OperatingSystemName
        $SP = $data.ServicePack
        $LastmessageTime = $data.LastmessageTime
        $Productid = $data.Productid
        $LastScanDateTime = $data.LastScanDateTime
        [STRING]$LastScanName = $data.LastScanName
        $savversion = $data.savversion
        $VirusDataVersion = $data.VirusDataVersion
        $SAVOnAccess = $data.SAVOnAccess
        If ($SAVOnAccess -eq "true")
        {
            $SAVOnAccess = "Yes"
        }Else
        {
            $SAVOnAccess = "No"
        }
        $VirusDataVersion = $data.VirusDataVersion
        $PackageExpiryTime = $data.PackageExpiryTime

        If($PackageExpiryTime -eq "01/01/9999 00:00:00")
        {
            [STRING]$UptoDate = "Yes"
        }Elseif($PackageExpiryTime.date)
        {
            [STRING]$UptoDate = "NOT SINCE $PackageExpiryTime"
        }Else
        {
            [STRING]$UptoDate = "UNKNOWN"
        }
        
        $PackageNotificationTime = $data.PackageNotificationTime

        # Check Alerts and Errors
        [STRING]$AUErrSource = $data.AUErrSource
        [STRING]$AUErrInsert1 = $data.AUErrInsert1
        [STRING]$AUErrInsert2 = $data.AUErrInsert2
        If($AUErrSource.startswith("ALC"))
        {
            $Alertanderror = "WARNING"
            $Alertdetails = ""
            #check if the reboot of the machine is required!
            foreach($namecpt in $rebootneeded)
            {
                #$computersneededreboot = $namecpt.name
                $computersneededreboot = $namecpt.ID
                If($ComputerID -eq $computersneededreboot)
                {
                    IF($UptoDate.startswith("Yes"))
                    {
                        [STRING]$Alertdetails = "Reboot Required"
                        #The value of $rebootpending is incremented +1
                        $global:rebootpending++   
                    }Else
                    {
                        [STRING]$Alertdetails = "WRONG UPDATE & Reboot Required"
                        #The value of $NotUptoDate is incremented +1
                        $global:NotUptoDate++                       
                    }                
                }
             }
             #indicated a different message if the reboot of the machine is not required!
             If($Alertdetails -eq "")
             {
                    $Alertanderror = "ERROR"
                    #The value of $errordetected is incremented +1
                    $global:errordetected++ 
                    if($UptoDate.startswith("Yes"))
                    {
                        $Alertdetails = "$AUErrInsert1 failed $AUErrInsert2"
                    }Else
                    {
                        $Alertdetails = "WRONG UPDATE & $AUErrInsert1 failed $AUErrInsert2"
                    }
             }
        
        }Else
        {
            $Alertanderror = "None"
            if($UptoDate.startswith("Yes"))
            {
                If($SAVOnAccess.startswith("Yes"))
		        {
			        $Alertdetails = "OK, AGENT ACTIVATED"
		        }Elseif($LastScanName -ne "")
		        {
			        $Alertdetails = "ON-ACCESS SCAN IS DEACTIVATED"
		        }Else
		        {
			        $Alertdetails = "AGENT DEACTIVATED: ON-ACCESS AND SCHEDULE SCANS ARE DEACTIVATED!"
                    #The value of $Onaccessdeactivated is incremented +1
                    $global:Onaccessdeactivated++  
                }

            }ElseIf($UptoDate.StartsWith("NOT"))
            {
                $Alertdetails = "WRONG UPDATE!"
                #The value of $NotUptoDate is incremented +1
                $global:NotUptoDate++ 

            }Else
            {
                $Alertdetails = "UNKNOWN UPDATE"
                #The value of $errordetected is incremented +1
                $global:errordetected++ 
            }

        }
 
       
        # If an Error or an infection is detected it is more important than previous alerts!   
        [STRING]$SAVErrSource = $data.SAVErrSource
        [STRING]$SAVErrInsert1 = $data.SAVErrInsert1
        [STRING]$ThreatName = $data.ThreatName
        [STRING]$FullFilePath = $data.FullFilePath
        If($ThreatName -ne "")
        {
            $Alertanderror = "MALWARE"
            $Alertdetails = "$ThreatName in $FullFilePath"
            #The value of $Malwaredetected is incremented +1
            $global:Malwaredetected++
        }ElseIf($SAVErrSource -eq "SAV")   
        {
            $Alertanderror = "ERROR"
            $Alertdetails = "UNKNOWN: $SAVErrInsert1"
            #The value of $errordetected is incremented +1
            $global:errordetected++        
        }
        
    }
}

# Set Exit codes on statistics

If($global:Malwaredetected -ge 5){Display "There are $Malwaredetected Malware detected on Endpoints managed by this console $ConsoleServername" "NOK"; $global:ExitCode = "2"
}ElseIf($global:errordetected -ge 5){Display "There are $errordetected Endpoints in error detected on this Console $ConsoleServername" "NOK"; $global:ExitCode = "2"
}ElseIf($global:Onaccessdeactivated -gt 5){Display "There are $Onaccessdeactivated inactive Endpoints detected on this Console $ConsoleServername" "NOK"; $global:ExitCode = "2"
}ElseIf($global:NotUptoDate -ge 10){Display "There are $NotUptoDate notuptodate Endpoints detected on this Console $ConsoleServername" "NOK"; $global:ExitCode = "2"
}ElseIf($global:rebootpending -ge 10){Display "There are $rebootpending Endpoints which are waiting a reboot detected on this Console $ConsoleServername" "Warning"; $global:ExitCode = "1"
}ElseIf($ExitCode -eq "0"){Display "All Checks are fine" "OK"}

Display "##### Below is the global Status of the $ConsoleServername agents: #####"
Display "There are $Malwaredetected Malware detected on Endpoints managed by this console"
Display "There are $errordetected Endpoints in error detected on this Console"
Display "There are $Onaccessdeactivated inactive Endpoints detected on this Console"
Display "There are $NotUptoDate notuptodate Endpoints detected on this Console"
Display "There are $rebootpending Endpoints which are waiting a reboot detected on this Console"

EndScript($exitcode)
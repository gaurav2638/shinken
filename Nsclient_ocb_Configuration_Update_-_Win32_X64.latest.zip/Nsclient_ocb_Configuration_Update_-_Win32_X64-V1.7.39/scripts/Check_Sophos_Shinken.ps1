###############################################################################################################################################
# Script Name : Check_Sophos_Shinken.ps1
###############################################################################################################################################
# Version : 1.0
###############################################################################################################################################
# Description : This Script check the health status of Sophos Agents from console side
# Usage example:
# .\Check_Sophos_Shinken.ps1
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 05/2016, Guillaume Blois, pre-release
# 0.2, 05/2016, Guillaume Blois, correct a bug of sql cluster check + change the threshold of alerts
# 1.0, 05/2016, Guillaume Blois, First script version
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok"        : Sophos agents are well from the console view.
# 1 : "Warning"   : A certain number agents don't reporting very well, an engineer must check the status.
# 2 : "Critical"  : Too much Sophos agents have problems (Communication failure , malware detected ...), an intervention MUST BE DONE ASAP.

# Others exit codes:
# 3 : "SQL Server": This script must be executed on a SQL SERVER.
# 4 : "Powershell": Powershell must be at least in version 2.0 and execution policy authorized.
###############################################################################################################################################
# Script Parameters Declaration 
###############################################################################################################################################

###############################################################################################################################################
# Variables definition
###############################################################################################################################################
$powershellversion = $host.Version.major
$global:Computername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$global:errorcode = "0"
$global:Onaccessdeactivated = 0
$global:NotUptoDate = 0
$global:Malwaredetected = 0
$global:rebootpending = 0
$global:errordetected = 0

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This Function Display a message with the date and color if need it
Function Display 
{
	param (
	[String] $Text,
	[String] $Type
	)
	$date = Get-Date
	Switch($Type)
	{
		"OK" {Write-Host "$date - $text" -nonewline; Write-Host " [Success]" -ForegroundColor Green}
		"NOK" {Write-Host "$date - $text" -nonewline; Write-Host " [Fail]" -ForegroundColor Red}
		"WARNING" {Write-Warning "$date - $text"}
		DEFAULT {Write-Host "$date - $text"}
	}
}

# This function Retrieves SQL server information from a local or remote servers. Pulls all instances from a SQL server and detects if in a cluster or not.
Function Get-SQLInstance 
{ �

    [cmdletbinding()]�
    Param (
        [parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True)]
        [Alias('__Server','DNSHostName','IPAddress')]
        [string[]]$ComputerName = $env:COMPUTERNAME
    ) 
    Process {
        ForEach ($Computer in $Computername) {
            $Computer = $computer -replace '(.*?)\..+','$1'
            Write-Verbose ("Checking {0}" -f $Computer)
            Try { 
                $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Computer) 
                $baseKeys = "SOFTWARE\\Microsoft\\Microsoft SQL Server",
                "SOFTWARE\\Wow6432Node\\Microsoft\\Microsoft SQL Server"
                If ($reg.OpenSubKey($basekeys[0])) {
                    $regPath = $basekeys[0]
                } ElseIf ($reg.OpenSubKey($basekeys[1])) {
                    $regPath = $basekeys[1]
                } Else {
                    Continue
                }
                $regKey= $reg.OpenSubKey("$regPath")
                If ($regKey.GetSubKeyNames() -contains "Instance Names") {
                    $regKey= $reg.OpenSubKey("$regpath\\Instance Names\\SQL" ) 
                    $instances = @($regkey.GetValueNames())
                } ElseIf ($regKey.GetValueNames() -contains 'InstalledInstances') {
                    $isCluster = $False
                    $instances = $regKey.GetValue('InstalledInstances')
                } Else {
                    Continue
                }
                If ($instances.count -gt 0) { 
                    ForEach ($instance in $instances) {
                        $nodes = New-Object System.Collections.Arraylist
                        $clusterName = $Null
                        $isCluster = $False
                        $instanceValue = $regKey.GetValue($instance)
                        $instanceReg = $reg.OpenSubKey("$regpath\\$instanceValue")
                        If ($instanceReg.GetSubKeyNames() -contains "Cluster") {
                            $isCluster = $True
                            $instanceRegCluster = $instanceReg.OpenSubKey('Cluster')
                            $clusterName = $instanceRegCluster.GetValue('ClusterName')
                            $clusterReg = $reg.OpenSubKey("Cluster\\Nodes")                            
                            $clusterReg.GetSubKeyNames() | ForEach {
                                $null = $nodes.Add($clusterReg.OpenSubKey($_).GetValue('NodeName'))
                            }
                        }
                        $instanceRegSetup = $instanceReg.OpenSubKey("Setup")
                        Try {
                            $edition = $instanceRegSetup.GetValue('Edition')
                        } Catch {
                            $edition = $Null
                        }
                        Try {
                            $ErrorActionPreference = 'Stop'
                            #Get from filename to determine version
                            $servicesReg = $reg.OpenSubKey("SYSTEM\\CurrentControlSet\\Services")
                            $serviceKey = $servicesReg.GetSubKeyNames() | Where {
                                $_ -match "$instance"
                            } | Select -First 1
                            $service = $servicesReg.OpenSubKey($serviceKey).GetValue('ImagePath')
                            $file = $service -replace '^.*(\w:\\.*\\sqlservr.exe).*','$1'
                            $version = (Get-Item ("\\$Computer\$($file -replace ":","$")")).VersionInfo.ProductVersion
                        } Catch {
                            #Use potentially less accurate version from registry
                            $Version = $instanceRegSetup.GetValue('Version')
                        } Finally {
                            $ErrorActionPreference = 'Continue'
                        }
                        New-Object PSObject -Property @{
                            Computername = $Computer
                            SQLInstance = $instance
                            Edition = $edition
                            Version = $version
                            Caption = {Switch -Regex ($version) {
                                "^14" {'SQL Server 2014';Break}
                                "^11" {'SQL Server 2012';Break}
                                "^10\.5" {'SQL Server 2008 R2';Break}
                                "^10" {'SQL Server 2008';Break}
                                "^9"  {'SQL Server 2005';Break}
                                "^8"  {'SQL Server 2000';Break}
                                Default {'Unknown'}
                            }}.InvokeReturnAsIs()
                            isCluster = $isCluster
                            isClusterNode = ($nodes -contains $Computer)
                            ClusterName = $clusterName
                            ClusterNodes = ($nodes -ne $Computer)
                            FullName = {
                                If ($Instance -eq 'MSSQLSERVER') {
                                    $Computer
                                } Else {
                                    "$($Computer)\$($instance)"
                                }
                            }.InvokeReturnAsIs()
                        }
                    }
                }
            } Catch { 
                Write-Warning ("{0}: {1}" -f $Computer,$_.Exception.Message)
            }  
        }   
    }
}

# This function to set the connection
Function global:Set-SqlConnection ($conn) 
{
    $SqlConnection.ConnectionString = $conn
}

### This function check if SQL SERVER component is present and running.
Function Sql-presence
{
    If (!(Get-Service -displayname "SQL Server Browser" -ErrorAction SilentlyContinue))
    {
        Display "$env:COMPUTERNAME is not a SQL Server!" "NOK"
        $global:errorcode = "3"
        Exit $global:errorcode
    }Else
    {
        Get-SQLInstance -ComputerName $Computername | ForEach { 
        If ($_.isClusterNode) 
        { 
            If (($list -notcontains $_.Clustername)) 
            { 
                Get-SQLInstance -ComputerName $_.ClusterName 
                $list += ,$_.ClusterName 
            } 
        }ElseIf($_.sqlinstance -like "*SOPHOS*")
        {
        	If(!($_.ClusterName-like $NULL))
            {
                
            [String]$global:SQLServerName = $_.ClusterName
            [String]$global:instance = $_.ClusterName + "\" + $_.sqlinstance
                
            }Else
            {
                [String]$global:SQLServerName = $env:COMPUTERNAME
                [String]$global:instance = $env:COMPUTERNAME + "\" + $_.sqlinstance
            }
        }
        }
            
        [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")|Out-null
        $srv = New-Object 'Microsoft.SqlServer.Management.SMO.Server' "$instance"
        [String]$dbnametemp = $srv.Databases | select name | ? {$_.name -like "SOPHOS5*"}
        $global:DbName = (($dbnametemp.split("="))[1]).Trim("}")
    }
}

# This function allow the user to perform a query that returns a table full of data
Function global:Get-SqlDataTable($requete) 
{
  
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
    $SqlCmd.CommandText = $requete
    $SqlCmd.Connection = $SqlConnection

    $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
    $SqlAdapter.SelectCommand = $SqlCmd

    $DataSet = New-Object System.Data.DataSet
    $SqlAdapter.Fill($DataSet)

    $SqlConnection.Close()
  
    return $DataSet.Tables[0]
}

# This function is able to retrieve Consolename from SQL database
Function Get-consoleName
{
    Set-Variable SqlConnection (New-Object System.Data.SqlClient.SqlConnection) -Scope Global -Option AllScope

    $Query =   "USE $dbname
                SELECT
                d.LastName
                FROM
                dbo.SDDMServers as d"

    # Initially create the SqlConnection
    $connectionString = "Data Source=$instance;Initial Catalog=$dbname; Trusted_Connection=Yes;"
    Set-SqlConnection $connectionString

    # Run the Query
    $SDDMServers = Get-SqlDataTable -requete $Query
    
    foreach($data in $SDDMServers)
    {
        $global:ConsoleServername = $data.LastName
    }

}

###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

# Checking Powershell status

If ($powershellversion -lt "2")
{
    Display "Wrong powershell version detected" "Warning"
    $global:errorcode = "4"
    Exit $global:errorcode
}

$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)) 
{
  #Display "Script Execution is disabled. Enabling it now" "Warning"
  Set-ExecutionPolicy $Policy -Force
  Display "Please Re-Run this script in a new powershell enviroment" "Warning"
  $global:errorcode =  = "4"
  Exit $global:errorcode
}

#Display "Get the information from Database Please wait..."
# Check SQL server presence, take instance and database name
Sql-presence
     
#Display "Audit the Database from $SQLServerName please wait..." 

Set-Variable SqlConnection (New-Object System.Data.SqlClient.SqlConnection) -Scope Global -Option AllScope

$Query =   "USE $dbname
            SELECT DISTINCT
            c.ComputerName,
            c.DomainName,
            t.OperatingSystemName,
            c.ServicePack,
            c.lastmessageTime,
            c.SAVOnAccess,
            c.Productid,
            c.LastScanDateTime,
            c.LastScanName,
            c.savversion,
            c.VirusDataVersion, 
            c.PackageExpiryTime,
            c.PackageNotificationTime,
            c.ThreatName,
            c.FullFilePath,
            c.SAVErrSource,
            c.AUErrSource,
            c.groupID,
            i.Name            
            FROM
            dbo.ComputerListData2 as c 
            INNER JOIN dbo.groups as i on i.ID = c.groupID
            INNER JOIN [Sophos Reporting Interface].vComputerHostData as t on t.OperatingSystemID = c.OS
            WHERE
            c.ComputerName <> ''
            Order by c.ComputerName"

# Initially create the SqlConnection
$connectionString = "Data Source=$instance;Initial Catalog=$dbname; Trusted_Connection=Yes;"
Set-SqlConnection $connectionString

# Run the Query
$global:Endpointlist = Get-SqlDataTable -requete $Query

foreach($data in $Endpointlist)
{
        $computername = $data.computername
        $DomainName = $data.DomainName
        $savversion = $data.savversion
        $VirusDataVersion = $data.VirusDataVersion
        $SAVOnAccess = $data.SAVOnAccess
        If (!($SAVOnAccess = "True"))
        {
            #The value of $Onaccessdeactivated is incremented +1
            $global:Onaccessdeactivated++
        }
        $VirusDataVersion = $data.VirusDataVersion
        $PackageExpiryTime = $data.PackageExpiryTime

        If ($PackageExpiryTime -ne "01/01/9999 00:00:00")
        {
            #The value of $NotUptoDate is incremented +1
            $global:NotUptoDate++
        }
        [String]$Alertanderror = $data.SAVErrSource
        If($Alertanderror -ne "SAV")
        {
            $Alertanderror = $data.AUErrSource
            If ($Alertanderror -ne "ALC")
            {
                $Alertanderror = $data.ThreatName
                If (!$Alertanderror -eq "")
                {
                    #The value of $Malwaredetected is incremented +1
                    $global:Malwaredetected++
                }
                $ThreatName = $data.ThreatName
                $FullFilePath = $data.FullFilePath
            }Else
            {
                #The value of $rebootpending is incremented +1
                $global:rebootpending++                
            }
        }Else
        {
            #The value of $errordetected is incremented +1
            $global:errordetected++            
        }
}

#Retrieve Console name to indicated in the messages
Get-consoleName

# Set Exit codes on statistics

If($global:Malwaredetected -ge 1){write-host "Critical At least one Malware was detected, Check Console $ConsoleServername" -ForegroundColor Red; $global:errorcode = "2"
}ElseIf($global:errordetected -gt 3){write-host "Critical At least 3 Sophos agents are on unknown Error, Check Console $ConsoleServername" -ForegroundColor Red; $global:errorcode = "2"
}ElseIf($global:Onaccessdeactivated -gt 5){write-host "Critical At least 5 Sophos agents are deactivated, Check Console $ConsoleServername" -ForegroundColor Red; $global:errorcode = "2"
}ElseIf($global:NotUptoDate -gt 5){write-host "Critical At least 5 Sophos agents are not updated, Check Console $ConsoleServername" -ForegroundColor Red; $global:errorcode = "2"
}ElseIf($global:rebootpending -gt 10){write-host "Warning At least 10 agents must be rebooted, Check Console $ConsoleServername" -ForegroundColor Yellow; $global:errorcode = "1"
}ElseIf($errorcode -eq "0"){write-host "All Checks are fine" -ForegroundColor Green}

Exit $errorcode

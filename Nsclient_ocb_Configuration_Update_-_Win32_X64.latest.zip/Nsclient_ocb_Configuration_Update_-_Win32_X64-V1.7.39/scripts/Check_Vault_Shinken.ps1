###############################################################################################################################################
# Script Name : Check_Vault_Shinken.ps1
###############################################################################################################################################
# Version : 1.3
###############################################################################################################################################
# Description : This Script check the health status of Vault Services (including Cluster and DR), for CyberArk product, thanks to PARClient 
# tool, which must be installed and configured properly as prerequisites (See Official Cyberark PARAgent documentation)
###############################################################################################################################################
# Version, Date, Author, Change description:
# 0.1, 2018/09/28, Guillaume Blois, First script version
# 1.0, 2018/10/05, Guillaume Blois, First Release
# 1.1, 2018/10/19, Guillaume Blois, Change some warning codes to Shinken alerts, update the scenarios
# 1.2, 2018/10/24, Guillaume Blois, Add harwares monitors
# 1.3, 2018/10/24, Guillaume Blois, Update CVM&Vault checks mistake (-OR instead -AND)
###############################################################################################################################################
#            Usage example:
###############################################################################################################################################
# .\Check_Vault_Shinken.ps1 -path [PARClientPath] -password [PARClientPassword] -Vault1 [Vault1] -Vault2 [Vault2] -$Vault3 [Vault3]
# Where:
# [PARClientPath] : is the path where the software PARClient.exe is installed, this is a mandatory prerequisite!
# [PARClientPassword]: is the password set in the PARClient configuration to accede the Vaults, without it script cannot work
# [Vault1]: is the Ip of the principal Vault, a unique vault can be monitored thanks to this script 
# [Vault2]: is the Ip of the second Vault, in case of Cluster, this represent the second node of the cluster (which can be "passive")
# [Vault3]: is the Ip of the third Vault, in case of DR (Disaster recovery) use.
###############################################################################################################################################
# Exit codes 
###############################################################################################################################################
# Shinken exit codes:
# 0 : "Ok" All checks are fine.
# 1 : "Warning" At least one of the provide parameter isn't right!
# 2 : "Critical" At least one Vault element is not working!

# Others exit codes:
# 3  : No PARClient detected.
# 4  : At least one Vault is not reachable
# 5  : Password is not correct
# 6  : CPU usage on one vault is too high
# 7  : The unique vault tested is not working
# 8  : At least one CVM is stopped on one of the cluster node
# 9  : The Vault service is not working properly on the Vaults
# 10 : The DisasterRecovery on Vault3 is stopped

###############################################################################################################################################
#			 Script Parameters Declaration 
###############################################################################################################################################

param(
	[String]$path = "",                                      # Provide The path where PARClient is deployed, if none default path is P:\
	[Parameter(Mandatory=$True)] [String]$password = "",     # This is a mandatory parameter, provide the PARClient Password set for the vaults access
	[Parameter(Mandatory=$True)] [String]$Vault1 = "",       # Provide the Ip or name of Vault1 (can be a node of a Cluster)
	[String]$Vault2 = "",                                    # Provide the Ip or name of Vault2 (can be a node of a Cluster)
	[String]$Vault3 = ""                                     # Provide the Ip or name of Vault3 (should be the Vault Disaster recovery)
	)

###############################################################################################################################################
# Variables definition
###############################################################################################################################################

$appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
$OSversion = (get-WmiObject -Class Win32_OperatingSystem).caption
$Global:computer = $env:computername
$FullComputername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$Global:LocalComputer = [ADSI]"WinNT://$Env:COMPUTERNAME,Computer"
$global:currentpath = (Get-Item -Path ".\" -verbose).fullname
$global:currentdomain = (get-wmiobject win32_computersystem).domain

$global:errorcode = "0"

###############################################################################################################################################
# Functions Declaration
###############################################################################################################################################

### This function to pickup all Vault information on a Vault, thanks to PARClient, and also check the hardwares status (CPU/Memory/Hard drives)
Function Check-Vault($allvault)
{
    $global:allVaultstatus=@()
    foreach ($IDVault in $allvault) 
    {
        if($errorcode -eq "0")
        {
            $IDVault = $IDVault.IDVault

            [string]$getvaultstatus = .\PARClient $IDVault/$password /C "status vault" 2>$null

            #check if password is correct for this vault, otherwise, end the script with errorcode "5"
            if($getvaultstatus -match "Authentication failure.")
            {
			    $global:message = write-host 'Critical, Provided Password is wrong, use "Paragent setpassword" command to set it properly' -ForegroundColor Red
			    $global:errorcode = "5"             
            }Else
            {

                [string]$getcvmstatus = .\PARClient $IDVault/$password /C "status CVM" 2>$null
                [string]$getPADRstatus = .\PARClient $IDVault/$password /C "status PADR" 2>$null
                [string]$getENEstatus = .\PARClient $IDVault/$password /C "status ENE" 2>$null
                [string]$getcpu = .\PARClient $IDVault/$password /C "getcpu" 2>$null
                [string]$getmemory = .\PARClient $IDVault/$password /C "getmemoryusage" 2>$null
                [string]$getdiskusage = .\PARClient $IDVault/$password /C "getdiskusage" 2>$null
                                
                $Vaultstatus = New-Object -TypeName PSobject

                $Vaultstatus | Add-Member -MemberType NoteProperty -Name VaultID -Value $IDVault -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name VAULTstatus -Value $getvaultstatus -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name CVMstatus -Value $getcvmstatus -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name PADRstatus -Value $getPADRstatus -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name ENEstatus -Value $getENEstatus -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name CPUusage -Value $getcpu -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name Memoryusage -Value $getmemory -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name PhysicalMemoryusage -Value ((($getmemory -split 'Utilized=')[1]).split('%'))[0] -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name SWAPMemoryusage -Value ((($getmemory -split 'Utilized=')[2]).split('%'))[0] -f
                $Vaultstatus | Add-Member -MemberType NoteProperty -Name Diskusage -Value $getdiskusage -f
                
                $global:allVaultstatus+=$Vaultstatus

           
                #Check CPU usage:
                #If CPU usage is great than 90%:        
                if((($getcpu.split('%'))[1]) -gt "90")
                {
                    $global:message = write-host "Critical, CPU usage on $IDVault is too high $getcpu" -ForegroundColor Red
                    $global:errorcode = "6"
                    break

                #Else Check Physical Memory usage:
                #If Physical memory usage is great than 95%:  
                }elseif ((((($getmemory -split 'Utilized=')[1]).split('%'))[0]) -gt "95")
                {
                    $global:message = write-host "Critical, Physical Memory usage on $IDVault is too high" (((($getmemory -split 'Utilized=')[1]).split('%'))[0]) "% used" -ForegroundColor Red
                    $global:errorcode = "6"
                    break
                }  

                #Check Disks usage

                $numberofdisk = (($getdiskusage.split('%')).count) -1
                for ($i = 0; $i -lt $numberofdisk;$i += 1) 
                {
                    If($i -eq "0")
                    {
                        $diskID = "C:"
                    }Else
                    {
                        $diskID = ((($getdiskusage.split("\"))[0 + $i]).split(")",2))[1]
                    }
                    $global:freediskusage = ((($getdiskusage.split('%'))[0 + $i]).split("(",2))[1]
                    #If free disk space is less than 2%:
                    if($freediskusage -lt "02")
                    {
                        $global:message = write-host "Critical, Only $freediskusage % free space is available on $IDVault $diskID drive" -ForegroundColor Red
                        $global:errorcode = "6"
                        break
                    }
                }

            }
        }
    }

}

### This Function check the connectivity to the server specified
Function Check-ServerConnectivity
{
	param(
	[String]$Server,
	[Int]$Port
	)
	# Create a Net.Sockets.TcpClient object to use for
        # checking for open TCP ports.
        $Socket = New-Object Net.Sockets.TcpClient
        
        # Suppress error messages
        $ErrorActionPreference = 'SilentlyContinue'
        
        # Try to connect
        $Socket.Connect($Server, $Port)
        
        # Make error messages visible again
        $ErrorActionPreference = 'Continue'
        
        # Determine if we are connected
        if ($Socket.Connected) 
		{
            $Socket.Close()
			#write-host "Connectivity to $Server on port $Port is OK" -ForegroundColor Green;write-output "`r"
        }Else
		{
			$global:message = write-host "Critical, Connectivity to $Server on port $Port isn't OK" -ForegroundColor Red
			$global:errorcode = "4" 
        }
        
        # Resetting the variable
        $Socket = $null
}


###############################################################################################################################################
#     		Main Script
###############################################################################################################################################
cls

#Check if ParClient appplication is properly deployed in the specidfied folder
If($path -eq "")
{
    $parclientfolder = "P:\Monitoring_Vault"
}Else
{
    $parclientfolder = $path
}


If((Test-Path "$parclientfolder\PARClient.exe") -or (Test-Path "$currentpath\PARClient.exe"))
{
    set-location $parclientfolder
    $PARclientOK = $true
}Else
{
    $global:message = write-warning "Warning: PARClient.exe doesn't found, please provide a proper path"
    $global:errorcode = "3" 
}

# check if Vault servers are reachable (PARClient is using flow TCP 9022
Check-ServerConnectivity $Vault1 9022
If(($Vault2 -ne "") -and ($errorcode -eq "0")){Check-ServerConnectivity $Vault2 9022}
If(($Vault3 -ne "") -and ($errorcode -eq "0")){Check-ServerConnectivity $Vault3 9022}

# if PARClient is properly deployed and Vaults reachable then store all provide VaultIp in a sheet to execute the function and export all the status in the "$allvaultstatus" sheet variable
If (($PARclientOK -eq $true) -and ($errorcode -eq "0"))
{
    $line = New-Object -TypeName PSobject
    $line | Add-Member -Name IDVault -MemberType NoteProperty -Value $Vault1
    $global:allvault = @()
    $global:allvault+=$line
    
    If($Vault2 -ne "")
    {
        $line = New-Object -TypeName PSobject
        $line | Add-Member -Name IDVault -MemberType NoteProperty -Value $Vault2
        $global:allvault+=$line
    }
    If($Vault3 -ne "")
    {
        $line = New-Object -TypeName PSobject
        $line | Add-Member -Name IDVault -MemberType NoteProperty -Value $Vault3
        $global:allvault+=$line
    }

    Check-Vault($allvault)

    if($errorcode -eq "0")
    {
        #Now we've got all the Status vault information in a unique Sheet "$allvaultstatus", we can compare and play each scenario:
        #set global variable for each Vault to play each scenario    
        $vault1status = ($allVaultstatus | Where-Object {$_.VaultID -like $Vault1})
        $vault2status = ($allVaultstatus | Where-Object {$_.VaultID -like $Vault2})
        $vault3status = ($allVaultstatus | Where-Object {$_.VaultID -like $Vault3})           
        
        #1st scenario: only one Vault was provided: 

        If(($vault2status -eq $null) -and ($vault3status -eq $null))
        {
            If(!($vault1status.VAULTstatus -match "running"))
            {
                If(!($vault1status.CVMstatus -match "running") -AND (!($vault1status.PADRstatus -match "running")))
                {
                    $global:message = write-host "Critical, The Vault&CVM&PADR services are both stopped on this Vault" -ForegroundColor Red;write-output "`r"
                    $global:errorcode = "7"                     
                }                
            }                   

        }Else
        {
            #2nd scenario: 
            #ClusterVaultManager : (V1[OK] & V2 [OK]) => SHINKEN [OK] SINON [KO]
            if((!($vault1status.CVMstatus -match "running")) -or (!($vault2status.CVMstatus -match "running")))
            {
                $global:message = write-host "Critical, At least one CVM is stopped on one of the cluster node" -ForegroundColor Red;write-output "`r"
                $global:errorcode = "8"
     
            #PrivateArk Server : (V1 [OK] & V2 [KO]) OU (V1 [KO] & V2 [OK]) => SHINKEN [OK] SINON [KO]
            }ElseIf((!($vault1status.VAULTstatus -match "running")) -and (!($vault2status.VAULTstatus -match "running")))
            {
                $global:message = write-host "Critical, The Vault service is not working properly on these Vaults!" -ForegroundColor Red;write-output "`r"
                $global:errorcode = "9"
        
            #DisasterRecovery : (V3 [OK] => SHINKEN[OK]) SINON [KO]
            }ElseIf(($vault3status -ne $null) -and (!($vault3status.PADRstatus -match "running")))
            {
                $global:message = write-host "Critical, The DisasterRecovery on Vault3 is stopped" -ForegroundColor Red;write-output "`r"
                $global:errorcode = "10"
            }
        }
    }
}

set-location $currentpath

# Change the errorcodes for Shinken

If($errorcode -eq "0")
{
    $global:Shinkenerrorcode = "0"
    write-host "All Checks are fine" -ForegroundColor Green
}Elseif($errorcode -eq "3"){$global:Shinkenerrorcode = "1"; $message
}Elseif($errorcode -eq "4"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "5"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "6"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "7"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "8"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "9"){$global:Shinkenerrorcode = "2"; $message
}Elseif($errorcode -eq "10"){$global:Shinkenerrorcode = "2"; $message
}

Exit $Shinkenerrorcode
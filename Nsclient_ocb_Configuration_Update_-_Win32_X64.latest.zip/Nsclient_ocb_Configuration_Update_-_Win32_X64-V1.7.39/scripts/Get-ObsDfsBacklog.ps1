<#
Script Name : Get-ObsDfsBacklog.ps1

.DESCRIPTION
This script check the status of the backlog from this server to the others in all the replications groups it is member of.
It will generate .txt files in the C:\Temp\DFSR in order Shinken will read them and get the backlog count for each replication group.

.EXAMPLE 
Get-ObsDfsBacklog.ps1
 .\Get-ObsDfsBacklog.ps1 


.NOTES
Version - Date - Author - Change description :
v1 - 26/10/2020 - Julien MAHE - First script version
	
.Warnings/Evolutions to do:


#>
# Function
Function getbacklog
{
	# Resetting error variable
	$err = $null
	
	# Getting backlog count with Get-DfsrBacklog
	$backlog = Get-DfsrBacklog -GroupName "$group" -FolderName "$folder" -SourceComputerName "$member" -DestinationComputerName "$destination" -ea SilentlyContinue -ev err;
	If ($err -ne $null)
	{
		Write-Host "Error retrieving backlog for folder $folder on replication group $group, from:$member to:$destination. To troubleshoot the error, please run <Get-DfsrBacklog -GroupName $group -FolderName $folder -SourceComputerName $member -DestinationComputerName $destination -Verbose> separately." -foreground red;
		$err | Out-File $path\Backlog_$($folder)_$($group -replace "[\/\\]", "-")_$($member)_$($destination).txt;
	}
	Else
	{
		if ($backlog -ne $null) 
			{
				$backlogcount = (Get-DfsrBacklog -GroupName $group -FolderName $folder -SourceComputerName $member -DestinationComputerName $destination -Verbose 4>&1).Message.Split(':')[2];
			}
		else
			{
				$backlogcount = 0
			}
		# Exporting file queue information out of the Get-DfsrBacklog cmdlet output
		$backlogcount | Out-File $path\Backlog_$($folder)_$($group -replace "[\/\\]", "-")_$($member)_$($destination).txt;

		Write-Host "Backlog for replicated folder $folder on replication group $group, from:$member to:$destination, contains $backlogcount file(s) queued.";
	}
}
$ComputerName = hostname
# Creating directory
$path = "\temp\DFSR";
New-Item -ItemType Directory -Force -Path $path | Out-Null;

# Getting replication group information
$groups = (Get-DfsReplicationGroup | Select -expand GroupName).trim();

# Looping each replication group found
Foreach ($group in $groups)
{
	# Getting all replicated folders for replication group $group
	$folders = (Get-DfsReplicatedFolder "$group" | Select -expand FolderName).trim();
	
	# Looping each replicated folder found for group $group
	Foreach ($folder in $folders)
	{
		# Getting all members for replication group $group
		$members = (Get-DfsrMember "$group" | Select -expand ComputerName).trim();
		
		# Looping each member found for replication group $group
		Foreach ($member in $members)
		{
			if ($member -eq $ComputerName)
			{
				# Getting all destination servers for member $member on replication group $group
				$destinations = (Get-DfsrConnection -GroupName "$group" -SourceComputerName "$member" | Select -expand DestinationComputerName).trim();
				
				# Looping each destination found for member $member on group $group
				Foreach ($destination in $destinations)
				{
					Getbacklog;
				}
			}
		}
	}
}
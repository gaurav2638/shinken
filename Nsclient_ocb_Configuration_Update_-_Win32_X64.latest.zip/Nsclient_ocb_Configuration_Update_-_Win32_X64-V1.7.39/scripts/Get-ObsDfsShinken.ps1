﻿<#
Script Name : Get-ObsDfsShinken.ps1

.SYNOPSIS
Script to get Windows AD-DS Role and Trust information to a CSV file.


.DESCRIPTION
This script check the health status of DFSR Services on Windows 2008-R2 and later versions
In PowerShell execute Get-ObsDfsShinken.ps1 with Administrator and Unrestricted rights
Test Parameters :
                                                                                    
		    ServiceStatus 				Show only DFS Services Status				
			DfsrConnection				Show only DFSr Connection Status			
			ReplicationGroup			Show only Replication Group Status			
			CompDFSFldRepl				Show only DFS Folders and Replication		
			Backlog						Show only Backlog File Count				
			Staging						Show only Staging Folder Size				
			Conflict					Show only Conflict and Deleted Percent		
			RootSize					Show only Root Size		

.EXAMPLE 
Get-ObsDfsShinken.ps1 -RG 'Replicated Group name' -RF 'Replicated folder Name' -test 'test to execute'
 .\Get-ObsDfsShinken.ps1 -rg WC.Home -rf Ddrive -test RootSize


.NOTES
Version - Date - Author - Change description :
	v0.5 - - Stephane CHAUVEAU 	- First script version : Checks the DFS server
														All services
														DfsrConnection
														PSDrive
														DFSNode
														Backlog, Staging, Conflict, Root Size and Watermarks 
	v0.6 - - 					- Parameters
	v2.0 - - 					- Automation (BC only)in
	v2.1 - - 					- Adding parameters instead of CSV sources files hosts.csv and Shares.csv
	v2.2 - 2019/04/25 - SBA 	- Modify some ExitCodeCritical to ExitCodeWarning for Warning status for some tests
								- Added some AllDFS mode tests for each unitary test to solve the systematic script exit on ErrorCodeOK
								- Added check powerhell v3.0
								- Added Display function
								- Added [Math] is not handled (cf an another v2.1 of this script)
								- Modification of the backlogcount calculation because it always returned '0' & modify critical tresholfd only for unknown value
								- Added tests for checking if $RG and $RF parameters value exist
								- Added correction for Staging Test because when $StagingSizeInMbList contains several value, the calcul of percent staging go wrong
	v2.3 - 2020/05/05 - SBA		- rename variable $DfsrRGrpRFldList to $Grpsname as early as line 217
								- change ExitCode for the check $RG & $RF value (no more "6" or "7", but "2")
								- change in backlog test: take in account only localhost as source server replication, not as receiver sever
	v2.4 - 2020/10/19 - JMA		- Change in backlog test : change the method used. Just read txt files created by a scheduled task on the servers.
	
.Warnings/Evolutions to do:
	* add parameters for tuning backlog threshold
	* problem when RDS desabled in DFSR management console -> not detected by powershell
	* problem with function get-dfsrconnection ( DFSRconnection, DFSnode, CompDFSFldRepl...) -> DFSR module dose not exit in 2008R2 server
	* problem with function get-dfsreplicationgroup  -> DFSR module dose not exit in 2008R2 server
	* problem with function get-dfsrmembership  -> DFSR module dose not exit in 2008R2 server
	(* probelm when $vv empty -> create an error with the following command ligne: $BacklogFileCount = $PartnerWMI1.GetOutboundBacklogFileCount($Vv).BacklogFileCount) -> no more used
	* check conflict test because $ConflictSizeInMb can have several values -> calcul go wrong
	* check rootsize test because $RootSizeInMb can have several values -> calcul go wrong

#>

<#
 Shinken exit codes:
 0 : "Ok" All checks are fine.
 1 : "Warning" At least one of the DFS service isn't running!
 2 : "Critical" DFS isn't operational!

 Others exit codes:
 3 : Wrong Powershell version : Powershell must be at least in version 3.0
 4 : Powershell Rights has been redefined
 5 : Parameter $Test empty
 6 : Parameter $RG value does not exist (no more used)
 7 : Parameter $RF value does not exist (no more used)
#>

####################################################################################################################################
#			 Script Parameters Declaration 
####################################################################################################################################
Param(
	[string]$RG,
	[string]$RF,
	[string]$Test  
)

## Parameters Definition
#[string]$Test=$args[0]
#[string]$Computername=$args[1]
#[string]$GrpsName=$args[2]


###############################################################################################################################################
#			 Global Variable declaration
###############################################################################################################################################
$ScriptVersion = "2.2"

## Variables definition
$Computername = hostname
$PowershellVersion = $host.Version.major
$Global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
$Global:Computername = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
$Error.Clear()
###$GrpsName = $RG

## Shinken exit codes
$Global:errorcode = "0"
$Global:Shinkenerrorcode = "0"
$Global:ExitCodeOK = "0"
$Global:ExitCodeWarning = "1"
$Global:ExitCodeCritical = "2"
 
<# Log File definition and auto deletion after 30 days

$MY_ArgFilePath = ".\Get-ObsDfsShinken-Arguments.txt"
$MY_ArgFile = Get-ChildItem .\Get-ObsDfsShinken-Arguments.txt

If($MY_ArgFile.lastaccesstime -lt (((get-date).AddDays(-30)))){
    $MY_ArgFile | remove-item -Force
}
#>

# Write arguments passed to the script in the log File
#"$(get-date) : Arguments reçu : $Args" >> $MY_ArgFilePath

################################################################################
#      		Functions Declaration
################################################################################
## This Function Display a message with the date and color if need it
Function Display{
	Param (
		[String] $Text,
		[String] $Type
	)
	$date = Get-Date
	Switch($Type){
		"OK" {Write-Host "$date - $text" -ForegroundColor Green}
		"NOK" {Write-Host "$date - $text" -ForegroundColor Red}
		"WARNING" {Write-Host "$date - $text" -ForegroundColor Yellow}
		DEFAULT {Write-Host "$date - $text"}
	}
}

function  global:Convert-Size{            
	[cmdletbinding()]            
	Param(            
		[validateset("Bytes","KB","MB","GB","TB")]            
		[string]$From,            
		[validateset("Bytes","KB","MB","GB","TB")]            
		[string]$To,            
		[Parameter(Mandatory=$True)]            
		[double]$Value,            
		[int]$Precision = 4            
	)  
	Switch($From){            
		"Bytes" {$value = $Value }            
		"KB" {$value = $Value * 1024 }            
		"MB" {$value = $Value * 1024 * 1024}            
		"GB" {$value = $Value * 1024 * 1024 * 1024}            
		"TB" {$value = $Value * 1024 * 1024 * 1024 * 1024}            
	}            
	Switch($To){            
		"Bytes" {return $value}            
		"KB" {$Value = $Value/1KB}            
		"MB" {$Value = $Value/1MB}            
		"GB" {$Value = $Value/1GB}            
		"TB" {$Value = $Value/1TB}            
            
	}            
	Return [Math]::Round($value,$Precision,[MidPointRounding]::AwayFromZero)            
} 


################################################################################
#     		Main Script
################################################################################
#cls

If($PowershellVersion -lt "3"){
    Display "Wrong powershell version detected" "Warning"
    $Global:ErrorCode = "3"
    Exit $Global:ErrorCode
}

## Checking/set Powershell status
$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If(((Get-ExecutionPolicy) -ne $Policy) -and ((Get-ExecutionPolicy) -ne $Policy2)){
	Set-ExecutionPolicy $Policy -Force
	Display "Please Re-Run this script in a new powershell enviroment" "Warning"
	$Global:ErrorCode = "4"
	Exit $Global:ErrorCode
}  
  
## Check if $RG & $RF value passed to the script as parameter exist
$WMIQuery0 = "select * from DfsrReplicatedFolderInfo"
$DfsrRGrpRFldList = Get-WmiObject -Computername $Computername -Namespace "root\MicrosoftDFS" -Query $WMIQuery0 #| select-object -Property replicationgroupname,replicatedfoldername,state
$RGexist ="False"
$RFexist = "False"
foreach($a in $DfsrRGrpRFldList){
	$RGN = $a.replicationgroupname
    $RFN = $a.replicatedfoldername
	if($RGN -eq $RG){
		$RGexist = "True"
	}

	if($RFN -eq $RF){
		$RFexist = "True"
	}
}
If($RGexist -eq "False"){
	Display "GroupName value does not exist! Re-Run this script with good RG parameter value" "NOK"
	#$Global:ErrorCode = "6"   #no more used, replaced by critical error code
	$Global:ErrorCode = "ExitCodeCritical"
	Exit $Global:ErrorCode
}
If($RFexist -eq "False"){
	Display "FolderName value does not exist! Re-Run this script with good RF parameter value" "NOK"
	#$Global:ErrorCode = "7"  #no more used, replaced by critical error code
	$Global:ErrorCode = "ExitCodeCritical"
	Exit $Global:ErrorCode
}
#$DfsrRGrpRFldList = $RG
$Grpsname = $RG

## Testing the Test Value
#If($Test -eq $empty){
If(!($Test)){
	Write-Host {
"
In PowerShell execute Get-ObsDfsShinken.ps1 with Administrator and Unrestricted rights

Syntax :

	Get-ObsDfsShinken.ps1 <ReplicationGroup> <ReplicatedFolder> <Test>

Test Parameters :
	AllDfs                      Show All tests for Distibuted File System								
	ServiceStatus 				Show only DFS Services Status				
	DfsrConnection				Show only DFSR Connection Status
	DFSNode						Show only DFS Nodes Status
	CompDFSFldRepl				Show only DFS Folders and Replication	
	ReplicationGroup			Show only Replication Group Status			
	Backlog						Show only Backlog File Count				
	Staging						Show only Staging Folder Size				
	Conflict					Show only Conflict and Deleted Percent		
	RootSize					Show only Root Size							

Example : Get-ObsDfsShinken.ps1 Marketing_France Documents ServiceStatus
"
	}

	$Global:ErrorCode = "5"
    Exit $Global:ErrorCode
}

If($Test -eq "AllDfs"){
	$ServiceStatus = $True
	$DfsrConnection = $True
    $DFSNode = $True
	$CompDFSFldRepl = $True
	$ReplicationGroup = $True
	$Backlog = $True
	$Staging = $True
	$Conflict = $True
	$RootSize = $True
	#$Watermark = $True
}	
If($Test -eq "ServiceStatus"){$ServiceStatus = $True}
If($Test -eq "DfsrConnection"){$DfsrConnection = $True}
If($Test -eq "DFSNode"){$DFSNode = $True}
If($Test -eq "CompDFSFldRepl"){$CompDFSFldRepl = $True}
If($Test -eq "ReplicationGroup"){$ReplicationGroup = $True}
If($Test -eq "Backlog"){$Backlog = $True}
If($Test -eq "Staging"){$Staging = $True}
If($Test -eq "Conflict"){$Conflict = $True}
If($Test -eq "RootSize"){$RootSize = $True}
#If($Test -eq "Watermark"){$Watermark = $True}




## Service Status
If($ServiceStatus -eq $True){
	$Global:Status01 = (Get-WmiObject win32_service | Where-Object -FilterScript {$_.Name -eq "DFS"}).status
	$Global:Status02 = (Get-WmiObject win32_service | Where-Object -FilterScript {$_.Name -eq "DFSR"}).status
	If($Status01 -and $Status02 -eq "ok"){
		Display "Ok - ServiceStatus test on $ComputerName - All services are fine." "OK"
        $ShinkenErrorCode = $ExitCodeOK
		If(!($Test -eq "AllDfs")){
			Exit $ShinkenErrorCode
		}
    }
	Else{
		Display "Critical - ServiceStatus test on $ComputerName - At least one of the DFS service isn't running!" "NOK"
        $ShinkenErrorCode = $ExitCodeCritical
		Exit $ShinkenErrorCode
    }
	#Write-Host "`r"
}

## DfsrConnection
If($DfsrConnection -eq $True){
	#$scn = Get-DfsrConnection -SourceComputerName $Computername
	#$scng = $scn.groupname
	#Foreach($scngn in $scng){
	#Write-Host $GrpsName

	$i = $GrpsName.count ###number of RG detected
	#$i = $DfsrRGrpRFldList.count ###number of RG detected
	
	Foreach($scngn in $GrpsName){
	#Foreach($scngn in $DfsrRGrpRFldList){
		(Get-DfsrConnection -GroupName $scngn -SourceComputerName $Computername) |`   ##/!\ Get-DfsrConnection don't exist on 2008R2
				ForEach-Object{
				
					$SComputerName = $_.SourceComputerName
					$DComputerName = $_.DestinationComputerName
				
                    $Status03 =	$_.Enabled
					If($Status03 -eq "True"){
                        #Write-Host "Ok - DfsrConnection test on $ComputerName @ $scngn DFS Connection is enabled"
						Display "Ok - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS Connection is enabled" "OK"
                        $ShinkenErrorCode = $ExitCodeOK
						If(!($Test -eq "AllDfs") -and ($i -eq 0)){
							Exit $ShinkenErrorCode
						}
                    }
					Else{
                        #Write-Host "Critical - DfsrConnection test on $ComputerName @ $scngn DFS Connection isn't enabled"
						Display "Critical - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS Connection isn't enabled" "NOK"
                        $ShinkenErrorCode = $ExitCodeCritical
						Exit $ShinkenErrorCode
                    }
					
                    $Status04 =	$_.RdcEnabled
					If($Status04 -eq "True"){
                        #Write-Host "Ok - DfsrConnection test on $ComputerName @ $scngn DFS Rdc is enabled"
						Display "Ok - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS Rdc is enabled" "OK"
                        $ShinkenErrorCode = $ExitCodeOK
						If(!($Test -eq "AllDfs") -and ($i -eq 0)){
							Exit $ShinkenErrorCode
						}
                    }
					Else{
                        #Write-Host "Critical - DfsrConnection test on $ComputerName @ $scngn DFS Rdc  isn't enabled"
						Display "Critical - DfsrConnection test on $ComputerName - from $SComputerName to $DComputerName - RG:$scngn - RF:$RF - DFS Rdc  isn't enabled" "NOK"
                        $ShinkenErrorCode = $ExitCodeCritical
						Exit $ShinkenErrorCode
                    }
					
					$Status05 =	$_.CrossFileRdcEnabled
					If($Status05 -eq "True"){
                        #Write-Host "Ok - DfsrConnection test on $ComputerName @ $scngn DFS Cross File Rdc is enabled"
						Display "Ok - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS Cross File Rdc is enabled" "OK"
                        $ShinkenErrorCode = $ExitCodeOK
						If(!($Test -eq "AllDfs") -and ($i -eq 0)){
							Exit $ShinkenErrorCode
						}
                    }
					Else{
						#Write-Host "Critical - DfsrConnection test on $ComputerName @ $scngn DFS Cross File Rdc isn't enabled"
						Display "Critical - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS Cross File Rdc isn't enabled" "NOK"
                        $ShinkenErrorCode = $ExitCodeCritical
						Exit $ShinkenErrorCode
                    }
					
			        $Status06 =	$_.State
					If($Status06 -eq "Normal"){
                        #Write-Host "Ok - DfsrConnection test on $ComputerName @ $scngn DFS State is Normal"
						Display "Ok - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS State is Normal" "OK"
                        $ShinkenErrorCode = $ExitCodeOK
						If(!($Test -eq "AllDfs") -and ($i -eq 0)){
							Exit $ShinkenErrorCode
						}
                    }
					Else{
                        #Write-Host "Critical - DfsrConnection test on $ComputerName @ $scngn DFS is not in a normal State"
						Display "Critical - DfsrConnection test on $ComputerName - from:$SComputerName to:$DComputerName - RG:$scngn - RF:$RF - DFS is not in a normal State" "NOK"
                        $ShinkenErrorCode = $ExitCodeCritical
						Exit $ShinkenErrorCode
                    }
                }
		#Write-Host "`r"
		$i = $i - 1
	}
}

## DFS Nodes State Test
If($DFSNode -eq $True){
	$PMI = Get-WmiObject Win32_DFSNode
	$i=$PMI.count ## number of RG detected
	
	Foreach($PMIq in $PMI){
		If($PMIq.Status -eq $Null){
			$PMIqs = "DFS node is functioning properly"
		}
		If($PMIq.Status -eq "OK"){
			$PMIqs = "DFS node is functioning properly"
		}
		If($PMIq.Status -eq "Error"){
			$PMIqs = "Error : Non-operational status"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Degraded"){
			$PMIqs = "Degraded : Operational status - $ComputerName indicates that an element is functioning properly, but is predicting a failure"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Unknown"){
			$PMIqs = "Unknown"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Pred Fail"){
			$PMIqs = "Pred Fail : Operational status - $ComputerName indicates that an element is functioning properly, but is predicting a failure"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Starting"){
			$PMIqs = "Starting : Non-operational status"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Stopping"){
			$PMIqs = "Stopping : Non-operational status"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Service"){
			$PMIqs = "Service : Non-operational status - $ComputerName can apply during disk mirror-resilvering, reloading a user permissions list, or other administrative work"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Stressed"){
			$PMIqs = "Stressed"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "NonRecover"){
			$PMIqs = "NonRecover"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "No Contact"){
			$PMIqs = "No Contact"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		If($PMIq.Status -eq "Lost Comm"){
			$PMIqs = "Lost Comm"
			$MY_error = $MY_error + "Critical - DfsNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs) `n"
		}
		
		If(($MY_Error -ne "0") -and ($MY_Error -ne $Null)){
			#Write-Host $MY_Error
			Display $MY_Error "NOK"
			$ShinkenErrorCode = $ExitCodeCritical
			Exit $ShinkenErrorCode
		}
		Else{
			#Write-Host "OK - DFSNode test on $ComputerName @ All DFS nodes are functioning properly"
			Display "OK - DFSNode test on $ComputerName - $($PMIq.name) Root:$($PMIq.Root) Status:$($PMIqs)" "OK"
			$ShinkenErrorCode = $ExitCodeOK
			If(!($Test -eq "AllDfs") -and ($i -eq 0)){
				Exit $ShinkenErrorCode
			}
		}
		$i = $i - 1
	}
    Clear-Variable -Name "MY_Error" -ErrorAction SilentlyContinue
}


#If(!(($AllDfs -eq $empty) -and ($CompDFSFldRepl -eq $empty) -and ($ReplicationGroup -eq $empty) -and ($Backlog -eq $empty) -and ($Staging -eq $empty) -and ($Conflict -eq $empty) -and ($RootSize -eq $empty))){

## Computing DFS Folders and Replication
$i = $GrpsName.count ## number of RG detected
#$i = $DfsrRGrpRFldList.count ## number of RG detected
# write-host "i grpsname count == $i" #for debug

Foreach($GrpName in $GrpsName){
#Foreach($GrpName in $DfsrRGrpRFldList){
	$RGrpGUID = (Get-DfsReplicationGroup -GroupName $GrpName).Identifier ##/!\ Get-DfsReplicationGroup don't exist on 2008R2
		
	## Replication State and Enabled
    If($CompDFSFldRepl -eq $True){
        $DfsRgC = Get-DfsrConnection -GroupName $GrpName -SourceComputerName $Computername  ##/!\ Get-DfsrConnection don't exist on 2008R2
		
		Foreach($DfsRg in $DFSRgC){
            If(!($($DfsRg.State) -eq "Normal") -and ($($DfsRg.Enabled) -eq "True") -and ($($DfsRg.RdcEnabled) -eq "True") -and ($($DfsRg.CrossFileRdcEnabled) -eq "True")){
				Display "Critical - CompDFSFldRepl test on $ComputerName - RG:$GrpName from:$($DfsRg.SourceComputerName) to:$($DfsRg.DestinationComputerName) Replication is not normal" "NOK"
                $ShinkenErrorCode = $ExitCodeCritical
				Exit $ShinkenErrorCode
            }
			Else{
				Display "Ok - CompDFSFldRepl test on $ComputerName - RG:$GrpName from:$($DfsRg.SourceComputerName) to:$($DfsRg.DestinationComputerName) Replication is normal" "OK"
                $ShinkenErrorCode = $ExitCodeOK
				If(!($Test -eq "AllDfs") -and ($i -eq 0)){
					Exit $ShinkenErrorCode
				} 
            }
        }
    }

    ## Backlog, Staging, Conflict, Root Size and Watermarks pre-compute
    $WMIQuery1 = "SELECT * FROM DfsrReplicatedFolderInfo WHERE ReplicationGroupGUID = '" + $RGrpGUID.ToString() + "' AND ReplicatedFolderName = '" + $RF + "'" 
    #$WMIQuery1 = "SELECT * FROM DfsrReplicatedFolderInfo WHERE ReplicationGroupGUID = '" + $RGrpGUID.ToString() + "' "
	$PartnerWMI1 = Get-WmiObject -Computername $Computername -Namespace "root\MicrosoftDFS" -Query $WMIQuery1 

	## Root,Staging folder size used In Mb
	#$Vv = $PartnerWMI1.GetVersionVector().VersionVector
	#$BacklogFileCount = $PartnerWMI1.GetOutboundBacklogFileCount($Vv).BacklogFileCount ##/!\  return value = 0 permanently
	
	$CurrentStage = $PartnerWMI1.CurrentStageSizeInMb
	#$CurrentConflict = $PartnerWMI1.CurrentConflictSizeInMb
	#$AllocatedStageSizeInMb = $PartnerWMI1.AllocatedStageSizeInMb
	
	$WMIQuery2 = "SELECT * FROM DfsrReplicatedFolderConfig WHERE ReplicationGroupGUID = '" + $RGrpGUID.ToString() + "' "
	$PartnerWMI2 = Get-WmiObject -Computername $Computername -Namespace "root\MicrosoftDFS" -Query $WMIQuery2 
	
	$StagingSizeInMbList = $PartnerWMI2.StagingSizeInMb #/!\ can have several values
	$ConflictSizeInMb = $PartnerWMI2.ConflictSizeInMb #/!\ can have several values
	$RootSizeInMb = $PartnerWMI2.RootSizeInMb #/!\ can have several values

	$WMIQuery3 = "SELECT * FROM DfsrMachineConfig" 
	$PartnerWMI3 = Get-WmiObject -Computername $Computername -Namespace "root\MicrosoftDfs" -Query $WMIQuery3 
	
	$RootLowWatermarkPercent = $PartnerWMI3.RootLowWatermarkPercent
	$RootHighWatermarkPercent = $PartnerWMI3.RootHighWatermarkPercent
	$StagingLowWatermarkPercent = $PartnerWMI3.StagingLowWatermarkPercent
	$StagingHighWatermarkPercent = $PartnerWMI3.StagingHighWatermarkPercent
	$ConflictLowWatermarkPercent = $PartnerWMI3.ConflictLowWatermarkPercent
	$ConflictHighWatermarkPercent = $PartnerWMI3.ConflictHighWatermarkPercent

	#Shinken cannot ask AD
	#$FoldNam = (ConvertFrom-DfsrGuid -GroupName $($PartnerWMI1.ReplicationGroupName) -Guid $PartnerWMI2.ReplicatedFolderGuid).FolderName
		
	$a = $PartnerWMI2.ReplicatedFolderGuid  ##/!\ can return several Guid
	$b = $($PartnerWMI1.ReplicationGroupName)
	$c = dfsrdiag guid2name /guid:$a /rgname:$b /v
	$d = $c | Select-String -Pattern "Object DN" -CaseSensitive
	$e = $d  -split "CN="
	$f = $e[1]
	$FoldNam = $f -split ","  ##/!\ value = Null when there are several folder for a same groupname, not critical because it's only used for the display
		
        ## Replication Group State
        If($ReplicationGroup -eq $True){
            $State = $PartnerWMI1.State
	        If($state -eq "0"){
				Display "Warning - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:Uninitialized" "Warning"
				$ShinkenErrorCode = $ExitCodeWarning
				exit $ShinkenErrorCode
			}
	        ElseIf($state -eq "1"){
				Display "Warning - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:Initialized" "Warning"
				$ShinkenErrorCode = $ExitCodeWarning
				exit $ShinkenErrorCode
			}
	        ElseIf($state -eq "2"){
				Display "Warning - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:Initial Sync" "Warning"
				$ShinkenErrorCode = $ExitCodeWarning
				exit $ShinkenErrorCode
			}
	        ElseIf($state -eq "3"){
				Display "Warning - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:Auto Recovery" "Warning"
				$ShinkenErrorCode = $ExitCodeWarning
				exit $ShinkenErrorCode
			}
	        ElseIf($state -eq "5"){
				Display "Critical - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:In Error" "NOK"
				$ShinkenErrorCode = $ExitCodeCritical
				exit $ShinkenErrorCode
			}
	        ElseIf(($state -eq $Null) -or ($state -eq "4")){
				Display "Ok - ReplicationGroup test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:Normal" "OK"
                $ShinkenErrorCode = $ExitCodeOK
				If(!($Test -eq "AllDfs") -and ($i -eq 0)){
					Exit $ShinkenErrorCode
				}
            }
			Else{
				Display "Critical - ReplicationGroup test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) RF:$FoldNam State:$state" "NOK"
                $ShinkenErrorCode = $ExitCodeCritical
				Exit $ShinkenErrorCode
            }
        }

        ## Backlog
        If($Backlog -eq $True){	
			
			## Source script https://hkeylocalmachine.com/?p=154 to determinate the backlogcount value
			## Get servers for the current replication group
			$replicationservers = & cmd /c ("dfsradmin conn list /rgname:`"{0}`"" -f $GrpName);
        
			## Reduce loop by 3 lines to filter out junk from dfsradmin 
			$j = 0;
			$jmax = ($replicationservers.count -3);
			## Loop through each replication member server
			foreach ($replicationserver in $replicationservers) {
				## Exclude first and last two lines as junk
				if (($j -ge 1) -and ($j -le $jmax)) {
					## Format server names
                    #display "replicationserver == $replicationserver" "warning"
					$sendingserver = ($replicationserver.split(" "))[0].trim();
					$z = 2
					do 
					{
						$receivingserver = $replicationserver.Split(" ")[$z]
						$z = $z + 1
					}
					While ($receivingserver.length -eq "0")
					
                    if($sendingserver -eq ($computername.split("."))[0].trim())
						{

						$path = "C:\Temp\DFSR"
						if (Test-Path $path\Backlog_$($RF)_$($grpname -replace "[\/\\]", "-")_$($sendingserver)_$($receivingserver).txt)
							{
								if ((Get-ChildItem $path\Backlog_$($RF)_$($grpname -replace "[\/\\]", "-")_$($sendingserver)_$($receivingserver).txt).LastWriteTime -gt (Get-Date).AddHours(-2)) 
								{
									$BacklogFileCount = Get-Content $path\Backlog_$($RF)_$($grpname -replace "[\/\\]", "-")_$($sendingserver)_$($receivingserver).txt
								}
								Else
								{
									Display "The file is more than 2 hours old"
									$ShinkenErrorCode = $ExitCodeCritical
									Exit $ShinkenErrorCode
								}
							}
						Else
							{
								Display "No file found for the Backlog."
								$ShinkenErrorCode = $ExitCodeCritical
								Exit $ShinkenErrorCode
							}
						## Unknown
						If(!($BacklogFileCount.Trim() -match "^[0-9]")){
						#Display "Unknown - Backlog test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam BacklogFileCount=Unknown" "NOK"
						Display "Unknown - Backlog test on $ComputerName - RG:$GrpName RF:$RF from:$sendingserver to:$receivingserver BacklogFileCount=Unknown" "NOK"
						$ShinkenErrorCode = $ExitCodeCritical
						Exit $ShinkenErrorCode
						}
						If(([int]$BacklogFileCount -ge 0) -and ([int]$BacklogFileCount -le 500)){ 
							#Display "OK - Backlog test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam BacklogFileCount=$BacklogFileCount" "OK"
							Display "OK - Backlog test on $ComputerName - RG:$GrpName RF:$RF from:$sendingserver to:$receivingserver BacklogFileCount = $BacklogFileCount" "OK"
							$ShinkenErrorCode = $ExitCodeOK
							#If(!($Test -eq "AllDfs") -and ($i -eq 0)){
							If(!($Test -eq "AllDfs")){
								Exit $ShinkenErrorCode
							}
						}
						## “1 Warning”  500<  x  =<10000
						If(([int]$BacklogFileCount -gt 500) -and ([int]$BacklogFileCount -le 1000)){ 
							#Display "Warning - Backlog test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam BacklogFileCount=$BacklogFileCount" "Warning"
							Display "Warning - Backlog test on $ComputerName - RG:$GrpName RF:$RF from:$sendingserver to:$receivingserver BacklogFileCount=$BacklogFileCount" "Warning"
							$ShinkenErrorCode = $ExitCodeWarning
							Exit $ShinkenErrorCode
						}
						## “2 Critique”  1000<  x
						If([int]$BacklogFileCount -gt 1000){ 
							#Display "Critical - Backlog test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam BacklogFileCount=$BacklogFileCount" "NOK"
							Display "Warning - Backlog test on $ComputerName - RG:$GrpName RF:$RF from:$sendingserver to:$receivingserver BacklogFileCount=$BacklogFileCount" "Warning"
							$ShinkenErrorCode = $ExitCodeWarning
							Exit $ShinkenErrorCode
						}
						## Unknown
<# 						If(!([int]$BacklogFileCount -match "[0-9]")){
							#Display "Unknown - Backlog test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam BacklogFileCount=Unknown" "NOK"
							Display "Unknown - Backlog test on $ComputerName - RG:$GrpName RF:$RF from:$sendingserver to:$receivingserver BacklogFileCount=Unknown" "NOK"
							$ShinkenErrorCode = $ExitCodeCritical
							Exit $ShinkenErrorCode
						} #>

			}
			}
			$j = $j + 1
			}
			}

        ## StagingSizeInMb
        If($Staging -eq $True){
		    Foreach($StagingSizeInMb in $StagingSizeInMbList){
				try {
					[int]$sp = (($CurrentStage * 100 )/ $StagingSizeInMb)
					$spr = ([Math]::Round($sp))
				}
				catch {
					#Write-Output "Warning - CurrentStagingPercent |CurrentStagingPercent=0;1;"
					Display "Warning - CurrentStagingPercent | CurrentStagingPercent=0;1;" "Warning"
				}
				#Write-Host "Staging Percent $spr StagingLowWatermarkPercent $StagingLowWatermarkPercent StagingHighWatermarkPercent $StagingHighWatermarkPercent" -foregroundcolor cyan
				## Unknown
				If([string]::IsNullOrEmpty($spr)){
					#Write-Host "Unknown - Staging test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam CurrentStagingPercentb=$spr"
					Display "Unknown - Staging test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam CurrentStagingPercentb=$spr" "NOK"
					$ShinkenErrorCode = $ExitCodeCritical
					Exit $ShinkenErrorCode
				}
				## OK
				If($spr -lt $StagingLowWatermarkPercent){ 
					#Write-Host	"OK - Staging test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam CurrentStagingPercent=$spr"
					Display	"OK - Staging test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam CurrentStagingPercent=$spr" "OK"
					$ShinkenErrorCode = $ExitCodeOK
					If(!($Test -eq "AllDfs") -and ($i -eq 0)){
						Exit $ShinkenErrorCode
					}
				}
				## Warning
				If($spr -ge $StagingLowWatermarkPercent -and $spr -le $StagingHighWatermarkPercent) { 
					#Write-Host "Warning - Staging test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam CurrentStagingPercent=$spr"
					display "Warning - Staging test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam CurrentStagingPercent=$spr" "Warning"
					$ShinkenErrorCode = $ExitCodeWarning
					Exit $ShinkenErrorCode
				}
				## Critical	
				If($spr -gt $StagingHighWatermarkPercent){ 
					#Write-Host "Critical - Staging test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam CurrentStagingPercent=$spr"
					Display "Critical - Staging test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam CurrentStagingPercent=$spr" "NOK"
					$ShinkenErrorCode = $ExitCodeCritical
					Exit $ShinkenErrorCode
				}
			}
        }

        ## ConflictAndDeletedQuotaInMB
        If($Conflict -eq $True){
	        #$ConflictAndDeletedQuotaInMB = ((Get-DfsrMembership -GroupName $GrpName -computername $Computername).ConflictAndDeletedQuotaInMB)
	        $drfg = ((Get-DfsrMembership -groupName  $GrpName -computername $Computername).ContentPath)
	        $drfgn = "$drfg"+"\DfsrPrivate\"
            $total = 0
	        If(Test-Path $drfgn\ConflictAndDeletedManifest.xml){
	            [xml]$userfile = Get-Content  $drfgn\ConflictAndDeletedManifest.xml
	            $userfile.ConflictAndDeletedManifest.Resource | foreach { $total += [long] $_.Size }
				$total
	            $totalMB = Convert-Size -From Bytes -To MB -value $total
				$totalMB
			
	            try{
					[int]$cdq = (($totalMB * 100 )/ $ConflictSizeInMb)
				}
				catch{
					#Write-Output "Warning - ConflictAndDeletedPercent |ConflictAndDeletedPercent=0;1;"
					Display "Warning - ConflictAndDeletedPercent |ConflictAndDeletedPercent=0;1;" "Warning"
				}
	            ## Unknown
	            If([string]::IsNullOrEmpty($cdq)){ 
		            #Write-Host "$GrpName ConflictAndDeletedPercent is unknown" -foregroundcolor Red
		            #Write-Host "Unknown - Conflict test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam ConflictAndDeletedPercent=$ConflictSizeInMb"
					Display "Unknown - Conflict test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam ConflictAndDeletedPercent=$cdq" "NOK"
                    $ShinkenErrorCode = $ExitCodeCritical
					Exit $ShinkenErrorCode
		            }
	            ## OK
	            If($cdq -lt $ConflictLowWatermarkPercent){ 
		            #Write-Host "$GrpName ConflictAndDeletedPercent is OK" -foregroundcolor cyan
		            #Write-Host "OK - Conflict test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam ConflictAndDeletedPercent=$cdq"
					Display	"OK - Conflict test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam ConflictAndDeletedPercent=$cdq" "OK"
                    $ShinkenErrorCode = $ExitCodeOK
					If(!($Test -eq "AllDfs") -and ($i -eq 0)){
						Exit $ShinkenErrorCode
					}
	            }
	            ## Warning
	            If($cdq -ge $ConflictLowWatermarkPercent -and $cdq -le $ConflictHighWatermarkPercent){ 
		            #Write-Host "$GrpName Current Staging Percent is between $StagingLowWatermarkPercent and $StagingHighWatermarkPercent `%" -foregroundcolor yellow
		            #Write-Host "Warning - Conflict test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam ConflictAndDeletedPercent=$cdq"
					Display "Warning - Conflict test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam ConflictAndDeletedPercent=$cdq" "Warning"
                    $ShinkenErrorCode = $ExitCodeWarning
					Exit $ShinkenErrorCode
	            }
	            ## Critical	
	            If($cdq -gt $ConflictHighWatermarkPercent){ 
		            #Write-Host "$GrpName ConflictAndDeletedPercent is critical" -foregroundcolor Red
		            #Write-Host "Critical - Conflict test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam ConflictAndDeletedPercent=$cdq"
					Display "Critical - Conflict test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam ConflictAndDeletedPercent=$cdq" "NOK"
		            $ShinkenErrorCode = $ExitCodeCritical
					Exit $ShinkenErrorCode
                }
	        }else{
	            #Write-Host "$GrpName ConflictAndDeletedPercent No ConflictAndDeletedManifest" -foregroundcolor cyan
	            #Write-Host "OK - Conflict test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam ConflictAndDeletedPercent=0"
				Display "OK - Conflict test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam ConflictAndDeletedPercent=0" "OK"
				$ShinkenErrorCode = $ExitCodeOK
				If(!($Test -eq "AllDfs") -and ($i -eq 0)){
					Exit $ShinkenErrorCode
				}
	        }
        }

        ## RootSize and Watermarks pre-compute
        If($RootSize -eq $True){
	        #Write-Host "$GrpName RootSize: $RootSizeInMb Mb " 
	        #Write-Host "RootLowWatermarkPercent $RootLowWatermarkPercent RootHighWatermarkPercent $RootHighWatermarkPercent"
	        [int]$RootSizeInMbQuotaInMB = "20480"
	        try{
				[int]$Rs = (($RootSizeInMb * 100 )/$RootSizeInMbQuotaInMB)
			}
			catch{
				#Write-Output "Warning - RootSizeInMb |RootSizeInMb=0;1;"
				Display "Warning - RootSizeInMb | RootSizeInMb=0;1;" "Warning"
			}	
	        ## Unknown
	        If([string]::IsNullOrEmpty($RootSizeInMb)){ 
		        #Write-Host "$GrpName Root Size is unknown" -foregroundcolor Red
		        #Write-Host "Unknown - RootSize test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam RootSizeInMb=$RootSizeInMb"
				Display "Unknown - RootSize test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam RootSizeInMb=$RootSizeInMb" "NOK"
                $ShinkenErrorCode = $ExitCodeCritical
				Exit $ShinkenErrorCode
	        }
	        ## OK
	        If($Rs -lt $RootLowWatermarkPercent){ 
		        #Write-Host "$GrpName Root Size is OK" -foregroundcolor cyan
		        #Write-Host	"OK - RootSize test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam RootSizeInMb=$RootSizeInMb"
				Display "OK - RootSize test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam RootSizeInMb=$RootSizeInMb" "OK"
                $ShinkenErrorCode = $ExitCodeOK
				If(!($Test -eq "AllDfs") -and ($i -eq 0)){
					Exit $ShinkenErrorCode
				}
	        }
	        ## Warning
	        If($Rs -ge $RootLowWatermarkPercent -and $Rs -le $RootHighWatermarkPercent){ 
		        #Write-Host "$GrpName Root Size is between $RootSizeLowWatermarkPercent and $RootSizeHighWatermarkPercent `%" -foregroundcolor yellow
		        #Write-Host "Warning - RootSize test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam RootSizeInMb=$RootSizeInMb"	
				Display "Warning - RootSize test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam RootSizeInMb=$RootSizeInMb"	"Warning"
	            $ShinkenErrorCode = $ExitCodeWarning
				Exit $ShinkenErrorCode
            }
	        ## Critical	
	        If($Rs -gt $RootHighWatermarkPercent){ 
		        #Write-Host "$GrpName Root Size is critical" -foregroundcolor Red
		        #Write-Host "Critical - RootSize test on $ComputerName @ Replicated Group $($PartnerWMI1.ReplicationGroupName) on Folder $FoldNam RootSize=$RootSizeInMb"
				Display "Critical - RootSize test on $ComputerName - RG:$($PartnerWMI1.ReplicationGroupName) RF:$FoldNam RootSize=$RootSizeInMb" "NOK"
                $ShinkenErrorCode = $ExitCodeCritical
				Exit $ShinkenErrorCode
            }
        }
		$i = $i - 1
    }
#}



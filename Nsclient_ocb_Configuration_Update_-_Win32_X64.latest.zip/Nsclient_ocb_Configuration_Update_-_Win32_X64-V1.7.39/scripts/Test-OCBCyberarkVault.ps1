<#
.SYNOPSIS
Test CyberArk Vault connexions
Can be schedule 'OcbCyberArkVaultTest.xml'

.DESCRIPTION
	1.0 Test Cyberark Vault connexion
	1.1 Shinken monitoring
	1.2	Error management handling
	
PS>
.\Test-OCBCyberArkVault.ps1
get-help .\Test-OCBCyberArkVault.ps1 -full
	
.EXAMPLE
(as Administrator)
.\Test-OCBCyberArkVault.ps1
.\Test-OCBCyberArkVault.ps1 -Monitoring Shinken -test Connexion
.\Test-OCBCyberArkVault.ps1 -Monitoring Shinken -test Vault

.NOTES
Contact
 Stephane CHAUVEAU 
 ORANGE/OBS/SCE/OCB SUBS/CSE/PMS/MS

.INPUTS
csv parameters

.OUTPUTS
	Screen  : Actual value and Shinken format
	Log 	: "C:\Scripts\OCB\Logs\Test-OcbCyberArkVault.log"
	
.LINK
http://www.orange.com

#>
	Param (
	[string]$Monitoring,
	[string]$Test
	)
#System
[System.Threading.Thread]::CurrentThread.Priority = 'AboveNormal'
cls 
$Policy = "RemoteSigned"
$Policy2 = "Unrestricted"
If (((get-ExecutionPolicy) -ne $Policy) -and ((get-ExecutionPolicy) -ne $Policy2)){
	#Test Execution policy
	Set-ExecutionPolicy $Policy -Force
	Display "Please Re-Run this script in a new powershell enviroment" "Warning"
	$global:errorcode = = "4"
	Exit $global:errorcode
	}

#Functions
Function Write-Color(
	[String[]]$Text,
	[ConsoleColor[]]$Color = "White",
	[int]$StartTab = 0,
	[int] $LinesBefore = 0,
	[int] $LinesAfter = 0,
	[string] $LogFile = "",
	$TimeFormat = "yyyy-MM-dd HH:mm:ss") {
    # version 0.2
    # - TimeFormat https://msdn.microsoft.com/en-us/library/8kb3ddd4.aspx
	$DefaultColor = $Color[0]
    if ($LinesBefore -ne 0) {  for ($i = 0; $i -lt $LinesBefore; $i++) { Write-Host "`n" -NoNewline } } # Add empty line before
    if ($StartTab -ne 0) {  for ($i = 0; $i -lt $StartTab; $i++) { Write-Host "`t" -NoNewLine } }  # Add TABS before text
    if ($Color.Count -ge $Text.Count) {
        for ($i = 0; $i -lt $Text.Length; $i++) { Write-Host $Text[$i] -ForegroundColor $Color[$i] -NoNewLine } 
    } else {
        for ($i = 0; $i -lt $Color.Length ; $i++) { Write-Host $Text[$i] -ForegroundColor $Color[$i] -NoNewLine }
        for ($i = $Color.Length; $i -lt $Text.Length; $i++) { Write-Host $Text[$i] -ForegroundColor $DefaultColor -NoNewLine }
    }
    Write-Host
    if ($LinesAfter -ne 0) {  for ($i = 0; $i -lt $LinesAfter; $i++) { Write-Host "`n" } }  # Add empty line after
    if ($LogFile -ne "") {
        $TextToFile = ""
        for ($i = 0; $i -lt $Text.Length; $i++) {
            $TextToFile += $Text[$i]
        }
        Write-Output "[$([datetime]::Now.ToString($TimeFormat))]$TextToFile" | Out-File $LogFile -Encoding unicode -Append
    }
}

# Variables
$global:Computername = hostname
$powershellversion = $host.Version.major
$global:OSVersion = (Get-WmiObject Win32_OperatingSystem).version
$usr = whoami
#flnm = $(Get-Date -Format dd/MM/yyyy)
#user =  [string]$usr.Split("\")[1]
$global:errorcode = "0"
$ErrorActionPreference= 'silentlycontinue'
#Data
$array = @()
$computers = @()
$counter = 0
$counterK = 0

 if (!($Monitoring -eq "Shinken")){
		Write-host ""
		Write-host "-*-			Checking CyberArk			-*-" -foreground Magenta
}
if(![System.IO.File]::Exists("c:\Scripts\OCB\Parameters\Hosts.csv")){
	Write-host ""
    Write-host "OCB Hosts parameters file does not exist" -foreground Red;exit
	}else{
	$computers = Import-Csv "c:\Scripts\OCB\Parameters\Hosts.csv"
	$lh = ($Computers  | Where-Object {$_.Name -eq $Computername}).name
	$Computs = $Computers | Select-Object -Property Name,Site,Platform,Type,IP
	$Site = ($Computers  | Where-Object {$_.Name -eq $Computername}).Site
	$ComputDiv = ($Computs  | Where-Object {$_.site -eq $site})
	$Platform =  ($Computers  | Where-Object {$_.Name -eq $Computername}).CustomerDivision

	$CustVault = $ComputDiv | Where-Object {$_.type -match "Vault"}
	$CustPvwa = $ComputDiv | Where-Object {$_.type -match "Pvwa"}
	$CustCpm = $ComputDiv | Where-Object {$_.type -match "Cpm"}
	$CustPsm = $ComputDiv | Where-Object {$_.type -match "Psm"}
	$CustPsmp = $ComputDiv | Where-Object {$_.type -match "Psmp"}
	$CustSyslog = $ComputDiv | Where-Object {$_.type -match "Syslog"}
	$CustSmtp = $ComputDiv | Where-Object {$_.type -match "SMTP"}
	$CustVip = $ComputDiv | Where-Object {$_.type -match "VIP"}
	$CustLdap = $Computers | Where-Object {$_.type -match "LDAP"}
	
	}

if(![System.IO.File]::Exists("c:\Scripts\OCB\Parameters\Vaults.csv")){
	Write-host ""
    Write-host "OCB Vaults parameters file does not exist" -foreground Red;exit
	}else{
	$Vaults = Import-Csv "c:\Scripts\OCB\Parameters\Vaults.csv"
	$Vault = ($Vaults  | Where-Object {$_.Platform -eq $Platform}).Vault
	$VaultIP = ($Vaults  | Where-Object {$_.Platform -eq $Platform}).VIP
	$VaultPort= "1858"
	$ssf = ($Vaults  | Where-Object {$_.Platform -eq $Platform}).Safe
	$FolderName= ($Vaults  | Where-Object {$_.Platform -eq $Platform}).Folder
	$file =  ($Vaults  | Where-Object {$_.Platform -eq $Platform}).TestFile
	$UserName= ($Vaults  | Where-Object {$_.Platform -eq $Platform}).UserToCheck
	
}	


if (test-path "C:\Scripts\OCB\Logs"){
    if (!($Monitoring -eq "Shinken")){
    Write-host "Logs folder is OK"}
    }
	else{New-Item -ItemType directory -Path C:\Scripts\OCB\Logs}

			
if (test-path "c:\Scripts\OCB\Temp\test.file"){

if (!($Monitoring -eq "Shinken")){
Write-host "Deleting Test file"} 
remove-item "c:\Scripts\OCB\Temp\test.file" -force}
	else{
		if (!($Monitoring -eq "Shinken")){
		Write-host "No test file"}
		}
$user = $username
$localfolder = "c:\Scripts\OCB\Temp"
$localfile = "test.file"

#Beguin
cls
$host.ui.RawUI.ForegroundColor = "White"
if (!($Monitoring -eq "Shinken")){
Write-host "-*-" -foreground Magenta
Write-host "-*-	CyberArk Vault Test" -foreground Magenta
Write-host "-*-" -foreground Magenta
}
if (($Computers  | Where-Object {$_.Name -eq $Computername}).type -match "Psm"){
	if (!($Monitoring -eq "Shinken")){
	Write-host ""
	Write-host "You are connected to a PSM computer" -foreground  green
		}
	}else{
	Write-host "You are not connected to a PSM computer" -foreground red}

$original_file = "C:\Scripts\OCB\Bin\Password Upload Utility\Vault.template.ini"
$destination_file =  "C:\Scripts\OCB\Bin\Password Upload Utility\Vault.ini"
(Get-Content $original_file) | Foreach-Object {
    $_ -replace '##VAULTNAME##', $Vault `
       -replace '##VAULTIP##', $VaultIP `
       -replace '##VAULTPORT##', $VaultPort `
    } | Set-Content $destination_file	
	
# Si compte AD il doit faire parti de Vault Admin.
	$tpa = Test-Path -Path "c:\Scripts\OCB\Bin\Password Upload Utility\ocb.cred"
	if (!($Monitoring -eq "Shinken")){
	Write-host "User credential : $tpa" -foregroundcolor green
		}
	if ($tpa -eq $true) {
        if ($Test -eq "Connexion"){
		    $VaultStatus = "OK"
			$global:Shinkenerrorcode = "0"; write-host "OK - Vault $Vault Credential File |Credential=$VaultStatus" -ForegroundColor Green
			Exit $Shinkenerrorcode			
		    }
		} else {
        if ($Test -eq "Connexion"){
		    $VaultStatus = "KO"
			$global:Shinkenerrorcode = "2"; write-host "KO - Vault $Vault Credential File |Credential=$VaultStatus" -ForegroundColor Red
			Exit $Shinkenerrorcode
		    }
        }
	if (!($Monitoring -eq "Shinken")){
		Write-host ""    	
		}
	cd "C:\Scripts\OCB\Bin\Password Upload Utility"
		$host.ui.RawUI.ForegroundColor = "White"

		 .\pacli init  2>&1
		 .\pacli DEFINE VAULT=$Vault ADDRESS=$VaultIp PORT=$VaultPort BEHINDFIREWALL=YES >$null 2>&1
		 if (!($Monitoring -eq "Shinken")){
			write-host "[1/5] Connecting the Vault" -foreground Green
			}
		 .\pacli logon VAULT=$Vault USER=$user LOGONFILE=ocb.cred FAILIFCONNECTED=NO >$null 2>&1
		 if (!($Monitoring -eq "Shinken")){
			write-host "[2/5] Checking Safe access" -foreground Green
			}
		 .\pacli OPENSAFE VAULT=$Vault USER=$user SAFE=$ssf >$null 2>&1
		 if (!($Monitoring -eq "Shinken")){
			write-host "[3/5] Getting Safe item" -foreground Green
			}
		 .\pacli RETRIEVEFILE VAULT=$Vault USER=$user SAFE=$ssf FOLDER=$foldername FILE=$file LOCALFOLDER=$localfolder LOCALFILE=$localfile LOCKFILE=NO >$null 2>&1
		if (!($Monitoring -eq "Shinken")){
			write-host "[4/5] Closing Safe" -foreground Green
			}
		 .\pacli CLOSESAFE VAULT=$Vault USER=$user SAFE=$ssf >$null 2>&1
		 if (!($Monitoring -eq "Shinken")){
			write-host "[5/5] Exiting" -foreground Green
			}
		 .\pacli logoff VAULT=$Vault USER=$user 2>&1
		 .\pacli term 2>&1
		
	
	if (test-path "$localfolder\$localfile"){
            if ($Test -eq "Vault"){
			    $VaultStatus = "OK"
				$global:Shinkenerrorcode = "0"; write-host "OK - Connexion to Vault $Vault |Vault=$VaultStatus" -ForegroundColor Green
				Exit $Shinkenerrorcode				
			    }
            }
		else{ 
            if ($Test -eq "Vault"){
			    $VaultStatus = "KO"
				$global:Shinkenerrorcode = "2"; write-host "KO - Connexion to Vault $Vault |Vault=$VaultStatus" -ForegroundColor Red
				Exit $Shinkenerrorcode
               }
            }
cd "C:\Program Files\NSClient++_ocb\scripts"
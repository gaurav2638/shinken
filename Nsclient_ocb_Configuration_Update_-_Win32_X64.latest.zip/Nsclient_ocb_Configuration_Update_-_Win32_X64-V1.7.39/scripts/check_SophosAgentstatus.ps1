###############################################################################################################################################
#	Script Name : check_SophosAgentstatus.ps1
###############################################################################################################################################
#	Description : Script Check if sophos agent is installed and properly work, 
#	give version of the agent, and version of update.
###############################################################################################################################################
#	Version, Date, Author, Change description:
#		1.0, 07/2013, Guillaume Blois,  First Release
#		1.1, 10/2013, Guillaume Blois,  Update after 10.3 release
#		1.2, 12/2013, Guillaume Blois,  Change the check of Sophos version number
#		1.3, 12/2013, Guillaume Blois,  Update for AV standalone version.
#		1.4, 01/2014, Gilles Meignan,   Resolve server connectivity bug.
#		1.5, 01/2014, Guillaume Blois,  Update to check the management console
#		1.6, 01/2014, Gilles Meignan,	Global inprovment
#		1.7, 01/2014, Gilles Meignan,	Detect Sophos Standalone
#		1.8, 11/02/2019, Guillaume Blois,  Detect Message Relay presence
#		1.9, 18/02/2019, Guillaume Blois,  Check all modules presence, add tamper protection checks
#		2.0, 22/02/2019, Guillaume Blois,  update Function "Show-SAVUpdateTime" to compare the date + add CheckUrl&cidpath + add check-onaccess + add virus detection
#		2.1, 25/02/2019, Guillaume Blois,  Update to be used by Shinken monitoring
#		2.2, 25/02/2019, Guillaume Blois,  Sorted a check-service bug when it doesn't exist
#		2.3, 14/03/2019, Guillaume Blois,  Add try/catch for cases where Antivirus is not properly deployed.
#		2.4, 14/03/2019, Guillaume Blois,  Add some warning when information cannot be found
#		2.5, 25/03/2019, Guillaume Blois,  Add reboot check, Bypass Hitman service check if console or less than 2008-R2
#		2.6, 02/04/2019, Guillaume Blois,  Change Hitman service check by name and update Check-service function accordingly + add french in virus detection
#		2.7, 07/08/2019, Guillaume Blois,  Update a Bug of recovered Console management name when only 2 data are indicated in the mrinit.conf file
#		2.8, 05/01/2021, Guillaume Blois,  Update to include the detection of adware/PUA and suspicious files, change "CRITICAL" messages by "ALERT"
#		2.9, 13/01/2021, Guillaume Blois,  Update the detection of authorized adware or PUA
#		3.0, 20/01/2021, Guillaume Blois,  Detect virus in last 24h only
#		3.1, 22/01/2021, Guillaume Blois,  Add the Daydiff variable to be able to choose the number of infection detection historic number of days to check
#		3.2, 27/01/2021, Guillaume Blois,  add elseif on virusdetection
#		3.3, 02/04/2021, Guillaume Blois,  delete hitmanpro service check because it is randomly started + updated "savupdate" date check from 24h
###############################################################################################################################################
#      		Exit codes 
###############################################################################################################################################

# 0 : "Ok" All checks are fine, Sophos Endpoint protection is updated, properly set and activated.
# 1 : "Warning" Sophos Endpoint Protection is not set properly, or an infection was detected and threated
# 2 : "Alert" Sophos Endpoint Protection is failed, not updated or an action is requiered (virus remove), an expert must check the status on the concerned computer.

###############################################################################################################################################
#			 Script Parameters Declaration 
###############################################################################################################################################

param(
	[Switch]$Shinken = $False,     # Switch to be used for Shinken monitoring
    [INT] $Daysdiff = "1"          # per default the script will check if an infection was detected in the last 24h
	)

###############################################################################################################################################
#			 Global Variable declaration
###############################################################################################################################################
$Version = "3.3"
$ComputerName = $env:COMPUTERNAME
$SysRoot = $env:SystemRoot
$CurrentUsername = [Environment]::UserName
$OSVersion = [Environment]::OSVersion.Version.Major
$powershellversion = $host.Version.major
$global:AV="$false"
[boolean]$Standalone = $True
[boolean]$global:failure = $false
$global:tamperprotection = "unavailable"
$global:ExitCode = "0"
$global:machinexmlpresence = $true
$global:rightswarning = $false

###############################################################################################################################################
#      		Functions Declaration
###############################################################################################################################################
### This Function Display a message with the date and color if need it
Function Display 
{
	param (
	[String] $Text,
	[String] $Type
	)
	$date = Get-Date

    if($shinken -eq $false)
    {
        Switch($Type)
	    {
         	"OK"{Write-Host "$date - $text" -nonewline;Write-Host " [Success]" -ForegroundColor Green}
		    "NOK" {Write-Host "$date - $text" -nonewline; Write-Host " [Fail]" -ForegroundColor Red;$global:badmessage = $text;$global:failure=$true}
		    "WARNING" {Write-Host "$date - $text" -nonewline;Write-Host " [Warning]" -ForegroundColor Yellow;$global:warningmessage = $text}
		    DEFAULT {Write-Host "$date - $text"}
	    }

    }Else
    {
        Switch($Type)
	    {
            "OK"{}
		    "NOK" {$global:badmessage = $text; $global:failure=$true}
		    "WARNING" {$global:warningmessage = $text}
        }
    }
}

### This function end the script properly
Function EndScript
{
	param (
	[Int] $ExitCode
	)
    If($ExitCode -eq "0" -And $failure -eq $false)
    {
        Write-Host "OK: Sophos Endpoint Server Protection is working properly" -ForegroundColor Green
    }Elseif($failure -eq $true -or $ExitCode -eq "2")
    {
        if($global:rebootrequiered -eq "Yes")
        {
            Write-Host "ALERT: $badmessage, because a reboot is required" -ForegroundColor red
        }Else
        {       
            Write-Host "ALERT: $badmessage" -ForegroundColor red
        }
    }Else
    {
        Write-Host "WARNING: $warningmessage" -ForegroundColor Yellow
    }

    If($Shinken -eq $False)
    {
        Write-Host "#######################################################################`n---> End of check_SophosAgentStatus script`n#######################################################################"
        Stop-Transcript
    }
	exit ($ExitCode)
}

# Check Sophos paths and set variables
Function Set-Variables
{
  
	If ($powershellversion -gt "1"){$dnscheck=$true}
	$global:alcpath="C:\ProgramData\Sophos\AutoUpdate\Logs\alc.log"

	Try
	{
        [string]$global:path=((get-wmiobject -query 'select * from win32_service where name="SAVService"').pathname).split('"')
        $Sophospath= $path �replace ("Sophos Anti-Virus\\SavService.exe","")
        [string]$global:Sophospath=$Sophospath.trim()
        $mrinitpath= $path �replace ("Sophos Anti-Virus\\SavService.exe","Remote Management System\mrinit.conf")
        [string]$global:mrinitpath= $mrinitpath.trim()
        [string]$global:Path=$path.trim()
        [string]$global:sophosversion= [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$path").FileVersion
        # Dynamic Variables Creation from Machine.XML file
	}
	Catch
	{
		Display "Unable to check some information with get-wmiobject, check rights!" "WARNING"
        $global:rightswarning = $true
        $global:ExitCode = "1"
	}    

}

### This function check if service is present and running or not
Function Check-Service
{
	param(
	#[Parameter(Mandatory=$true)]
	[String]$DisplayServiceName
	)
	If (Get-Service "$DisplayServiceName" -ErrorAction SilentlyContinue)
	{ 
       If ((Get-Service "$DisplayServiceName").status -eq "running")
       {
            Display  "Service $DisplayServiceName is running" "OK"
	   }Else
       {
	        Display  "Service $DisplayServiceName is Stopped!" "NOK"
            $global:ExitCode = "2"
       }       
	}Else
    {
        Display  "Service $DisplayServiceName is not present!" "NOK"
        $global:ExitCode = "2"
	}
}

function Get-InstalledApps
# This function will loop through the applications installed and output one object for each Application with all its properties.
{
    foreach ($App in $Applications)
    {           
        $AppRegistryKey = $UninstallRegKey + "\\" + $App
        $AppDetails = $HKLM.OpenSubKey($AppRegistryKey)
        $AppGUID = $App
        $AppDisplayName = $($AppDetails.GetValue("DisplayName"))
        $AppVersion = $($AppDetails.GetValue("DisplayVersion"))
        $AppPublisher = $($AppDetails.GetValue("Publisher"))
        $AppInstalledDate = $($AppDetails.GetValue("InstallDate"))
        $AppUninstall = $($AppDetails.GetValue("UninstallString"))
        if(!$AppDisplayName) { continue }
        $OutputObj = New-Object -TypeName PSobject
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppName -Value $AppDisplayName
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppVersion -Value $AppVersion
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppVendor -Value $AppPublisher
        $OutputObj | Add-Member -MemberType NoteProperty -Name InstalledDate -Value $AppInstalledDate
        $OutputObj | Add-Member -MemberType NoteProperty -Name UninstallKey -Value $AppUninstall
        $OutputObj | Add-Member -MemberType NoteProperty -Name AppGUID -Value $AppGUID
        if ($RegistryView -eq 'Registry32')
        {
            $OutputObj | Add-Member -MemberType NoteProperty -Name Arch -Value '32'
        } else {
            $OutputObj | Add-Member -MemberType NoteProperty -Name Arch -Value '64'
        }
        $OutputObj
    }
}
  
### This function check the DNS resolution
Function CheckDNS
{
	param(
	[String]$Serverfqdn
	)
	Try
	{
		[System.Net.Dns]::Resolve($Serverfqdn) | Out-Null
		Display  "Sophos $Serverfqdn Name DNS Resolution" "OK"
	}
	Catch
	{
		Display  "Sophos $Serverfqdn Name DNS Resolution failed" "NOK"
        $global:ExitCode = "2"
		
	}
}

# This function Collect the Update Console name 
Function Collect-updconsole
{
    $alccontent = Get-Content $alcpath
    [array]$updconsolename=@()
    Foreach ($line in $alccontent) 
    {
     if (($line -match "SAVXP") -and ($line -match "\\")) 
        {
            $line_splitted = $line.split("\\")
            $updconsolename = $line_splitted[2]
            $line_splitted2 = $line -split("SAVXP")
            $cidpath = $line_splitted2[1].trim()
        }else
        {
            if (($line -match "SAVXP") -and ($line -match "http://")) 
                {
                 $line_splitted = $line.split("//")
                 $updconsolename = $line_splitted[2]
                 $line_splitted2 = $line -split("SAVXP")
                 $cidpath = $line_splitted2[1].trim()
                }
        }
    }
    
    $updconsolename=$updconsolename | sort-object -unique
    Display  "The Sophos update server is $updconsolename"
    $global:updconsolename = $updconsolename
    $:cidpath = $cidpath | sort-object -unique    
    $global:cidpath = $cidpath
}


### This Function Display the date of virus definition
Function Show-SAVUpdateTime

{
	Try
	{
    
        $componentMgr = New-Object -ComObject Infrastructure.ComponentManager.1
        $configMgr = $componentMgr.FindComponent("ConfigurationManager")
        $node = $configMgr.GetNode(2,"ProductInfo/updateDate")
 
        #rebuild $SAVUpdateTime to a real date to compare it with the current date
        if([INT]($node.GetAttributeValue("day")) -le "9"){$global:SAVUpdateTimeday = "0" + $node.GetAttributeValue("day")}Else{$global:SAVUpdateTimeday = $node.GetAttributeValue("day")}
        if([INT]($node.GetAttributeValue("month")) -le "9"){$global:SAVUpdateTimemonth = "0" + $node.GetAttributeValue("month")}Else{$global:SAVUpdateTimemonth = $node.GetAttributeValue("month")}
        $global:SAVUpdateTimeyear = $node.GetAttributeValue("year")
        if([INT]($node.GetAttributeValue("hour")) -le "9"){$global:SAVUpdateTimehour = "0" + $node.GetAttributeValue("hour")}Else{$global:SAVUpdateTimehour = $node.GetAttributeValue("hour")}
        if([INT]($node.GetAttributeValue("minute")) -le "9"){$global:SAVUpdateTimeminute = "0" + $node.GetAttributeValue("minute")}Else{$global:SAVUpdateTimeminute = $node.GetAttributeValue("minute")}
        if([INT]($node.GetAttributeValue("second")) -le "9"){$global:SAVUpdateTimesecond = "0" + $node.GetAttributeValue("second")}Else{$global:SAVUpdateTimesecond = $node.GetAttributeValue("second")}

        $global:SAVUpdateTimetemp = $SAVUpdateTimeyear + $SAVUpdateTimemonth + $SAVUpdateTimeday + $SAVUpdateTimehour + $SAVUpdateTimeminute + $SAVUpdateTimesecond
        #[System.Management.ManagementDateTimeConverter]::ToDateTime($SAVUpdateTimetemp).ToUniversalTime();
        [datetime]$global:SAVUpdateTime = [datetime]::ParseExact($SAVUpdateTimetemp,"yyyyMMddHHmmss",$null)
        
        #Compare with current date, if the difference is more than 24 hours then indicate this is too old 
        
        if($SAVUpdateTime -gt (Get-Date).AddHours(-24)) 
        {
            Display  "The SAV update time is $SAVUpdateTime" "OK"
            $global:Sophosupdate = $true
        }Else
        {
            Display  "The SAV update time is too old: $SAVUpdateTime" "NOK"
            $global:ExitCode = "2"
        }

    }Catch
    {
        Display "Sophos Antivirus is not properly installed, you should redeploy it" "NOK"
    }

    Display  "The Cid Path is $cidpath"
    If($Sophosupdate -ne $true)
    {
        If($cidpath.contains("//"))
        {
            Check-ServerConnectivity $updconsolename 80
        }ElseIf($cidpath.contains("\\"))
        {
            Check-ServerConnectivity $updconsolename 445
        }
        #Check that the $cidpath is reachable
        CheckUrl $cidpath	
        If($httpavailable -eq "Yes")
        {
            Display  "$cidpath is reachable" "OK"
        }Else
        {
            Display  "$cidpath is not reachable" "NOK"
            $global:ExitCode = "2"
        }
    }
}

# This function Collect the management Console name and cid information
Function Collect-mgmtconsole
{
    $alccontent = Get-Content $mrinitpath
    [array]$Tabmgmtconsolename=@()
    Foreach ( $line in $alccontent) 
    {
        if ($line -match "MRParentAddress" ) 
        {
            $line_splitted2 = $line.split("=")                        
            $line_splitted = ($line_splitted2[1]).split(",")
            $global:Tabmgmtconsolename2 = $line_splitted[2] 
            if($line_splitted[2] -eq $null)
            {
                $global:Tabmgmtconsolename2 = $line_splitted[1]
                if($line_splitted[1] -eq $null)
                {
                    $global:Tabmgmtconsolename2 = $line_splitted[0]
                }
            }
        }
        if ($line -match "ParentRouterAddress" )
        {
            $line_splitted3 = $line.split("=")
            $global:line_splitted4 = ($line_splitted3[1]).split(",")
                        
            if($line_splitted4[2] -eq $null)
            {
                $global:TabMR = $line_splitted4[0]
            }Else
            {
                $global:TabMR = $line_splitted4[2]                   
            }     
        }

    }   
    $Tabmgmtconsolename = $Tabmgmtconsolename2 | sort-object -unique
	[String]$TmpString = $Tabmgmtconsolename
	# We delete the character "
    If($TmpString.contains('"')){$TmpString = $TmpString -replace '"',""}
	$global:mgmtconsolename = $TmpString
    Display "The Management console is $global:mgmtconsolename "

    if($line_splitted2[1] -ne $line_splitted3[1])
    {
        $TabMR = $TabMR | sort-object -unique
		[String]$TmpString2 = $TabMR
		# We delete the character "
        If($TmpString2.contains('"')){$TmpString2 = $TmpString2 -replace '"',""}
		$global:MRname= $TmpString2
        Display "Sophos Message Relay $MRname is used"              

    }Else
    {
        $global:MRname = ""
    } 

}


### This Function check the connectivity to the console server 
Function Check-ServerConnectivity
{
	param(
	[String]$Server,
	[Int]$Port
	)
		# Create a Net.Sockets.TcpClient object to use for
        # checking for open TCP ports.
        $Socket = New-Object Net.Sockets.TcpClient
        
        # Suppress error messages
        $ErrorActionPreference = 'SilentlyContinue'
        
        # Try to connect
        $Socket.Connect($Server, $Port)
        
        # Make error messages visible again
        $ErrorActionPreference = 'Continue'
        
        # Determine if we are connected
        if ($Socket.Connected) 
		{
            $Socket.Close()
			Display  "The flow TCP $Port is open with $Server" "OK"
            $global:flowopen = $true
        }Else
		{
			Display  "The flow TCP $Port is closed with $Server" "NOK"
            $global:ExitCode = "2"
            $global:flowopen = $false
        }
        
        # Resetting the variable
        $Socket = $null
}

### This function check if URL exist
Function CheckUrl
{
	param(
	[String]$Url
	)
	
	# Create Object System.Net.WebRequest to check URL
	$WebRequest = [System.Net.WebRequest]::Create($Url)
	
	Try
	{
		$WebResponse = $WebRequest.GetResponse() | Out-Null
        $global:httpavailable = "Yes"

	}
	Catch
	{
		$ErrorMessage=$_.Exception.Message
		$global:httpavailable = "No"
	}
}

# This function Check if the current user as the right to uninstall Sophos Anti-Virus
Function Check-onaccess

{
    $global:onaccesscheck = ((((((($machinexml.configuration).scanTemplates).onAccessScan).TDE).processors).item).settings)
    if($onaccesscheck -eq $null) 
    {
    
        $onaccesschecktemp = (((((($machinexml.configuration).scanTemplates).onAccessScan).TDE).processors).item)
        $global:onaccesscheck = ($onaccesschecktemp | Where-object {$_.itemname -eq "DriverOperations"}).settings    
    
    }      
    if($onaccesscheck.running -eq "true")
    {

        if($onaccesscheck.OnReadCheck -eq "true")
        {
            if($onaccesscheck.OnWriteCheck -eq "true")
            {
                if($onaccesscheck.OnRenameCheck -eq "true")
                {
                    Display  "On-access scan on Read/Write/Rename files is enabled" "OK"
                }Else
                {
                    Display  "On-access scan on Read/Write files is enabled but it is also recommended to scan files on rename" "WARNING"
                    $global:ExitCode = "1"
                }
            }Else
            {
                Display  "On-access scan on Read files is enabled but it is also recommended to scan files on Write/Rename" "WARNING"
                $global:ExitCode = "1"
            }
        }
    }Else
    {
        Display  "On-access scan is not enabled, it is not recommended on a Windows OS!" "NOK"
        $global:ExitCode = "2"        
    }
}

# This function Check if the current user as the right to uninstall Sophos Anti-Virus
Function Check-uninstalluserrights

{
		$LocalGroup = "Administrators"
		$LocalGroup2 = "SophosAdministrator"
		$Group = [ADSI]"WinNT://$ComputerName/$LocalGroup,group"
		$Group2 = [ADSI]"WinNT://$ComputerName/$LocalGroup2,group"
		$Members = @($Group.psbase.Invoke("Members"))
		$Members2 = @($Group.psbase.Invoke("Members"))
		$Members | ForEach-Object {[String[]]$MemberNames += $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}
		$Members2 | ForEach-Object {[String[]]$MemberNames2 += $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}

		# If the current user is member of SophosAdministrator he can launch the uninstallation
		If($MemberNames -Contains $CurrentUsername -And $MemberNames2 -Contains $CurrentUsername)
		{
			Display  "Your user has the rights to uninstall the agent present on this server" "OK"					
		}Else
		{
			Display  "Your current profile hasn't sufficient rights to uninstall Sophos"
		}
}

################################################################################
#     		Main Script
################################################################################
If($Shinken -eq $False)
{
    Display  "Script version : $Version"
    # Create the transcript log file
    New-Item -type file -Name "check_SophosAgentstatus.log" -Force
    sleep 2
    Start-Transcript -Path "check_SophosAgentstatus.log" -Force
    cls

    Write-Host "#######################################################################`n---> Begin of check_SophosAgentStatus script`n#######################################################################"

}

# Check if the server is a Windows 2003
If($OSVersion -eq "5")
{
    Display "Non-supported Operating System version" "WARNING"
    EndScript(1)
}

# Check if a reboot is required
$rebootregkey = get-itemproperty -path registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Sophos\AutoUpdate\UpdateStatus\VolatileFlags" -ErrorAction SilentlyContinue

If($rebootregkey.RebootRequired -eq "1")
{
    Display "A reboot is required to benefit of all functionalities" "WARNING"
    $global:rebootrequiered = "Yes"
    $global:ExitCode = "1"
}

# Check if Sophos is present
   
$RegistryViews = @('','Wow6432Node')
foreach ( $RegistryView in $RegistryViews )
{
    # Get the reg key(s) where add/remove program information is stored.
    $UninstallRegKey="SOFTWARE\" + $RegistryView + "\Microsoft\\Windows\\CurrentVersion\\Uninstall"
    $HKLM = [microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine',$localhost)
    $UninstallRef = $HKLM.OpenSubKey($UninstallRegKey)
    $Applications = $UninstallRef.GetSubKeyNames()

    # Now we have the registry locations, call the function which will enumerate the applications on this PC
    [Array]$apps = Get-InstalledApps
    If($Apps)
    {
	    # Get all programs names
	    ForEach ($App in $Apps) 
        {
            $Sophosapp = ($App | Where-Object {$_.AppVendor -Match "Sophos Limited"}).AppName

            if ($Sophosapp -Match "Sophos Anti-Virus")
            {
				$Sophospresence = "OK"
                $global:sophosAVsvc = "Sophos Anti-Virus"
                $global:sophosWebsvc = "Sophos Web Intelligence Service"
            }
            
            if ($Sophosapp -Match "Sophos AutoUpdate")
            {
                $global:Autoupdatesvc = "Sophos AutoUpdate Service"
            }

            if ($Sophosapp -Match "Sophos Remote Management System")
            {
				$global:sophosRMSsvc = "Sophos Message Router"
            }
               
            if ($Sophosapp -match "Sophos Endpoint Defense")
            {
                $global:tamperprotection = "available"
            }

            if ($Sophosapp -Match "Sophos System Protection")
            {
				$global:SophosSystemProtectsvc = "Sophos System Protection Service"
            }
                        
            if ($Sophosapp -Match "Sophos Clean")
            {
                $global:Sophoscleansvc = "Sophos Clean Service"
            }

            if ($Sophosapp -Match "Sophos CryptoGuard")
            {
                $global:cryptoguardsvc = "hmpalertsvc"
            }

            #Check if it is a Sophos Enterprise Console server
            if ($Sophosapp -Match "Sophos Management Server")
            {
                $global:consoleserverprog = "Sophos Management Service"
                Display  "This server is a Sophos Enterprise Console"                   
            }

        }
    }
}

If($Sophospresence -eq "OK")
{
    If($sophosAVsvc -eq "Sophos Anti-Virus")
    {
        Check-service $sophosAVsvc
        Check-service $sophosWebsvc
    }
    If($Autoupdatesvc -eq "Sophos AutoUpdate Service")
    {
        Check-service $Autoupdatesvc
    }
    If($sophosRMSsvc -eq "Sophos Message Router")
    {
        Check-service $sophosRMSsvc
        # Sophos is not a Stand alone version
        $Standalone = $False
    }  
    If($SophosSystemProtectsvc -eq "Sophos System Protection Service")
    {
        Check-service $SophosSystemProtectsvc
    }
    If($Sophoscleansvc -eq "Sophos Clean Service")
    {
        Check-service $Sophoscleansvc
    }
    If($cryptoguardsvc -eq "hmpalertsvc")
    {
        if(test-path "C:\Program Files (x86)\HitmanPro.Alert\hmpalert.exe")
        {
            #Check-service "$cryptoguardsvc"
            [string]$global:Exploitprevversion= [System.Diagnostics.FileVersionInfo]::GetVersionInfo("C:\Program Files (x86)\HitmanPro.Alert\hmpalert.exe").FileVersion
            Display  "Exploit prevention version $Exploitprevversion is deployed on this server" "OK"
        }Else
        {
            Display  "Unable to find Exploit prevention files on this server" "NOK"
        }
    }
	
}Else
{
	Display  "No Sophos Endpoint protection program has been found" "WARNING"
    EndScript(1)
}

# Set variables depending of the OS and the architecture
Set-Variables


If(($Standalone -eq $false) -or ($consoleserverprog -eq "Sophos Management Service"))
{
	# Check Services
	Check-Service "Sophos Agent"
	Check-Service "Sophos Anti-Virus status reporter"

    # Show Update console name
    Collect-updconsole

    if($mrinitpath -ne $null)
    {
        # Show management console name
	    Collect-mgmtconsole

	    ############ check communication between agent and console: ############
	    # Check the DNS resolution if the powershell version is superior to 1
	    If($powershellversion -gt "1") 
        {
            if($MRname -ne "")
            {
	            CheckDNS($MRname)        
            }Else
            {
	            CheckDNS($mgmtconsolename)
            }        
        }
    
        # Check if the port on the Sophos Console are open !
        if($MRname -ne "")
        {
	        Check-ServerConnectivity $MRname 8192
            if($global:flowopen -eq $true){Check-ServerConnectivity $MRname 8194}    
        }Else
        {
	        Check-ServerConnectivity $mgmtconsolename 8192
	        if($global:flowopen -eq $true){Check-ServerConnectivity $mgmtconsolename 8194}
        }
    }
}

# Show Sophos version number
if($global:rightswarning -eq $false)
{
    Display  "Sophos Anti-virus version installed is $sophosversion"
}

# Show the Virus definition last update date !   
Show-SAVUpdateTime 

# Check if on-access scan is activated
Try{
        [xml]$global:machinexml = Get-Content "C:\ProgramData\Sophos\Sophos Anti-Virus\Config\machine.xml"
        check-onaccess
}Catch
{
    Display "Impossible to check the machine.xml file" "WARNING"
    $global:ExitCode = "1"
    $global:machinexmlpresence = $false
}  

# Check if the savlogfile is readable
Try
{
     
    $global:SAVLOG = Get-Content -path "C:\ProgramData\Sophos\Sophos Anti-Virus\logs\SAV.txt" | where { $_ -ne "$null" }

}Catch
{
    Display "Impossible to find all the information in the SAV.txt log file" "WARNING"
    $global:ExitCode = "1"
    Display "Check that this file is present and accessible"
}

# Check if a virus was detected in the SAVlogfile in the last 24h

If($SAVLOG ){

    $SAVLOG | foreach { 

    $SAVLOG = $_ 

    #set the $savhistorydate the number of day(s) before today (-1 per default, otherwise $Daysdiff variable) :
    $savhistorydate = ((Get-Date).AddDays(-$Daysdiff)).ToString("yyyyMMdd")
    $savhistorydate = [Datetime]::ParseExact($savhistorydate,'yyyyMMdd', $null)

    #Recover each SAVLOG file lines which are compatible with a date format and compare it to the wanted date of infection: 
    $eventdate = $SAVLOG.substring(0,8)
        
    Try
    {
        $eventdate = [Datetime]::ParseExact($eventdate,'yyyyMMdd', $null)
        $tdiff = New-TimeSpan -Start $eventdate -End $savhistorydate
        $Nb_jour = $tdiff.Days

    }Catch
    {
        
    }
  
    If ($Nb_jour -lt "0")
    { 
        If ($SAVLOG.contains("virus") -or $SAVLOG.contains("spyware") -or $SAVLOG.contains("adware") -or $SAVLOG.contains("PUA") -or $SAVLOG.contains("suspicious"))
        {
            if($SAVLOG.contains('has denied access') -or ($SAVLOG.contains('a refus� l')))
            {
                $blocked = "yes"
            }
            if($SAVLOG.contains('has been cleaned up') -or ($SAVLOG.contains('a �t� nettoy�')))
            {
                $cleaned = "yes"
            }
            if($SAVLOG.contains('belongs to authorized') -or ($SAVLOG.contains('autoris�')))
            {
                $authorized = "yes"
            }
    
            If($cleaned -eq "yes")
            {
                $global:malwaremessage = $SAVLOG
                $global:ExitCode = "1"              
            }Else
            {
                If($blocked -eq "yes")
                {
                    $global:malwaremessage = $SAVLOG
                    $global:ExitCode = "1"          
                }Else
                {
                    If($authorized -eq "yes")
                    {
                        $global:malwaremessage = $SAVLOG
                        $global:ExitCode = "1"            
                    }Else               
                    {
                        $global:malwaremessage = $SAVLOG
                        $global:ExitCode = "2"
                    }
                }
            }
        }Elseif($SAVLOG.contains('has denied access') -or ($SAVLOG.contains('a refus� l')) -or $SAVLOG.contains('has been cleaned up') -or ($SAVLOG.contains('a �t� nettoy�')) -or $SAVLOG.contains('belongs to authorized') -or ($SAVLOG.contains('autoris�')))
        {
            $global:malwaremessage = $SAVLOG
            $global:ExitCode = "1" 
        }

    }
    }

    if($malwaremessage -ne $null)
    {
        if($ExitCode -eq "1"){Display $malwaremessage "WARNING"}
        if($ExitCode -eq "2"){Display $malwaremessage "NOK"}
    }
    
}

#Check the tamper protection
If($global:tamperprotection -eq "available")
{
    If($machinexmlpresence -eq $false)
    {
        Display "Impossible to check the machine.xml file" "WARNING"
        $global:ExitCode = "1"

    }Else
    {
        if((((($machinexml.configuration).components).TamperProtectionManagement).settings).enabled -eq "true")
        {
            Display  "Tamper protection is enabled" "OK"
            Display  "The Sophos Services and Uninstallation product are protected by a tamper password!" "OK"
            Display  "You must deactivate it if you program to uninstall Sophos product"
        }Else
        {
            Display  "Tamper protection is not enabled, you can uninstall with administrator rights" "OK"
            ############ check current user rights to uninstall product ############"
	        # Check If user has the Sophos Uninstall Agent rights
	        Check-uninstalluserrights
        }       
    }

}Else
{
    Display  "Tamper protection program is not present, you can uninstall with administrator rights" "OK"
    ############ check current user rights to uninstall product ############"
	# Check If user has the Sophos Uninstall Agent rights
	Check-uninstalluserrights
}
    
EndScript($exitcode)
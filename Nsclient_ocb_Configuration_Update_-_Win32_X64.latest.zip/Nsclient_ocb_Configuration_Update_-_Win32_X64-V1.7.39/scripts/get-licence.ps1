<#
.SYNOPSIS
This script give the status of the os licencing.

.DESCRIPTION
This script give the status of the os licencing.
It is mainly used by shinken but can be also used by end users.

For the shinken mode output is :
0 : licenced server - OK
1 : grace period - Warning
2 : unlicenced server - Critical


computer   Description                                              ApplicationId                        LicenseStatus
--------   -----------                                              -------------                        -------------
MyComputer Windows Operating System - Windows(R) 7, OEM_SLP channel 55c92734-d682-4d71-983e-d6ec3f16059f Licensed

.PARAMETER fromShinken
This parameter ask the script to check the licence of the local host, and return the shinken code.

.PARAMETER ComputerName
The parameter ComputerName is used to define the value of computer to request.
This can be parse thru the pipeline.

.EXAMPLE
The example below get the licence status for the current cumputer 
PS C:\> get-icence.ps1

computer                  Description                                  KeyManagementServiceMachine                  LicenseStatus
--------                  -----------                                  ---------------------------                  -------------
VD-EQV401310024           Windows Operating System - Windows(R) 7, ... SIKMSF01.corporate.adroot.infra.ftgroup      Licensed


.EXAMPLE
The example below get the licences status for the hosts given thru the pipeline
PS C:\> Get-MyListofComputers | get-icence.ps1

computer       Description                                  KeyManagementServiceMachine                  LicenseStatus
--------       -----------                                  ---------------------------                  -------------
Computer2      Windows Operating System - Windows(R) 7, ... SIKMSF01.corporate.adroot.infra.ftgroup      Licensed
Computer3      Windows Operating System - Windows(R) 7, ...                                              Unlicensed
Computer4      Windows Operating System - Windows(R) 7, ... SIKMSF01.corporate.adroot.infra.ftgroup      Licensed
Computer5      Windows Operating System - Windows(R) 7, ... SIKMSF01.corporate.adroot.infra.ftgroup      Licensed
Computer1      Windows Operating System - Windows(R) 7, ... SIKMSF01.corporate.adroot.infra.ftgroup      Licensed

.NOTES
Author: CDS - PEIPS SII
Last Edit: 2018-01-05
Version 1.0 - initial release
#>

param (
    [parameter(Position=0, ValueFromPipeline=$true,
    ValueFromPipelineByPropertyName=$true)]
    [string]$computername="$env:COMPUTERNAME",
    [switch] $fromShinken
)

Begin {

# readable values for license code
$licence_code_txt = @'
0 = Unlicensed (Activation status cannot be determined. It may indicate tampering of activation related binaries and configuration values.)
1 = Licensed (Have been activated by a valid product key)
2 = Out-of-Box (OOB) Grace (Still within the initial grace period allowed by Windows)
3 = Out of Tolerance (OOT) Grace (Hardware or BIOS changes significant enough to require reactivation. Or KMS client have not renewed his activation within the 180 days.)
4 = Non-Genuine Grace (Applicable only to systems running Windows Vista RTM edition)
5 = Notification (Either past the activation grace period or failed validation. Is subject to a notification experience but continue to run with full functionality.)
6 = Extended Grace (Grace period was manually extended.)
'@

    $lstat =  ConvertFrom-StringData -StringData $licence_code_txt
        
    $SHINKEN_OUTCODE_OK = "0"
    $SHINKEN_OUTCODE_WARNING = "1"
    $SHINKEN_OUTCODE_ERROR = "2"
    $shinken_out_code = $SHINKEN_OUTCODE_OK

    # array used for the output, usefull is the computerlist is given thru the pipe
    $outItems = New-Object System.Collections.Generic.List[System.Object]
}

Process {
    # get wmi license information for the OS and change licenceStatus code to readable information
    $licences = Get-WmiObject SoftwareLicensingProduct -ComputerName $computername |
        Where-Object {$_.PartialProductKey -and ($_.Description -like "windows*" )} |
        Select-Object @{N="Computer"; E={$computername}},Description, KeyManagementServiceMachine,LicenseStatus,
        @{N="LicenseMessage"; E={$lstat["$($_.LicenseStatus)"]}}
    if ($shinken_out_code -eq $SHINKEN_OUTCODE_OK) {
        switch ($licences.LicenseStatus) {
            "1"  { $shinken_out_code = $SHINKEN_OUTCODE_OK }
            default  { $shinken_out_code = $SHINKEN_OUTCODE_ERROR }
        }
    }

    #add license information to the output object
    $outItems.Add($licences)
}

End {
    if ($fromShinken) {
        $_txt = $outItems[0].LicenseMessage
        switch ($shinken_out_code) {  
            $SHINKEN_OUTCODE_ERROR {$outText = "KO - "+$_txt}
            $SHINKEN_OUTCODE_OK {$outText = "OK - "+$_txt}
            $SHINKEN_OUTCODE_WARNING {$outText = "Warning - "+$_txt}
        }
        Write-Output $outText
        exit  $shinken_out_code 
    }
    else {
        write-output $outItems | Format-Table -wrap
        exit  $shinken_out_code 
    }
}
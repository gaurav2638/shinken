#!/usr/local/bin/seppperl
#!/usr/local/bin/seppperl -d:ptkdb
#---------------------------------------------------------------------
# "@(#) $Id: sealplugin.pl,v 1.26 2018/02/09 18:08:10 juergen Exp $"
#---------------------------------------------------------------------
# "@ $Id: sealplugin.pl,v 1.26 2018/02/09 18:08:10 juergen Exp $"  
# 
# CVS Log at EOF

use strict;
use warnings;
use Getopt::Long;
use Data::Dumper;
use DBI;
use Sys::Hostname;
use File::Basename;
use Date::Parse;
use seppperl::msghandler;
use startstop::exclude;

my $reterr = 3;  #if script cannot continue: return 3  (Nagios UNDEFINED)
my $statusmapFACTORY = "1122111010"; # used if anything else failed
my $statusmaplength = 10;

{
my $help;
my $dbport;
my $diagnose;
my $showinc;
my $appname;
my $appport;
my $servicename;
my $procname;

my $allProcesses;
my $statname;
my $warnth;
my $critth;
my $statusmap;
my %config;
my $message;
my @applicationlist;
my $systemid;
my $sql;
my $ref;
my $sealstatus;
my $dbh;
my $nagiosStatus;
my $nagiosPerform;
my  $ldlpath;

my $dbhost = lc hostname;
my $dbhostAlias;
my $dbname = "seal";
my $dbuser = "sysmon";
my $dbpasswd = "";

addMessageTable("os", GetLocalMessages());

 
# Read Options
my $result = GetOptions (
                "h"                   => \&showHelp,      #help/usage
                "history"             => \&history,       #cvs history
                "v"                   => \&showVersion,   #cvs version
                "dbport:i"            => \$dbport,        #database port  (DBserver = localhost:dbport) 
                "diagnose"            => \$diagnose,      #output diagnose information
                "showinc"             => \$showinc,       #output perl include paths (only for bugtracking)
                "application:s"       => \$appname,       #select application
                "appport:i"           => \$appport,       #select port of application
                "service:s"           => \$servicename,   #select service of application
                "process:s"           => \$procname,      #select process name
                "statistics:s"        => \$statname,      #select ststistics name
                "allprocess"             => \$allProcesses,  #select complete status of all processes
                "warnthreshold:s"     => \$warnth,
                "criticalthreshold:s" => \$critth,
                "statusmapping:s"     => \$statusmap,
);

# Options wrong? -> exit
if (!$result)
    {
    $message = gettext("OptionsError");
    print $message;
    exit($reterr);
    }

#bugtracking    
if ($showinc)
    {
    print "Bugtracking Information:\n INC=";
    print Dumper @INC;
    print "\n";
 
    print "LD_LIBRARY_PATH="; 
    print Dumper $ENV{LD_LIBRARY_PATH};
    print "\n";
    exit(0);
    }
    
# No Function selected?    
if (!$diagnose and !$procname and !$statname and !$servicename and !$allProcesses) 
    { exit showHelp(); }

        
# Conflicting Options: process and statistics? -> exit
if ($procname and $statname)
    {
    $message = gettext("OptionsConfl");
    print $message;
    exit($reterr);
    }
    
# determine port to database
if (!$dbport) {$dbport = $ENV{SEALDBPORT}};
if (!$dbport)
    {
    $message = gettext("DbportNotSet");
    print $message;
    exit($reterr);
    };

# output diagnose information?   
my %dbData = ( HOST     => $dbhost,
               PORT     => $dbport,
               NAME     => $dbname,
               PASSWORD => $dbpasswd,
               USER     => $dbuser,
             );

if ($diagnose)
    {
    exit outputDiagnosis (\%dbData);
    }

# output process or statistics information?   
if ($procname or $statname or $servicename or $allProcesses)
    {
    outputNagiosSystemMonintoringInfo(\%dbData);
 
    # connect to database
    $dbh = dbConnect($dbname, "localhost", $dbport, $dbuser, $dbpasswd);
    if (!$dbh)
        {
        exit printErrorStatus("ConnectFail", "ERROR", $statusmap);
        }
   
    $systemid = getSystemid($dbh, $dbData{HOST}, $appname, $appport);
    %config = getConfigurationFromDatabase($dbh, $systemid);
    $nagiosStatus = validateConfiguration(systemId => $systemid, config => \%config, statusmap => $statusmap);
    if ( $nagiosStatus )
        {
        $dbh->disconnect;
        exit ($nagiosStatus);
        }
       
    my $determineNagiosStatusAndMessage = 1; 
    if ($procname)
        {
        ($sealstatus, $message) = getProcessStatus (dbHandle => $dbh, systemid => $systemid,  process => $procname, service => $servicename, config => \%config);
        }
    elsif ($statname)
        {
        # look for statistic information
       ($sealstatus, $message, $determineNagiosStatusAndMessage, $nagiosStatus) =
           getStatisticStatus(config => \%config, dbHandle =>$dbh,  systemid => $systemid, 
                                            statistic => $statname, service => $servicename,
                                            criticalThreshold => $critth, warningThreshold => $warnth);
        }
    elsif ($servicename)
        {
        ($sealstatus, $message) = getStatusOfSubSystem(systemid => $systemid, dbHandle => $dbh, subsystem => $servicename, config => \%config); 
        }
    elsif ($allProcesses)
        {
        ($sealstatus, $message) = getStatusOfCompleteSystem(systemid => $systemid, dbHandle => $dbh, config => \%config); 
        }

    # Build Nagios Message and Status, then exit.
    if ( $determineNagiosStatusAndMessage )
        { 
        $nagiosStatus = NagiosMessageAndStatus($message, $sealstatus, $statusmap, $config{NAGIOS_STATUSMAPPING});
        }
        
   #  This is the main info printed to STDOUT. It is evaluated by NAGIOS  
    print $message;
    
    # close connection
    $dbh->disconnect;
    }
else
    {
    showHelp();
    $nagiosStatus = $reterr;
    }
    
exit ($nagiosStatus);    
}
 
#------------------------------ end of main  ------------------------------------------------------------------ 
# 

#----------------------------------------------------------------------------------
#----------------------------------------------------------------------------------
sub isMaintenanceOn
    {
    my ($rh_Config) = @_;

    $rh_Config && (ref ($rh_Config) eq 'HASH') && $rh_Config->{MAINTENANCE} && ($rh_Config->{MAINTENANCE} =~ /\bON\b/i);
    }

#----------------------------------------------------------------------------------
# Pusrpose  : Test, if timestamp is inside a given intervall
# Parameters: $lastTimestamp - a date like '2018-02-09 15:23:21.332'
#           : $interval      - interval in minutes
# Return    : 0 => outdated , else up to date
#----------------------------------------------------------------------------------
sub isDatabaseInfoUpToDate
    {
    my ($lastTimestamp, $interval) = @_;

    if ($interval)
        {
        return time() - str2time($lastTimestamp) < max(60,180*$interval) ;
        }
    else
        {
        return 0;
        }
    }

#----------------------------------------------------------------------------------
# Pusrpose  : Test, if timestamp is inside a given intervall.
# Parameters: $lastupdated - epoche time, time in ticks (seconds)
#           : $interval   - interval in minutes
# Return    : 0 => outdated , else up to date
#----------------------------------------------------------------------------------
sub is_Database_Table_Systemstatus_UpToDate {
    my ($lastupdated, $interval) = @_;

	return 0 if ($lastupdated < 0);
	
    if ($interval) {
        return time() - $lastupdated < max(60,180*$interval) ;
        }
    else {
        return 0;
    }
}	
	
#----------------------------------------------------------------------------------------------------
# New subroutine "getStatisticStatus" extracted - Mon Apr 13 19:17:55 2015.
#
#   getStatisticStatus(config => \%config dbHandle =>$dbh,  systemid => $systemId, 
#                                 statistic => $statname, service => $servicename,
#                                 criticalThreshold => $critth, warningThreshold  => $warnth);
#----------------------------------------------------------------------------------------------------
sub getStatisticStatus {
    my (%param) = @_;

    my $Fct = (caller(0))[3];   
    my $rh_config = $param{config};
    
    if (! $param{statistic} || ! $param{dbHandle} || ! $param{systemid})  {die "$Fct: ERROR: missing parameter!\n" ;}
    if ( ref($rh_config) ne 'HASH')  {die "$Fct: ERROR: missing parameter config!\n" ;}    
    
    my $systemid = $param{systemid};
    my $servicename =  $param{service};
    my $dbh = $param{dbHandle};

    my ($sealstatus, $message, $nagiosPerform, $nagiosStatus);
    my $determineNagiosStatusAndMessage = 1;
    
    my $ref = getStatisticInfoFromDb(dbHandle => $param{dbHandle}, systemid => $param{systemid}, 
                                                    statistic => $param{statistic}, service => $param{service});         
                                                    
    my $statisticKey = 0;                                                
    my $service = 1;
    my $statisticValue = 2;
    my $lasttimestamp = 3;
    
    if (!@{$ref})
        {
        #nothing found
        $message = gettext("NoStatistics");
        $sealstatus = "UNKNOWN"
        }
    else
        {
        #deliver first hit in database (discard rest)
        $message = gettext("StatisticId");
        $message .= ": @{@{$ref}[0]}[$statisticKey]   ".gettext("Value").": @{@{$ref}[0]}[$statisticValue]   ";
        $nagiosPerform = "|@{@{$ref}[0]}[$statisticKey]=@{@{$ref}[0]}[$statisticValue]";
        
        # Test for Maintenance Mode
        if ( isMaintenanceOn($rh_config) )
            {
            $sealstatus = "MAINTENANCE"
            }
        else
            {
            #Test for Outdated Information
            my $lastTimestamp = @{@{$ref}[0]}[$lasttimestamp];
            if (isDatabaseInfoUpToDate($lastTimestamp, $rh_config->{PLOSSYS_STATISTIC_INTERVAL}) )
                {
                $nagiosStatus = testThreshold($message, @{@{$ref}[0]}[2], $param{warningThreshold}, $param{criticalThreshold});
                $determineNagiosStatusAndMessage = 0;
                $message .= $nagiosPerform;
                }
            else
                {              
                $sealstatus = "OUTDATED"
                }
            }
        }
    return ($sealstatus, $message, $determineNagiosStatusAndMessage, $nagiosStatus);
}

#---------------------------------------------------------------------------------------------------
# Purpose   : New subroutine "getProcessStatus" extracted - Mon Apr 13 17:27:00 2015.
#             Get status of one process in table 'systemstatus' (database 'system')
# Parameters: hash 
#               process  => search for this process name in table 'systemstatus'
#               dbHandle => valid database handle to database 'system'
#               systemid => System ID of running system stored in table 'systemstatus'
# Return: array[0] : status of required subsystem
#         array[1] : text message with additional information
#---------------------------------------------------------------------------------------------------
sub getProcessStatus {
    my (%param) = @_;

    my $Fct       = (caller(0))[3];   
    my $rh_config = $param{config};
    my ($sealstatus, $message);
    
    if (! $param{process} || ! $param{dbHandle} || ! $param{systemid})
	    { die "$Fct: ERROR: missing parameter!\n" ;}
    if (! $rh_config || ref($rh_config) ne 'HASH')  
	    {die "$Fct: ERROR: missing parameter!\n" ;}
        
    my $ref = 
	    getProcessInfoFromDb(dbHandle => $param{dbHandle}, 
                             systemid => $param{systemid}, 
                             process  => $param{process} ,
							 service => $param{service}
	);
                                                
    my $processStatus = 2;         
    my $last_updated  = 5;                                                            
    if (!@{$ref}) {
        # nothing found on database
        $message = gettext("PInfoNotFound");
        $sealstatus = "UNKNOWN"
    }
    else {
        $message = buildProcessMessage ($ref);
        if ( isMaintenanceOn($rh_config) ) {
            $sealstatus = "MAINTENANCE"
        }
        else {
            # Test, if table entries are up-to-date or outdated.
            my $last_updated = @{@{$ref}[0]}[$last_updated];
            if (is_Database_Table_Systemstatus_UpToDate($last_updated, $rh_config->{PLOSSYS_STATUS_INTERVAL}) ) {
                $sealstatus = @{@{$ref}[0]}[$processStatus]
            }
            else {                
                $sealstatus = "OUTDATED"
            }
        }
    }
    return ($sealstatus, $message);
}

#---------------------------------------------------------------------------------------------------------------
# Collect status of all processes belonging to one subsystem (table column service)
#
# Return: array[0] : status of required subsystem
#              array[1] : text message with additional information
#---------------------------------------------------------------------------------------------------------------
sub getStatusOfSubSystem
    {
    my (%param) = @_;
    my $rh_config = $param{config};

    my $Fct = (caller(0))[3]; 
    
    if (! $param{subsystem} || ! $param{dbHandle} || ! $param{systemid})  {die "$Fct: ERROR: missing parameter!\n" ;}
    if (! $rh_config || ref($rh_config) ne 'HASH')  {die "$Fct: ERROR: missing parameter!\n" ;}

    my $subsystemStatus;
    my $message = "";
    my $ra_SubsystemProcessList = getSubsystemProcessListFromDb(%param); 
    if (ref ($ra_SubsystemProcessList) eq 'ARRAY' && (scalar @$ra_SubsystemProcessList) > 0)
        {
        my $subsystem = 1;
        my $processStatus = 2;
        my $runningProcessCounter = 0;
        my $last_updated = $ra_SubsystemProcessList->[0]->[5];

        if ( isMaintenanceOn($rh_config) )
            {
            $subsystemStatus = "MAINTENANCE"
            }
        else
            {
            #Test for Outdated Information
            if ( is_Database_Table_Systemstatus_UpToDate($last_updated, $rh_config->{PLOSSYS_STATUS_INTERVAL}) )
                {
                foreach my $process (@$ra_SubsystemProcessList)
                    {
                    $runningProcessCounter++ if ($process->[$subsystem] eq $param{subsystem} && $process->[$processStatus] =~ /RUNNING|OK/gxm);
                    }
                if (scalar @$ra_SubsystemProcessList == $runningProcessCounter)
                    {
                    $subsystemStatus = "RUNNING";
                    $message = "Service: " . $param{subsystem} . " Status: RUNNING";
                    }
                else
                    {
                    $subsystemStatus = "STOPPED";
                    $message = "Service: " . $param{subsystem} . " Status: STOPPED";
                    }
                }
            else
                {                
                $subsystemStatus = "OUTDATED"
                }
            }
        }
    else
        {
        $subsystemStatus = "UNKNOWN";
        $message = "Service: " . $param{subsystem} . "   " . gettext("InfoNotFound");
        }
    
    return ($subsystemStatus, $message);
    }

#-------------------------------------------------------------------------------
#  getStatusOfCompleteSystem(systemid => $systemid, 
#                                                   dbHandle => $dbh,
#                                                   config => \%config); 
#
# Return: array[0] : status of required subsystem
#              array[1] : error text message with additional information
#-------------------------------------------------------------------------------
sub getStatusOfCompleteSystem
    {
    my (%param) = @_;
    my $rh_config = $param{config};
    
    my $Fct = (caller(0))[3]; 
    
    if (! $param{dbHandle} || ! $param{systemid})
        {die "$Fct: ERROR: missing parameter!\n" ;}
    if (! $rh_config || ref($rh_config) ne 'HASH') 
        {die "$Fct: ERROR: missing parameter!\n" ;}

    my $subsystemStatus;
    my $message = "";
    my $ra_SubsystemProcessList = getAllProcessFromDb(%param); 
    if (   ref ($ra_SubsystemProcessList) eq 'ARRAY'
        && (scalar @$ra_SubsystemProcessList) > 0)
        {
        my $subsystem = 1;
        my $processStatus = 2;
        my $runningProcessCounter = 0;
        my $last_updated = $ra_SubsystemProcessList->[0]->[5];

        # Test for Maintenance Mode
        if ( isMaintenanceOn($rh_config) )
            {
            $subsystemStatus = "MAINTENANCE"
            }
        else
            {
            #Test for Outdated Information
            if ( is_Database_Table_Systemstatus_UpToDate($last_updated, $rh_config->{PLOSSYS_STATUS_INTERVAL}) )
                {
                foreach my $process (@$ra_SubsystemProcessList)
                    {
                    $runningProcessCounter++ if ($process->[$processStatus] =~ /RUNNING|OK/gxm);
                    }
                if (scalar @$ra_SubsystemProcessList == $runningProcessCounter)
                    {
                    $subsystemStatus = "RUNNING";
                    $message = "Complete system:  Status: RUNNING";
                    }
                else
                    {
                    $subsystemStatus = "STOPPED";
                    $message = "Complete system:  Status: STOPPED";
                    }
                }
            else
                {                
                $subsystemStatus = "OUTDATED"
                }
            }
        }
    else
        {
        $subsystemStatus = "UNKNOWN";
        $message = "Service: " . $param{subsystem} . "   " . gettext("InfoNotFound");
        }
    
    return ($subsystemStatus, $message);
    }

#---------------------------------------------------------------------------
# Example:
# getProcessInfoFromDb(dbHandle => $databaseHandle, systemid >= $id, process => $process, service => $service);
#
# Return: Array ref with found results.
#---------------------------------------------------------------------------
sub getProcessInfoFromDb {
    my (%param) = @_;
    my $Fct = (caller(0))[3]; 

    if (! $param{dbHandle}) {die "$Fct: ERROR: missing parameter 'dbHandle' !\n" ;}    
    if (! $param{systemid})   {die "$Fct: ERROR: missing parameter 'systemid' !\n" ;}
    if (! $param{process}) {die "$Fct: ERROR: missing parameter 'process' !\n" ;}
            
    my $sql ; 
    my @sqlArgs;
	
	# SUE-30277. Don't use row 'lasttimestamp', because it doesn't store the
    # correct date/time in other time zones. Better use local epoche time
    # 'lastupdated'	
    if ($param{service}) {  
         $sql = "select component,service,status,pid,port,lastupdated from systems.systemstatus where systemid=? and component=? and service=?"; 		 
         @sqlArgs = ($param{systemid}, $param{process}, $param{service});
    }    
    else {
        $sql = "select component,service,status,pid,port,lastupdated from systems.systemstatus where systemid=? and component=?";		
        @sqlArgs = ($param{systemid}, $param{process});
    }
    
    return runSqlSelect(dbHandle => $param{dbHandle},sql => $sql, sqlArgs => \@sqlArgs);
}

#---------------------------------------------------------------------------
# Example:
# getStatisticInfoFromDb(dbHandle => $databaseHandle, 
#                                         systemid >= $id, 
#                                         statistic => $statistic, service => $service);
#
# Return: Array ref with found results.
#---------------------------------------------------------------------------
sub getStatisticInfoFromDb
    {
    my (%param) = @_;
    my $Fct = (caller(0))[3]; 

    if (! $param{dbHandle}) {die "$Fct: ERROR: missing parameter 'dbHandle' !\n" ;}    
    if (! $param{systemid})   {die "$Fct: ERROR: missing parameter 'systemid' !\n" ;}
    if (! $param{statistic}) {die "$Fct: ERROR: missing parameter 'statistic' !\n" ;}
            
    my $sql ; 
    my @sqlArgs;
    if ($param{service}) 
    {  
         $sql = "select id,service,value,lasttimestamp from sysmon.statistics where systemid=? and id=? and service=?";
         @sqlArgs = ($param{systemid}, $param{statistic}, $param{service});
    }    
    else
    {
        $sql = "select id,service,value,lasttimestamp from sysmon.statistics where systemid=? and id=?";
        @sqlArgs = ($param{systemid}, $param{statistic});
    }
    
    return runSqlSelect(dbHandle => $param{dbHandle},sql => $sql, sqlArgs => \@sqlArgs);
    }

#---------------------------------------------------------------------------
# Example:
# getSubsystemProcessListFromDb(dbHandle => $databaseHandle,
#                                         systemid >= $id, 
#                                         subsystem => $subsystem);
#
# Return: Array ref with found results.
#---------------------------------------------------------------------------
sub getSubsystemProcessListFromDb
    {
    my (%param) = @_;
    my $Fct = (caller(0))[3]; 
    
    if (! $param{systemid}) 
        {die "$Fct: ERROR: missing parameter 'systemid' !\n" ;}
    if (! $param{subsystem})
        {die "$Fct: ERROR: missing parameter 'subsystem' !\n" ;}
    
	# SUE-30277. Don't use row 'lasttimestamp', because it doesn't store the
    # correct date/time in other time zones. Better use local epoche time
    # 'lastupdated'
    my $sql = "select component,service,status,pid,port,lastupdated from systems.systemstatus where systemid=? and service=?";	
    my @sqlArgs = ($param{systemid}, $param{subsystem});
    $param{sql} = $sql;
    $param{sqlArgs} = \@sqlArgs;

    return runSqlSelect(%param);
    }

#---------------------------------------------------------------------------
# Example:
# getAllProcessFromDb(dbHandle => $databaseHandle);
#
# Return: Array ref with found results.
#---------------------------------------------------------------------------
sub getAllProcessFromDb
    {
    my (%param) = @_;
    my $Fct = (caller(0))[3]; 
    
    if (! $param{systemid})
       {die "$Fct: ERROR: missing parameter 'systemid' !\n" ;}

	# SUE-30277. Don't use row 'lasttimestamp', because it doesn't store the
    # correct date/time in other time zones. Better use local epoche time
    # 'lastupdated'
    my $sql = "select component,service,status,pid,port,lastupdated from systems.systemstatus where systemid=?";	
    my @sqlArgs = ($param{systemid});
    $param{sql} = $sql;
    $param{sqlArgs} = \@sqlArgs;

    return runSqlSelect(%param);
    }

#---------------------------------------------------------------------------
# Convenient funtion to run a SQL select statement.
# Example: 
# runSqlSelect(dbHandle => $databaseHandle, 
#              sql => 'select component from systems.systemstatus where systemid=?',
#              sqlArs => \@selectParams);
#
# Return: Array ref with found results.
#---------------------------------------------------------------------------
sub runSqlSelect
    {
    my (%param) = @_;
    my $dbHandle = $param{dbHandle};
    my $sqlSelect = $param{sql};
    my $ra_sqlArgs  = $param{sqlArgs};
    
    my $Fct = (caller(0))[3]; 
    if (! $param{dbHandle})  {die "$Fct: ERROR: missing parameter 'dbHandle' !\n" ;}
    if (! $param{sql})  {die "$Fct: ERROR: missing parameter 'sql' !\n" ;}
    if (! $ra_sqlArgs || ref($ra_sqlArgs) ne 'ARRAY')  {die "$Fct: ERROR: missing parameter 'sqlArgs' !\n" ;}
    
    my $return = 
    eval {
        my $select_cached_sth; 
        if (! ($select_cached_sth = $dbHandle->prepare_cached($sqlSelect)) )
            {
            my $msg = "SQL statement: " . $dbHandle->errstr ;
            print $msg;
            return;
            }
        $select_cached_sth->execute(@$ra_sqlArgs); 
        my $ref = $dbHandle->selectall_arrayref($select_cached_sth);
        $select_cached_sth->finish;
        return $ref;
    };

    if ($@)
        {
        my $msg = gettext ("ErrorTransaction", $@);
        print $msg;
        return;
        }
    
    return $return;
    }

#---------------------------------------------------------------------------
# local message table
#---------------------------------------------------------------------------
sub GetLocalMessages
    {
    my $rh_Table;
    return $rh_Table = {
        de => {
            Usage => "*******************************************************************************\n"
                . "%1    \n"
                . "(c) 2010-2011 SEAL Systems %2\n\n"
                . "Nagios Plug-in fuer SEAL-Serveranwendungen.\n"
                . "------------------------------------------------------------------------------\n"
                . "Aufruf: %1\n"
                . "          [-application <name>]\n"
                . "          [-appport <port>]\n"
                . "          [-criticalthreshold <range>]\n"
                . "          [-dbport <port>]\n" 
                . "          [-diagnose]\n"
				. "          [-h]\n"
				. "          [-history]\n"
                . "          [-process <name>]\n"
                . "          [-service <name>]\n"
                . "          [-statistics <name>]\n"
                . "          [-statusmapping <mapping>]\n\n"
				. "          [-v]\n"
                . "          [-warnthreshold <range>]\n"
                . "  -allprocess           Information ueber das Gesamtsystem (alle Prozesse).\n"
                . "  -application       Name der Anwendung.\n"
                . "  -appport           Port der Anwendung.\n"
                . "  -criticalthreshold Schwellwert(bereich) fuer Nagios-Status Critical.\n"                
                . "  -dbport            Portnummer der SEAL-Datenbank.\n" 
                . "  -diagnose          Diagnosemodus.\n"
                . "  -h                 zeigt diesen Hilfetext an.\n"
                . "  -history           zeigt die Versionshistorie des Programms an.\n"
                . "  -process           Prozessname fuer den Informationen abgerufen werden.\n"
                . "  -service           Servicename fuer den Informationen abgerufen werden.\n"
                . "  -statistics        Name der Statistikinformation.\n"
                . "  -statusmapping     Abbildung SEAL-Status -> Nagios-Status.\n"
                . "  -v                 zeigt die Programmversion an.\n"
                . "  -warnthreshold     Schwellwert(bereich) fuer Nagios-Status Warning.\n",
            DbportNotSet  => 'Portnummer des SEAL-Datenbankservers fehlt, Option -dbport <portnummer> angeben',
            OptionsError  => 'Fehler in Kommandozeile',
            OptionsConfl  => "Die Optionen -process und -statistics koennen nicht gleichzeitig gesetzt werden",             
            DiagnoseMsg1  => "Diagnose des SEAL-Plug-ins --- ",
            DiagnoseMsg2  => "+-- Anwendung: ",
            ConnectFail   => "Verbindungsaufbau zur SEAL-Datenbank nicht moeglich",
            ConnectSucc   => "Verbindung zur SEAL-Datenbank hergestellt",
            NoConfig      => "Es wurden keine Konfigurationsdaten gefunden",
            SysmonState   => "System Monitoring: ",
            MaintState    => "   Wartung: ",
            UnexpState    => " - Unbekannter Status -",
            AppMaint      => " -WARTUNG-",
            InfoOutdated  => " -VERALTET-",
            ON            => "AN",
            OFF           => "AUS",
            Process       => "Prozess",
            NoProcess     => "Es wurden keine Prozessinformationen gefunden!",
            StatisticId   => "Statistik Id",
            NoStatistics  => "Statitische Informationen nicht in der SEAL-Datenbank gefunden!",
            AppNotFound   => "Es wurden keine Informationen zur Anwendung in der SEAL-Datenbank gefunden",
            PInfoNotFound => "Prozessinformationen nicht in der SEAL-Datenbank gefunden",
            InfoNotFound =>  "Information nicht in der SEAL-Datenbank gefunden",
            SysmonOff     => "Das System Monitoring ist abgeschaltet",
            BadStatMapPar => "Ungueltiger Optionswert bei: -statusmapping",
            BadStatMapConf=> "Ungueltiger Wert in der Konfiguration bei: NAGIOS_STATUSMAPPING",
            unknown       => "Unbekannt",
            badWarn       => "Ungueltiger Wert bei: -warnthreshold",
            badCrit       => "Ungueltiger Wert bei: -criticalthreshold",
            CritRange     => "-Im kritischen Bereich-",
            WarnRange     => "-Im Warnbereich-",
            Value         => "Wert",
            ErrorTransaction  => "Fehlerhafte Datenbank Transaktion\n%1",
 
			},
        en => {
            Usage => "*******************************************************************************\n"
                . "%1    \n"
                . "(c) 2010-2011 SEAL Systems %2\n\n"
                . "Nagios Plug-in for SEAL server applications\n"
                . "------------------------------------------------------------------------------\n"
                . "Usage: %1 \n" 
                . "          [-application <name>]\n"
                . "          [-appport <port>]\n"
                . "          [-criticalthreshold <range>]\n"
                . "          [-dbport <port>]\n" 
                . "          [-diagnose]\n"
				. "          [-h]\n"
				. "          [-history]\n"
                . "          [-process <name>]\n"
                . "          [-service <name>]\n"
                . "          [-statistics <name>]\n"
                . "          [-statusmapping <mapping>]\n\n"
				. "          [-v]\n"
                . "          [-warnthreshold <range>]\n"
                . "  -allprocess           information about complete system (all processes).\n"
                . "  -application       application name.\n"
                . "  -appport           application port.\n"
                . "  -criticalthreshold threshold for Nagios status Critical.\n"
                . "  -dbport            port of SEAL database.\n" 
                . "  -diagnose          shows diagnostics information.\n"
                . "  -h                 shows this help.\n"
                . "  -history           shows the revision history of the program.\n"
                . "  -process           Name of the process for which information is requested.\n"
                . "  -service           Name of the service for which information is requested.\n"
                . "  -statistics        Name of statistical information.\n"
                . "  -statusmapping     mapping SEAL status -> Nagios status.\n"
                . "  -v                 shows the program version.\n"
                . "  -warnthreshold     threshold for Nagios status Warning.\n",
 
            DbportNotSet  => 'Port number of SEAL database server not specified, use -dbport <portnumber>',
            OptionsError  => 'Error in command line',
            OptionsConfl  => "Conflicting options -process and -statistics cannot be set at the same time", 
            DiagnoseMsg1  => "Diagnostics of SEAL plug-in --- ",
            DiagnoseMsg2  => "+-- Application: ",
            ConnectFail   => "connection to SEAL db failed",
            ConnectSucc   => "connection established",
            NoConfig      => "No configuration data found",
            SysmonState   => "System Monitoring: ",
            MaintState    => "   Maintenance: ",
            UnexpState    => " -unexpected status-",
            AppMaint      => " -MAINTENANCE-",
            InfoOutdated  => " -OUTDATED-",
            NoProcess     => "No process information found!",
            StatisticId   => "Statistic Id",
            NoStatistics  => "Statistic information not found in SEAL database!",
            AppNotFound   => "Application not found in database",
            PInfoNotFound => "Process information not found in SEAL database",
            InfoNotFound =>  "Information not found in SEAL database",
            SysmonOff     => "System Monitoring NOT ACTIVE",
            BadStatMapPar => "Option value invalid at: -statusmapping",
            BadStatMapConf=> "Value in configuration invalid at: NAGIOS_STATUSMAPPING",
            badWarn       => "Option value invalid at: -warnthreshold",
            badCrit       => "Option value invalid at: -criticalthreshold",
            CritRange     => "-In CRITICAL Range-",
            WarnRange     => "-In WARN Range-",            
            ErrorTransaction  => "Database transaction failed\n%1",
            },
		};
    }

sub history
    {
    print "\nRevision History:\n";
    while (<DATA>)
        {
        print $_;
        }
    exit 0;
    }

sub getVersion
    {
    my $VERSION = '$Revision: 1.26 $';
    $VERSION =~ s/\$\w+:\s*([0-9.,]+)\s*\$/$1/;
    return $VERSION;
    }
#Help / Usage
sub showHelp
    {
    my $help = gettext("Usage",scalar fileparse($0), getVersion());
    print $help;
#    return 0;
    exit 0;   
    };

sub showVersion
    {
    my $VERSION = getVersion();
    print "Version: $VERSION\n" ;
    exit 0;
    }
sub max
    {
     my ($a, $b) = @_;
     return $a > $b ? $a : $b
    }
    
# Connect to SEAL database, return db handle
sub dbConnect
    {
    my ($dbname, $dbhost, $dbport, $dbuser, $dbpasswd) = @_;
    
    my $data_source = "dbi:Pg:database=$dbname;host=$dbhost;port=$dbport";
    my $dbh = DBI->connect($data_source, $dbuser, $dbpasswd, {AutoCommit => 1});

    return $dbh;
    }
    
# get applications on localshost from database
sub getApplications
    {
    my ($dbh, $dbhost) = @_;
    
    my $sql;
    my $ref;
    my @applicationlist;
    
    # JIRA SMT-42 Get aliases hostnames for a given host
    my @hostList = startstop::exclude::getAliases ($dbhost);
    my $alternativeHostname = $ENV{SEAL_SYSTEMNAME};
    push @hostList, $alternativeHostname if (defined $alternativeHostname and $alternativeHostname ne "");
 
    # application: PLOSSYS netdome
    foreach my $hostname (@hostList)
        {
        $sql = "select systemid,port from systems.systemsplossys where host ilike '$hostname'";
        $ref = $dbh->selectall_arrayref($sql);
        if (scalar @$ref > 0)
            { 
            foreach my $element (@{$ref})
                {
                push @{$element}, "PLOSSYS netdome";
                push @applicationlist, $element;
                };
            #-- Set the correct host to access to database
            $dbhost = $hostname;
            last;
            }       
        }
    # application: DPF
    $sql = "select systemid,port from systems.systemsdpf where host ilike '$dbhost'";
    $ref = $dbh->selectall_arrayref($sql);
    foreach my $element (@{$ref})
        {
        push @{$element}, "DPF";
        push @applicationlist, $element;
        };
           
    # application: NETPLOT    
    $sql = "select systemid from systems.systemsnetplot where host ilike '$dbhost'";
    $ref = $dbh->selectall_arrayref($sql);
    foreach my $element (@{$ref})
        {
        push @{$element}, "0";        #no port for Netplot
        push @{$element}, "NETPLOT";
        push @applicationlist, $element;
        };
        
    # application: SAP  
    $sql = "select systemid, sysnr from systems.systemssap where host ilike '$dbhost'";
    $ref = $dbh->selectall_arrayref($sql);
    foreach my $element (@{$ref})
        {
        push @{$element}, "SAP";    #sysnr replaces port for SAP
        push @applicationlist, $element;
        };

    # more applications may be added here...
    
    return @applicationlist;
    }

sub testThreshold
    {
    my ($message, $value, $warn, $crit) = @_;
    my $retstat;
    my $ctest = inside($value, $crit);
    my $btest = inside($value, $warn);
    
    if ($btest and $btest == -1)  
        {
        print gettext("badWarn")."\n";
        exit ($reterr);
        }
    if ($ctest and $ctest == -1)
        {
        print gettext("badCrit")."\n";
        exit ($reterr);
        }
    if ($ctest)
        {
        $message = "CRITICAL: ".$message. gettext("CritRange");
        $retstat = 2
        }
    elsif ($btest)
        {
        $message = "WARNING: ".$message. gettext("WarnRange");
        $retstat = 1
        }
    else
        {       
        $message = "OK: ".$message ;
        $retstat = 0;
        }
        
    $_[0] = $message;   #writeback message in first parameter 
    return $retstat;    #return Nagios compatible status
    }
    
sub inside
    {
    my ($value, $range) = @_;
    
    my $inner;
    my $i; 
    my $end;
    my $ch;
    my $val;
    my $from = 0;
    my $valLow = 0;
    my $valHigh = "MAX";
    my $state = 0;
    
    #evaluate range
    if (!$range) {return}
    $end = length($range);
    if (!$end) {return}
    
    for ($i=0; $i<$end; $i++)
        {
        $ch = substr($range,$i,1);
        if ($ch eq ' ') 
            {
            if ($from == $i) {$from = $i+1}
            else
                {
                $val = substr($range,$from,$i-$from)+0;
                if ($state == 2) 
                    {
                    $valHigh = $val;
                    $state = 4
                    }
                elsif ($state < 2)
                    {
                    $valLow = $val;
                    $state = 2
                }
                else {return -1};
                $from = $i+1;
                }
            }
        elsif ($ch eq '@')
            {
            if ($state == 0) 
                {
                $state = 1;
                $inner = 1;
                $from = $i+1              
                }
            else {return -1}
            }
        elsif ($ch eq '~')
            {
             if ($state<2) 
                {
                $state = 2;
                $valLow = "MIN";
                $from = $i+1                   
                }
            else {return -1};
            }
        elsif ($ch eq ':')
            {
            if ($state > 2) {return -1}
            if ($from < $i)
                {
                if ($state > 1) {return -1}
                $valLow = substr($range,$from,$i-$from)+0            
                }
            $state = 3;
            $from = $i+1;
            }
        elsif ($ch lt "0" or $ch gt "9") {return -1}
        }
    if ($from <$i)
        {
        if ($state < 2) {$valHigh = substr($range,$from,$i-$from)+0}
        elsif ($state == 3) {$valHigh = substr($range,$from,$i-$from)+0}
        else {return -1}
        }
        
    # Value in range?
    if ($inner)
        {
        if (($valLow eq "MIN" or $valLow <= $value) and 
            ($valHigh eq "MAX" or $valHigh >= $value)) {return 1}
        return
        }
    else
        {
         if (($valLow ne "MIN" and $valLow > $value) or
             ($valHigh ne "MAX" and $valHigh < $value)) {return 1}
         return
        }
        
    }
    
sub NagiosMessageAndStatus
    {
    my ($message, $sealstatus, $statMapPar, $statMapConf) = @_;
    my $retstat;
    my $statMap;
    my $ch;
    my $i;

    # no statusmap (parameter and config)? use factory default
    if (!$statMapPar and !$statMapConf) { $statMap = $statusmapFACTORY };
    
    # if statusmap in config: check it
    if ($statMapConf)
        {
        if (length($statMapConf) != $statusmaplength)
            {
             $_[0] = gettext("BadStatMapConf");   #writeback errormessage 
            return $reterr;    #return error
            }
        else
            {
            for ($i = 0; $i<$statusmaplength; $i++ )
                {
                $ch = substr($statMapConf,$i,1);
                if (($ch lt "0") or ($ch gt "3"))
                    {
                    $_[0] = gettext("BadStatMapConf");   #writeback errormessage 
                    return $reterr;    #return error
                    }                
                }
            }
        $statMap = $statMapConf
        }
    else
        {
        $statMap = $statusmapFACTORY
        }
    
    # if statsmap in parameter: check and replace "D"
    if ($statMapPar)
        {
        if (length($statMapPar) != $statusmaplength)
            {
             $_[0] = gettext("BadStatMapPar");   #writeback errormessage 
            return $reterr;    #return error
            }
        else
            {
            for ($i = 0; $i<$statusmaplength; $i++ )
                {
                $ch = substr($statMapPar,$i,1);
                if (($ch eq "D") or ($ch eq "d"))
                    {
                    $ch = substr($statMap,$i,1);
                    substr($statMapPar,$i,1) = $ch
                    }
                if (($ch lt "0") or ($ch gt "3"))
                    {
                    $_[0] = gettext("BadStatMapPar");   #writeback errormessage 
                    return $reterr;    #return error
                    }                
                }
            }
        $statMap = $statMapPar
        }
   
    #determine Nagios status fron SEAL status
    if ($sealstatus eq "STARTING")
        {
        $retstat = substr($statMap,0,1) + 0
        }
    elsif ($sealstatus eq "STOPPING")
        {
        $retstat = substr($statMap,1,1) + 0
        }
    elsif ($sealstatus eq "FATAL")
        {
        $retstat = substr($statMap,2,1) + 0
        }
    elsif ($sealstatus eq "ERROR")
        {
        $retstat = substr($statMap,3,1) + 0
        }
    elsif ($sealstatus eq "UNKNOWN")
        {
        $retstat = substr($statMap,4,1) + 0
        }
    elsif ($sealstatus eq "STOPPED")
        {
        $retstat = substr($statMap,5,1) + 0
        }
    elsif ($sealstatus eq "WARNING")
        {
        $retstat = substr($statMap,6,1) + 0
        }
    elsif ($sealstatus eq "RUNNING" || $sealstatus eq "OK")
        {
        $retstat = substr($statMap,7,1) + 0
        }
    elsif ($sealstatus eq "OUTDATED")
        {
        $message .= gettext("InfoOutdated");
        $retstat = substr($statMap,8,1) + 0
        }
    elsif ($sealstatus eq "MAINTENANCE")
        {
        $message .= gettext("AppMaint");
        $retstat = substr($statMap,9,1) + 0
        }
    else 
        {
        #unexpected Status => Return status of UNKNOWN
        $retstat = substr($statMap,4,1) + 0;
        $message .= gettext("UnexpState");
        }

    # set Nagios prefix
    if ($retstat == 0)
        {
        $message = "OK:  $message \n"
        }
    elsif ($retstat == 1)
        {
        $message = "WARNING:  $message \n"
        }
    elsif ($retstat == 2)
        {
        $message = "CRITICAL:  $message \n"
        }
    else
        {
        $message = "UNDEFINED:  $message \n";
        $retstat = 3
        }
    $_[0] = $message;   #writeback message in first parameter 
    return $retstat;    #return Nagios compatible status
    }

sub getSystemid
    {
    my ( $dbh, $dbhost, $appname, $appport) = @_;

    my @applications = getApplications ($dbh, $dbhost);
    
    # find the right systemid in applicationslist (and return)
    APP:foreach my $element (@applications)
        {
        if ($appname and $appname ne ${$element}[2]){ next APP};
        if ($appport and $appport ne ${$element}[1]){ next APP};
        return ${$element}[0]
        }
    # nothing found
    return 
    }

sub getConfigurationFromDatabase
    {
    my ( $dbh, $systemid) = @_;
    my $sql;
    return if (! $dbh || ! $systemid);    
    
    #build hashable key-value pairs
    $sql = "select id, value from sysmon.config where systemid='$systemid'";
    return @{$dbh->selectcol_arrayref($sql, { Columns=>[1,2] })}
    }

#---------------------------------------------------------------------------------
# Print all available common data about SEAL applications. Use systemstatus to get 
# these data.
#
# Return: 0 => ok
#         $reterr (see global variables)
#---------------------------------------------------------------------------------
sub outputDiagnosis
    {
    my ($rh_dbData) = @_;
    my $Fct = (caller(0))[3]; 
    unless (ref ($rh_dbData) eq "HASH") {die "$Fct: ERROR: Parameter must be a hash reference!" ;}

    my $message = gettext("DiagnoseMsg1");
    print $message;
    print "dbs= " . $rh_dbData->{HOST} . ":" . $rh_dbData->{PORT} . " --- ";

    # connect to database
    my $dbh = dbConnect($rh_dbData->{NAME}, "localhost", $rh_dbData->{PORT},
                        $rh_dbData->{USER}, $rh_dbData->{PASSWORD});
    if (!$dbh)
        {
        $message = gettext("ConnectFail");
        print "$message\n";
        return $reterr;
        }
    else
        {
        $message = gettext("ConnectSucc");
        print "$message\n";
        };
        
    # get applications on localshost (=$dbhost) from database
    my @applicationlist = getApplications($dbh, $rh_dbData->{HOST});
    
    # applications loop
    foreach my $element (@applicationlist)
        {
        # application headline
        print gettext("DiagnoseMsg2");
        my $application = ${$element}[2];
        print $application;
        print "  Server:". $rh_dbData->{HOST};
        if (${$element}[1] ne "0")
            {
            print ":".${$element}[1];
            };
        my $systemid = ${$element}[0];
        print "  Id:$systemid\n";

        # get configuration for this systemid from database
        my %config = getConfigurationFromDatabase($dbh, $systemid);
        if (!%config or !$config{SYSMON} or !$config{MAINTENANCE})
            {
            $message = gettext("NoConfig");
            print "    $message\n"
            }
        else
            {
            $message = gettext("SysmonState") . gettext($config{SYSMON}) 
                     . gettext("MaintState") . gettext($config{MAINTENANCE});
            print "    $message\n"            
            }
        
        if ( $config{SYSMON} !~ /OFF/i )
            {
            #processes for this application
            my $ref = getAllProcessData($dbh, $systemid);
            outputAllProcessData ($ref);
            
            #statistics for this application
            $ref = getAllStatisticData($dbh, $systemid);
            outputAllStatisticData ($ref);
           }
        };

    # close connection
    $dbh->disconnect;    

    return 0;
    }

#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
sub getAllProcessData
    {
    my ($dbh, $systemid) = @_;
    my $Fct = (caller(0))[3]; 

    unless ($dbh or $systemid) {die "$Fct: ERROR: missing parameter!\n" ;}
    my $sql = "select component,service,status,pid,port from systems.systemstatus where systemid='$systemid'";
    return $dbh->selectall_arrayref($sql);
    }

#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
sub getAllStatisticData
    {
    my ($dbh, $systemid) = @_;
    my $Fct = (caller(0))[3]; 

    unless ($dbh or $systemid) {die "$Fct: ERROR: missing parameter!\n" ;}
    my $sql = "select id,service,value from sysmon.statistics where systemid='$systemid'";
    return $dbh->selectall_arrayref($sql);
    }


#---------------------------------------------------------------------------------
# Print all statistic data of a gviven application (systemId) to STDOUT.
#---------------------------------------------------------------------------------
sub outputAllStatisticData
    {
    my ($ra_Statistic) = @_;
    my ($message);

    if (!@{$ra_Statistic})
        {
        $message = gettext("NoStatistics");
        print "    $message\n";            
        }
    else
        {
        $message = gettext("StatisticId");
        #- sort by ID
        my @sortedById = sort { $a->[0] cmp $b->[0] } @$ra_Statistic;
        my $statStringLength = maxStringLength(\@sortedById, 0);

        foreach my $stat(@sortedById)
            {
            printf "    $message: %s Service: %s ".gettext("Value").": %s\n", 
                    substr(${$stat}[0]." "x$statStringLength,0,$statStringLength), substr(${$stat}[1]." "x20,0,20), 
 
                   substr(${$stat}[2]." "x25,0,25);
            }
        }       
    }

#---------------------------------------------------------------------------------
# Print all process data of a given application (systemId) to STDOUT.
#---------------------------------------------------------------------------------
sub outputAllProcessData
    {
    my ($ra_Application) = @_;
    my ($message);
    
    if (!@{$ra_Application})
        {
        $message = gettext("NoProcess");
        print "    $message\n";            
        }
    else
        {
        $message = gettext("Process");
        #- sort by process and service 
        my @sortedByProcessAndService = sort { $a->[1] cmp $b->[1] or lc($a->[0]) cmp lc($b->[0]) } @$ra_Application;
        my $processStringLength = maxStringLength(\@sortedByProcessAndService, 0);

        foreach my $proc(@sortedByProcessAndService)
            {
            printf "    $message: %s Service: %s Status: %s Pid: %s Port: %s\n", 
                   substr(${$proc}[0]." "x$processStringLength,0,$processStringLength), substr(${$proc}[1]." "x20,0,20),                    
                   substr(${$proc}[2]." "x10,0,10), substr(${$proc}[3]." "x8,0,8), 
                   substr(${$proc}[4]." "x8,0,8);
            }
        }
    }

#--------------------------------------------
#--------------------------------------------
sub maxStringLength
    {
    my ($ref_data, $position) = @_;
   
    return unless ($ref_data);
    return if ($position < 0);
    
    my $maxStringLength = 0; 
    foreach my $proc(@{$ref_data})
        {
        my $stringLength = length ($proc->[$position]);
        if ( $stringLength > $maxStringLength )
            {
            $maxStringLength = $stringLength; 
            } 
        }
    return $maxStringLength; 
    }

#---------------------------------------------------------------------------
#---------------------------------------------------------------------------
sub validateConfiguration
    {
    my (%param) = @_;
   
    my $rh_config = $param{config};

    if (! $param{systemId})
        {
        # specified application was not found in SEAL db 
        return printErrorStatus("AppNotFound", "UNKNOWN", $param{statusmap});
        }
    if ( ref($rh_config) eq 'HASH' and ! keys %$rh_config)
        {
        # Configuration was not found in SEAL db 
        return printErrorStatus("NoConfig", "UNKNOWN", $param{statusmap});
        }
    
    # is system monitoring enabled for this application?
    if (! $rh_config->{SYSMON} or ($rh_config->{SYSMON} ne "ON"))
        {
        return printErrorStatus("SysmonOff", "UNKNOWN", $param{statusmap}, $rh_config->{NAGIOS_STATUSMAPPING});
        }
    else
        {
        return; 
        }
    }

#---------------------------------------------------------------------------
#---------------------------------------------------------------------------
#
# New subroutine "buildProcessMessage" extracted - Mon Apr 13 12:05:58 2015.
#
sub buildProcessMessage 
{
    my $ref = shift;
    my $message;
    $message = gettext("Process");
    $message .= ": @{@{$ref}[0]}[0]   Status: @{@{$ref}[0]}[2]   ";
    my $pid = @{@{$ref}[0]}[3];
    my $port = @{@{$ref}[0]}[4];
    if ($pid > 0) { $message .= "Pid: $pid   "}
    if ($port > 0) {$message .= "Port: $port   "}
    return $message;
}

sub printErrorStatus
   {
   my ($messageKey, $sealstatus, $statusmap, $statMapConf) = @_;
   my $message = gettext($messageKey);
   my $nagiosStatus = NagiosMessageAndStatus($message, $sealstatus, $statusmap, $statMapConf);
   print $message;
   return $nagiosStatus;
   } 

#---------------------------------------------------------------------------
#---------------------------------------------------------------------------
sub outputNagiosSystemMonintoringInfo
    {
    my ($rh_dbData) = @_;
    my $Fct = (caller(0))[3]; 
    
    if (! $rh_dbData || ref($rh_dbData) ne 'HASH')  {die "$Fct: ERROR: missing parameter!\n" ;}

    }    

# ---------------------------------------------------------------------------------------------------------------------------
# end of programm code
#
## Bugtracking: Route STDERR to a logfile 
#sub BEGIN
#    {
#    my $logfilename = "stderr.log"; #<--- MODIFY TO YOUUR NEEDS
#    close STDERR;
#    open STDERR, ">>$logfilename";
#    }
#
__DATA__

  HISTORY
  $Header: /home/e1/plscvs/tools/sysmon/nagiosplugin/sealplugin.pl,v 1.26 2018/02/09 18:08:10 juergen Exp $
  $Log: sealplugin.pl,v $
  Revision 1.26  2018/02/09 18:08:10  juergen
  SUE-30277 resolved. Processes in other time zones than GMT are always outdated.
  This affects only processes managed in database 'systems', table 'systemstatus'.
  Don't use row 'lasttimestamp', because it doesn't store the correct date/time
  in other time zones. Better use local epoche time 'lastupdated' in table 'systemstatus'.
  New function: is_Database_Table_Systemstatus_UpToDate()

  Revision 1.25  2016/07/11 11:50:13  juergen
  JIRA SMT-64 resolved:
  DPF inserts status 'OK' in tabel 'systemstatus'. This status is now
  considered by evaluating process status summary (option -allprocess, -service).

  Revision 1.24  2016/07/01 13:55:07  juergen
  SMT-64: Option '-allprocess' has to evaluate all process states of
  type 'RUNNING' and 'OK'

  Revision 1.23  2015/04/16 14:41:49  juergen
  JIRA ticket SMT-34 resolved:
  - determine status of a subsystem, use parameter "-service"
  - determine status of total system, use parameter "-allprocess"
  Additionally a greater refactoring has been done.

  Revision 1.22  2015/01/12 15:30:23  juergen
  SMT-51 resolved: double output of usage message.
  Exit the Perl script directly in function showHelp().

  Revision 1.21  2013/10/14 10:58:55  juergen
  Because of security reasons option "-diagnose" does not print any messages
  to output.

  Revision 1.20  2013/10/11 14:10:41  juergen
  JIRA SMT-42: Read alternative hostname from environment variable SEAL_SYSTEMNAME

  Revision 1.19  2013/09/26 13:23:32  juergen
  JIRA ticket SMT-42: use different hostnames for local system to get
  the right systemid from database.

  Revision 1.18  2013/07/19 13:10:57  juergen
  Bug fixed: Script output for option "-diagnose" results in shortened strings,
  because the strings are formatted and limited to 16 or 24 characters.
  This affects process names and statistic information like gates and queues.
  Now these names are displayed without limited length.

  Revision 1.17  2011/10/18 16:01:37  juergen
  JIRA issue SMT-31 reolved: Sort output to STDOUT, if parameter "-diagnose" is set.

  Revision 1.16  2011/10/13 16:03:07  juergen
  New to System Monitoring, Version 1.0.1
  Use user "sysmon" to access to System Monitoring and systemstatus tables.
  The user's privileges are restricted. He has read only access.

  Revision 1.15  2011/07/14 11:00:35  tom
  Bugtracking Hilfe hinzugef�gt

  Revision 1.14  2011/05/20 08:46:34  tom
  Usage gem�� SMT-32 erg�nzt

  Revision 1.13  2011/04/12 14:43:34  tom
  Texte gem�� SMT-19 angepasst

  Revision 1.12  2011/04/11 08:23:43  tom
  extra Nagios Performance Daten f�r statistische Informationen hinzugef�gt

  Revision 1.11  2011/04/11 07:54:53  tom
  Release Candidate No 2

  Revision 1.10  2011/04/05 16:29:29  tom
  Fehlerbehebung

  Revision 1.9  2011/04/03 19:53:12  tom
  Release Candidate No 1

  Revision 1.8  2011/04/01 13:44:09  tom
  in development

  Revision 1.7  2011/03/31 14:23:58  tom
  in development

  Revision 1.6  2011/03/28 15:36:16  tom
  in development

  Revision 1.5  2011/03/23 08:40:03  tom
  in development

  Revision 1.4  2011/03/16 10:37:37  tom
  in development

  Revision 1.3  2011/03/08 13:59:03  tom
  in Entwicklung

  Revision 1.2  2011/03/03 13:50:02  tom
  in development

  Revision 1.1  2011/02/23 13:46:25  tom
  Added to CVS

